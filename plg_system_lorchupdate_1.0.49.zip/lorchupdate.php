<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\Installer;
use Joomla\CMS\Installer\InstallerHelper;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\CMS\Updater\Updater;
use Joomla\CMS\Uri\Uri;
use Joomla\CMS\Version;
use Joomla\Database\DatabaseInterface;
use Joomla\Database\ParameterType;

final class PlgSystemLorchupdate extends CMSPlugin
{
    private const LOCAL_RATE_LIMIT_WINDOW_SECONDS = 60;
    private const LOCAL_RATE_LIMIT_MAX_ATTEMPTS = 120;
    private const LOCAL_RATE_LIMIT_BLOCK_SECONDS = 300;

    protected $autoloadLanguage = true;
    private ?string $cachedAgentVersion = null;
    private bool $agentResponseSent = false;

    public function onAfterInitialise(): void
    {
        $app = Factory::getApplication();
        $input = $app->input;

        if ($input->getCmd('lucagent') !== '1') {
            return;
        }

        $this->registerAgentFatalErrorHandler();

        if (!$this->checkLocalRateLimit()) {
            $this->respond([
                'status' => 'error',
                'message' => 'Zu viele Agent-Anfragen. Bitte später erneut versuchen.',
            ], 429);
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->respond([
                'status' => 'error',
                'message' => 'Nur POST ist erlaubt.',
            ], 405);
        }

        $action = $input->getCmd('action');

        if (!in_array($action, ['handshake', 'ping', 'precheck', 'backup', 'prepare_update', 'update', 'agent_update', 'core_runner_probe', 'core_runner_akeeba_guard', 'core_runner_dry_run', 'core_runner_status', 'core_runner_dry_run_step'], true)) {
            $this->respond([
                'status' => 'error',
                'message' => 'Aktion nicht unterstützt.',
            ], 404);
        }

        $config = $this->readConfig();
        $payload = json_decode((string) file_get_contents('php://input'), true);

        if (!is_array($payload)) {
            $this->respond([
                'status' => 'error',
                'message' => 'Ungültiger JSON-Body.',
            ], 400);
        }

        if (!$this->validateSignature($action, $payload, $config)) {
            $this->respond([
                'status' => 'error',
                'message' => 'Signatur ungültig.',
            ], 403);
        }

        try {
            if ($action === 'precheck') {
                $data = $this->buildPrecheckData($config);
            } elseif ($action === 'backup') {
                $data = $this->buildBackupData($config, $payload);
            } elseif ($action === 'prepare_update') {
                $data = $this->buildUpdatePreparationData($config);
            } elseif ($action === 'update') {
                $data = $this->buildUpdateData($config, $payload);
            } elseif ($action === 'agent_update') {
                $data = $this->buildAgentUpdateData($config, $payload);
            } elseif ($action === 'core_runner_probe') {
                $data = $this->buildCoreRunnerProbeData($config);
            } elseif ($action === 'core_runner_akeeba_guard') {
                $data = $this->buildCoreRunnerAkeebaGuardData($config);
            } elseif ($action === 'core_runner_dry_run') {
                $data = $this->buildCoreRunnerDryRunData($config);
            } elseif ($action === 'core_runner_status') {
                $data = $this->buildCoreRunnerStatusData($config);
            } elseif ($action === 'core_runner_dry_run_step') {
                $data = $this->buildCoreRunnerDryRunStepData($config, $payload);
            } else {
                $data = $this->buildAgentData($config);
            }
        } catch (\Throwable $throwable) {
            $this->respond([
                'status' => 'error',
                'message' => 'Agent-Aktion fehlgeschlagen.',
                'data' => [
                    'site_uuid' => (string) ($config['site_uuid'] ?? ''),
                    'agent_version' => $this->getAgentVersion(),
                    'action' => $action,
                ],
                'timestamp' => gmdate(DATE_ATOM),
            ], 500);
        }

        $this->respond([
            'status' => 'ok',
            'message' => $action === 'handshake'
                ? 'Handshake erfolgreich.'
                : ($action === 'ping'
                    ? 'Ping erfolgreich.'
                    : ($action === 'backup'
                        ? 'Backup-Aktion ausgeführt.'
                        : ($action === 'update' ? 'Update-Aktion ausgeführt.' : 'Precheck erfolgreich.'))),
            'data' => $data,
            'timestamp' => gmdate(DATE_ATOM),
        ]);
    }

    private function registerAgentFatalErrorHandler(): void
    {
        register_shutdown_function(function (): void {
            if ($this->agentResponseSent) {
                return;
            }

            $error = error_get_last();

            if (!is_array($error)) {
                return;
            }

            $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR];

            if (!in_array((int) ($error['type'] ?? 0), $fatalTypes, true)) {
                return;
            }

            if (!headers_sent()) {
                http_response_code(500);
                header('Content-Type: application/json; charset=utf-8');
            }

            echo json_encode([
                'status' => 'error',
                'message' => 'Agent-Fatal-Error: ' . (string) ($error['message'] ?? 'Unbekannter PHP-Fatal-Error'),
                'data' => [
                    'agent_version' => $this->getAgentVersion(),
                    'action' => Factory::getApplication()->input->getCmd('action', ''),
                    'fatal_error' => [
                        'type' => (int) ($error['type'] ?? 0),
                        'message' => (string) ($error['message'] ?? ''),
                        'file' => (string) ($error['file'] ?? ''),
                        'line' => (int) ($error['line'] ?? 0),
                    ],
                ],
                'timestamp' => gmdate(DATE_ATOM),
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        });
    }

    private function checkLocalRateLimit(): bool
    {
        $baseDirectory = $this->resolveNonceBaseDirectory();

        if ($baseDirectory === null) {
            return true;
        }

        $directory = rtrim($baseDirectory, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'luc-agent-rate-limit';

        if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
            return true;
        }

        $this->purgeExpiredRateLimitFiles($directory, time() - 86400);
        $ipAddress = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        $action = Factory::getApplication()->input->getCmd('action', 'unknown');
        $filePath = $directory . DIRECTORY_SEPARATOR . hash('sha256', $ipAddress . '|' . $action) . '.json';
        $now = time();
        $state = [];

        if (is_file($filePath)) {
            $decoded = json_decode((string) @file_get_contents($filePath), true);
            $state = is_array($decoded) ? $decoded : [];
        }

        $blockedUntil = (int) ($state['blocked_until'] ?? 0);

        if ($blockedUntil > $now) {
            return false;
        }

        $windowStartedAt = (int) ($state['window_started_at'] ?? ($state['last_attempt'] ?? 0));

        if ($windowStartedAt <= 0 || ($now - $windowStartedAt) > self::LOCAL_RATE_LIMIT_WINDOW_SECONDS) {
            $windowStartedAt = $now;
            $attempts = 1;
        } else {
            $attempts = ((int) ($state['attempts'] ?? 0)) + 1;
        }

        $nextState = [
            'attempts' => $attempts,
            'window_started_at' => $windowStartedAt,
            'last_attempt' => $now,
            'blocked_until' => $attempts > self::LOCAL_RATE_LIMIT_MAX_ATTEMPTS ? $now + self::LOCAL_RATE_LIMIT_BLOCK_SECONDS : 0,
        ];

        @file_put_contents($filePath, json_encode($nextState, JSON_UNESCAPED_SLASHES), LOCK_EX);

        return $nextState['blocked_until'] === 0;
    }

    private function purgeExpiredRateLimitFiles(string $directory, int $expireBefore): void
    {
        $files = @glob($directory . DIRECTORY_SEPARATOR . '*.json');

        if (!is_array($files)) {
            return;
        }

        foreach ($files as $filePath) {
            if (!is_string($filePath) || !is_file($filePath)) {
                continue;
            }

            $modifiedAt = @filemtime($filePath);

            if ($modifiedAt !== false && $modifiedAt < $expireBefore) {
                @unlink($filePath);
            }
        }
    }

    private function readConfig(): array
    {
        $webappUrl = trim((string) $this->params->get('webapp_url', ''));
        $siteUuid = trim((string) $this->params->get('site_uuid', ''));
        $keyId = trim((string) $this->params->get('key_id', ''));
        $secret = trim((string) $this->params->get('secret', ''));
        $akeebaApiSecret = trim((string) $this->params->get('akeeba_api_secret', ''));

        if ($webappUrl === '' || $siteUuid === '' || $keyId === '' || $secret === '') {
            $this->respond([
                'status' => 'error',
                'message' => 'Plugin-Konfiguration unvollständig.',
            ], 400);
        }

        return [
            'webapp_url' => rtrim($webappUrl, '/'),
            'site_uuid' => $siteUuid,
            'key_id' => $keyId,
            'secret' => $secret,
            'akeeba_api_secret' => $akeebaApiSecret,
        ];
    }

    private function validateSignature(string $action, array $payload, array $config): bool
    {
        $siteUuid = trim((string) ($_SERVER['HTTP_X_LUC_SITE_UUID'] ?? ''));
        $keyId = trim((string) ($_SERVER['HTTP_X_LUC_KEY_ID'] ?? ''));
        $timestamp = (int) ($_SERVER['HTTP_X_LUC_TIMESTAMP'] ?? 0);
        $nonce = trim((string) ($_SERVER['HTTP_X_LUC_NONCE'] ?? ''));
        $signature = trim((string) ($_SERVER['HTTP_X_LUC_SIGNATURE'] ?? ''));

        if ($siteUuid === '' || $keyId === '' || $timestamp <= 0 || $nonce === '' || $signature === '') {
            return false;
        }

        if ($siteUuid !== $config['site_uuid'] || $keyId !== $config['key_id']) {
            return false;
        }

        if (abs(time() - $timestamp) > 300) {
            return false;
        }

        $json = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if (!is_string($json)) {
            return false;
        }

        $canonical = implode("\n", [
            'POST',
            $action,
            (string) $timestamp,
            $nonce,
            hash('sha256', $json),
        ]);
        $expected = hash_hmac('sha256', $canonical, $config['secret']);

        if (!hash_equals($expected, $signature)) {
            return false;
        }

        return $this->rememberInboundNonce($config['site_uuid'], $nonce, $timestamp);
    }

    private function rememberInboundNonce(string $siteUuid, string $nonce, int $timestamp): bool
    {
        $baseDirectory = $this->resolveNonceBaseDirectory();

        if ($baseDirectory === null) {
            return false;
        }

        $directory = rtrim($baseDirectory, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'luc-agent-nonces';

        if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
            return false;
        }

        $this->purgeExpiredInboundNonceFiles($directory, time() - 600);

        $nonceHash = hash('sha256', $siteUuid . '|' . $nonce);
        $filePath = $directory . DIRECTORY_SEPARATOR . $nonceHash . '.nonce';

        if (is_file($filePath)) {
            return false;
        }

        $contents = json_encode([
            'site_uuid' => $siteUuid,
            'timestamp' => $timestamp,
            'created_at' => gmdate(DATE_ATOM),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return is_string($contents) && @file_put_contents($filePath, $contents, LOCK_EX) !== false;
    }

    private function resolveNonceBaseDirectory(): ?string
    {
        $candidates = [
            (string) Factory::getConfig()->get('tmp_path', ''),
            defined('JPATH_CACHE') ? (string) JPATH_CACHE : '',
            sys_get_temp_dir(),
        ];

        foreach ($candidates as $candidate) {
            $path = trim($candidate);

            if ($path === '') {
                continue;
            }

            if (is_dir($path) && is_writable($path)) {
                return $path;
            }
        }

        return null;
    }

    private function purgeExpiredInboundNonceFiles(string $directory, int $expireBefore): void
    {
        $files = @glob($directory . DIRECTORY_SEPARATOR . '*.nonce');

        if (!is_array($files)) {
            return;
        }

        foreach ($files as $filePath) {
            if (!is_string($filePath) || !is_file($filePath)) {
                continue;
            }

            $modifiedAt = @filemtime($filePath);

            if ($modifiedAt !== false && $modifiedAt < $expireBefore) {
                @unlink($filePath);
            }
        }
    }

    private function buildAgentData(array $config): array
    {
        $version = new Version();

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'admin_url' => rtrim(Uri::root(), '/') . '/administrator',
            'server_ip' => (string) ($_SERVER['SERVER_ADDR'] ?? ''),
            'webapp_url' => $config['webapp_url'],
        ];
    }

    private function buildPrecheckData(array $config): array
    {
        $version = new Version();
        $currentVersion = $version->getShortVersion();
        $appConfig = Factory::getConfig();
        $tmpPath = (string) $appConfig->get('tmp_path', '');
        $logPath = (string) $appConfig->get('log_path', '');
        $installationPath = JPATH_ROOT . '/installation';
        $kickstartPath = JPATH_ROOT . '/kickstart.php';
        $checks = [];
        $coreUpdate = $this->detectCoreUpdate($currentVersion);

        $checks[] = $this->makeCheck('site_online', ((int) $appConfig->get('offline', 0) === 0) ? 'ok' : 'fail', ((int) $appConfig->get('offline', 0) === 0) ? 'Website ist online.' : 'Website ist offline.');
        $checks[] = $this->makeCheck('debug_disabled', ((int) $appConfig->get('debug', 0) === 0) ? 'ok' : 'fail', ((int) $appConfig->get('debug', 0) === 0) ? 'Debug-Modus ist deaktiviert.' : 'Debug-Modus ist aktiv.');
        $checks[] = $this->makeCheck('tmp_path_writable', ($tmpPath !== '' && is_dir($tmpPath) && is_writable($tmpPath)) ? 'ok' : 'fail', $tmpPath !== '' ? 'tmp-Pfad geprüft.' : 'tmp_path ist leer.', ['path' => $tmpPath]);
        $checks[] = $this->makeCheck('log_path_writable', ($logPath !== '' && is_dir($logPath) && is_writable($logPath)) ? 'ok' : 'fail', $logPath !== '' ? 'log-Pfad geprüft.' : 'log_path ist leer.', ['path' => $logPath]);
        $checks[] = $this->makeCheck('installation_removed', !is_dir($installationPath) ? 'ok' : 'fail', !is_dir($installationPath) ? 'Kein installation-Verzeichnis gefunden.' : 'installation-Verzeichnis ist noch vorhanden.');
        $checks[] = $this->makeCheck('kickstart_absent', !is_file($kickstartPath) ? 'ok' : 'fail', !is_file($kickstartPath) ? 'Kein kickstart.php im Webroot gefunden.' : 'kickstart.php liegt im Webroot.');
        $checks[] = $this->makeCheck('php_version_supported', version_compare(PHP_VERSION, '8.1.0', '>=') ? 'ok' : 'fail', 'PHP-Version geprüft.', ['php_version' => PHP_VERSION]);
        $checks[] = $this->makeCheck('akeeba_present', is_dir(JPATH_ADMINISTRATOR . '/components/com_akeebabackup') ? 'ok' : 'warn', is_dir(JPATH_ADMINISTRATOR . '/components/com_akeebabackup') ? 'Akeeba Backup gefunden.' : 'Akeeba Backup nicht gefunden.');
        $checks[] = $this->checkAkeebaBackupOnUpdatePlugin();
        $checks[] = $this->makeCheck('actionlog_enabled', $this->isExtensionEnabled('plugin', 'actionlog', 'joomla') ? 'ok' : 'warn', $this->isExtensionEnabled('plugin', 'actionlog', 'joomla') ? 'User Action Log Plugin ist aktiv.' : 'User Action Log Plugin ist nicht aktiv.');
        $checks[] = $this->makeCheck('akeeba_api_secret_local', $config['akeeba_api_secret'] !== '' ? 'ok' : 'warn', $config['akeeba_api_secret'] !== '' ? 'Akeeba API Secret ist im Agenten hinterlegt.' : 'Akeeba API Secret fehlt im Agenten.');
        $checks[] = $this->checkJoomlaManualUpdatePath();
        $checks[] = $this->makeCheck('core_update_lookup', $coreUpdate['status'], $coreUpdate['message'], [
            'current_version' => $currentVersion,
            'target_version' => $coreUpdate['target_version'],
            'has_update' => $coreUpdate['has_update'],
            'same_major' => $coreUpdate['same_major'],
            'source' => $coreUpdate['source'] ?? 'unknown',
        ]);

        $summary = ['ok' => 0, 'warn' => 0, 'fail' => 0, 'overall' => 'ok'];

        foreach ($checks as $check) {
            $summary[$check['status']]++;
        }

        if ($summary['fail'] > 0) {
            $summary['overall'] = 'fail';
        } elseif ($summary['warn'] > 0) {
            $summary['overall'] = 'warn';
        }

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $currentVersion,
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'core_update' => [
                'current_version' => $currentVersion,
                'target_version' => $coreUpdate['target_version'],
                'has_update' => $coreUpdate['has_update'],
                'same_major' => $coreUpdate['same_major'],
                'status' => $coreUpdate['status'],
                'message' => $coreUpdate['message'],
            ],
            'summary' => $summary,
            'checks' => $checks,
        ];
    }

    private function buildBackupData(array $config, array $payload): array
    {
        $version = new Version();
        $backup = $this->triggerAkeebaBackup($config, $payload);

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'backup' => $backup,
        ];
    }

    private function buildCoreRunnerProbeData(array $config): array
    {
        $version = new Version();
        $appConfig = Factory::getConfig();
        $tmpPath = (string) $appConfig->get('tmp_path', '');
        $logPath = (string) $appConfig->get('log_path', '');
        $stateDirectory = $this->resolveCoreRunnerStateDirectory();
        $joomlaUpdateTempDirectory = $this->resolveJoomlaUpdateTempDirectory();
        $checks = [];

        $checks[] = $this->makeCheck('php_version', version_compare(PHP_VERSION, '8.1.0', '>=') ? 'ok' : 'fail', 'PHP-Version geprüft.', [
            'php_version' => PHP_VERSION,
        ]);
        $checks[] = $this->makeCheck('php_limits', 'ok', 'PHP-Limits gelesen.', [
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
        ]);
        $checks[] = $this->makeCheck('tmp_path_writable', ($tmpPath !== '' && is_dir($tmpPath) && is_writable($tmpPath)) ? 'ok' : 'fail', 'Joomla tmp_path geprüft.', [
            'path' => $tmpPath,
        ]);
        $checks[] = $this->makeCheck('log_path_writable', ($logPath !== '' && is_dir($logPath) && is_writable($logPath)) ? 'ok' : 'warn', 'Joomla log_path geprüft.', [
            'path' => $logPath,
        ]);
        $checks[] = $this->probeCoreRunnerStateDirectory($stateDirectory);
        $checks[] = $this->probeJoomlaUpdateTempDirectory($joomlaUpdateTempDirectory);
        $checks[] = $this->probeJoomlaUpdateModel();
        $checks[] = $this->checkAkeebaBackupOnUpdatePlugin();
        $checks[] = $this->probeZipArchiveSupport($tmpPath);
        $checks[] = $this->probeRemoteJoomlaPackageAccess($version->getShortVersion());

        $summary = ['ok' => 0, 'warn' => 0, 'fail' => 0, 'overall' => 'ok'];

        foreach ($checks as $check) {
            $status = (string) ($check['status'] ?? 'fail');
            $summary[$status] = (int) ($summary[$status] ?? 0) + 1;
        }

        if (($summary['fail'] ?? 0) > 0) {
            $summary['overall'] = 'fail';
        } elseif (($summary['warn'] ?? 0) > 0) {
            $summary['overall'] = 'warn';
        }

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'core_runner_probe' => [
                'status' => $summary['overall'] === 'fail' ? 'fail' : 'ok',
                'message' => 'Core-Runner-Probe abgeschlossen.',
                'summary' => $summary,
                'checks' => $checks,
            ],
        ];
    }

    private function buildCoreRunnerAkeebaGuardData(array $config): array
    {
        $version = new Version();
        $guard = $this->runCoreRunnerAkeebaGuard();

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'core_runner_akeeba_guard' => $guard,
        ];
    }

    private function buildCoreRunnerDryRunData(array $config): array
    {
        $version = new Version();
        $dryRun = $this->runCoreRunnerDryRun($version->getShortVersion());

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'core_runner_dry_run' => $dryRun,
        ];
    }

    private function buildCoreRunnerStatusData(array $config): array
    {
        $version = new Version();

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'core_runner_status' => $this->readCoreRunnerStatus(),
        ];
    }

    private function buildCoreRunnerDryRunStepData(array $config, array $payload): array
    {
        $version = new Version();
        $requestedStep = trim((string) ($payload['step'] ?? 'auto'));
        $stepResult = $this->runCoreRunnerDryRunStep($requestedStep, !empty($payload['reset_runner_state']), $config, $payload);
        $bridge = $this->buildCoreRunnerBridgeHandoff($stepResult);

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'core_runner_dry_run_step' => $this->sanitizeDiagnosticArray($stepResult),
            'core_update_bridge' => $bridge,
        ];
    }

    private function runCoreRunnerDryRun(string $currentVersion): array
    {
        $startedAt = gmdate(DATE_ATOM);
        $stateDirectory = $this->resolveCoreRunnerStateDirectory();
        $tmpPath = $this->resolveJoomlaUpdateTempDirectory();
        $result = [
            'status' => 'fail',
            'phase' => 'init',
            'message' => 'Core-Runner-Dry-Run wurde nicht abgeschlossen.',
            'current_version' => $currentVersion,
            'target_version' => null,
            'akeeba_guard' => null,
            'update_model' => null,
            'package' => null,
            'state_written' => false,
            'started_at' => $startedAt,
            'finished_at' => null,
        ];

        try {
            $result['phase'] = 'akeeba_guard';
            $guard = $this->runCoreRunnerAkeebaGuard();
            $result['akeeba_guard'] = $guard;

            if (empty($guard['verified_disabled'])) {
                $result['message'] = 'Dry-Run abgebrochen: Akeeba Backup on Update konnte nicht sicher deaktiviert werden.';
                $result['finished_at'] = gmdate(DATE_ATOM);
                $this->writeCoreRunnerDryRunState($stateDirectory, $result);

                return $result;
            }

            $result['phase'] = 'update_model';
            $model = $this->createJoomlaUpdateModel();
            $result['update_model'] = [
                'class' => get_class($model),
                'has_download' => method_exists($model, 'download'),
                'has_finaliseUpgrade' => method_exists($model, 'finaliseUpgrade'),
            ];

            $targetVersion = $this->fetchLatestVersionFromOfficialSources($this->majorVersion($currentVersion)) ?? '';
            $result['target_version'] = $targetVersion !== '' ? $targetVersion : null;

            if ($targetVersion === '' || !version_compare($targetVersion, $currentVersion, '>')) {
                $result['status'] = 'ok';
                $result['phase'] = 'dry_run_complete';
                $result['message'] = 'Kein neueres Joomla-Patchpaket für den Dry-Run ermittelt.';
                $result['finished_at'] = gmdate(DATE_ATOM);
                $this->writeCoreRunnerDryRunState($stateDirectory, $result);

                return $result;
            }

            $downloadUrl = $this->buildOfficialUpgradePackageUrl($targetVersion);
            $result['phase'] = 'package_download';
            $diagnostics = [];
            $body = $this->fetchRemoteText($downloadUrl, 'application/zip,application/octet-stream', $diagnostics);

            if (!is_string($body) || strlen($body) < 1000000) {
                $result['message'] = 'Joomla-Updatepaket konnte im Dry-Run nicht geladen werden.';
                $result['package'] = [
                    'url' => $downloadUrl,
                    'bytes' => is_string($body) ? strlen($body) : 0,
                    'diagnostics' => $this->sanitizeDiagnosticArray($diagnostics),
                ];
                $result['finished_at'] = gmdate(DATE_ATOM);
                $this->writeCoreRunnerDryRunState($stateDirectory, $result);

                return $result;
            }

            if (!$this->ensureCoreRunnerDirectory($tmpPath)) {
                $result['message'] = 'Joomla-Update-Temp-Verzeichnis ist für den Dry-Run nicht beschreibbar.';
                $result['finished_at'] = gmdate(DATE_ATOM);
                $this->writeCoreRunnerDryRunState($stateDirectory, $result);

                return $result;
            }

            $packagePath = $tmpPath . '/luc-runner-dry-run-' . str_replace('.', '-', $targetVersion) . '-' . bin2hex(random_bytes(6)) . '.zip';

            if (@file_put_contents($packagePath, $body, LOCK_EX) === false) {
                $result['message'] = 'Joomla-Updatepaket konnte im Dry-Run nicht in das Joomla-Update-Temp-Verzeichnis geschrieben werden.';
                $result['finished_at'] = gmdate(DATE_ATOM);
                $this->writeCoreRunnerDryRunState($stateDirectory, $result);

                return $result;
            }

            $hash = hash_file('sha256', $packagePath) ?: hash('sha256', $body);
            $result['package'] = [
                'url' => $downloadUrl,
                'path' => $packagePath,
                'bytes' => strlen($body),
                'sha256' => $hash,
                'diagnostics' => $this->sanitizeDiagnosticArray($diagnostics),
            ];
            @unlink($packagePath);
            $result['package']['removed_after_probe'] = !is_file($packagePath);
            $result['status'] = 'ok';
            $result['phase'] = 'dry_run_complete';
            $result['message'] = 'Core-Runner-Dry-Run abgeschlossen. Paketdownload und State-Schreibung funktionieren.';
            $result['finished_at'] = gmdate(DATE_ATOM);
            $this->writeCoreRunnerDryRunState($stateDirectory, $result);

            return $result;
        } catch (\Throwable $throwable) {
            $result['message'] = 'Core-Runner-Dry-Run fehlgeschlagen: ' . $throwable->getMessage();
            $result['exception_class'] = get_class($throwable);
            $result['exception_file'] = $throwable->getFile();
            $result['exception_line'] = $throwable->getLine();
            $result['finished_at'] = gmdate(DATE_ATOM);
            $this->writeCoreRunnerDryRunState($stateDirectory, $result);

            return $result;
        }
    }

    private function writeCoreRunnerDryRunState(string $stateDirectory, array &$result): void
    {
        if (!is_dir($stateDirectory) && !@mkdir($stateDirectory, 0755, true) && !is_dir($stateDirectory)) {
            return;
        }

        @file_put_contents(rtrim($stateDirectory, '/\\') . '/.htaccess', "Require all denied\n", LOCK_EX);
        $result['state_written'] = true;
        $payload = json_encode([
            'type' => 'dry_run',
            'written_at' => gmdate(DATE_ATOM),
            'result' => $result,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

        if (!is_string($payload) || @file_put_contents(rtrim($stateDirectory, '/\\') . '/dry-run.json', $payload, LOCK_EX) === false) {
            $result['state_written'] = false;
        }
    }

    private function readCoreRunnerStatus(): array
    {
        $stateDirectory = $this->resolveCoreRunnerStateDirectory();

        return [
            'status' => 'ok',
            'message' => 'Core-Runner-State gelesen.',
            'state_directory' => $stateDirectory,
            'states' => [
                'dry_run_step' => $this->readCoreRunnerStateFile($stateDirectory, 'dry-run-step.json'),
                'dry_run' => $this->readCoreRunnerStateFile($stateDirectory, 'dry-run.json'),
                'akeeba_guard' => $this->readCoreRunnerStateFile($stateDirectory, 'akeeba-guard.json'),
            ],
        ];
    }

    private function runCoreRunnerDryRunStep(string $requestedStep, bool $resetRunnerState = false, array $config = [], array $payload = []): array
    {
        $stateDirectory = $this->resolveCoreRunnerStateDirectory();

        if ($resetRunnerState) {
            $this->resetCoreRunnerStepState($stateDirectory, $payload);
        }

        $state = $this->readCoreRunnerStepResult($stateDirectory);
        $step = $requestedStep === '' ? 'auto' : $requestedStep;

        if ($step === 'auto') {
            $nextStep = is_array($state) ? ($state['next_step'] ?? null) : null;
            $stateStatus = is_array($state) ? (string) ($state['status'] ?? '') : '';
            $extract = is_array($state['update_runner_extract'] ?? null) ? $state['update_runner_extract'] : [];
            $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
            $bridgeId = trim((string) ($prepare['bridge_id'] ?? ''));
            $bridgeState = $bridgeId !== '' ? $this->readCoreUpdateBridgeState($bridgeId) : null;
            $bridgePhase = is_array($bridgeState) ? (string) ($bridgeState['phase'] ?? '') : '';

            if (in_array($bridgePhase, ['prepared', 'extracting', 'extracted', 'extract_finalized', 'finalise_upgrade_succeeded', 'joomla_finalized'], true)) {
                $step = 'external_extract';
            } elseif (
                is_array($state)
                && $stateStatus === 'running'
                && in_array((string) ($state['phase'] ?? ''), ['update_runner_extract_start', 'update_runner_extract_step'], true)
                && ($nextStep === null || $nextStep === '')
                && !empty($extract['extract_started'])
                && empty($extract['needs_more_steps'])
                && empty($extract['finaliseUpgrade_executed'])
            ) {
                $step = 'update_runner_finalize';
            } else {
                $step = ($stateStatus === 'fail' || $nextStep === null || $nextStep === '') ? 'init' : (string) $nextStep;
            }
        }

        $allowedSteps = ['init', 'akeeba_guard', 'update_model', 'package_prepare', 'package_chunk', 'verify_package', 'joomla_package_state', 'restoration_bridge_check', 'update_runner_prepare', 'external_extract', 'update_runner_finalize_external', 'cleanup'];

        if (!in_array($step, $allowedSteps, true)) {
            return [
                'status' => 'fail',
                'phase' => 'invalid_step',
                'message' => 'Unbekannte Dry-Run-Phase: ' . $step,
                'requested_step' => $requestedStep,
                'next_step' => is_array($state) ? ($state['next_step'] ?? null) : null,
            ];
        }

        try {
            if ($step === 'init') {
                return $this->runCoreRunnerDryRunInitStep($stateDirectory);
            }

            if (!is_array($state)) {
                $state = $this->runCoreRunnerDryRunInitStep($stateDirectory);
            }

            return match ($step) {
                'akeeba_guard' => $this->runCoreRunnerDryRunAkeebaStep($stateDirectory, $state),
                'update_model' => $this->runCoreRunnerDryRunUpdateModelStep($stateDirectory, $state),
                'package_prepare' => $this->runCoreRunnerDryRunPackagePrepareStep($stateDirectory, $state),
                'package_chunk' => $this->runCoreRunnerDryRunPackageChunkStep($stateDirectory, $state),
                'verify_package' => $this->runCoreRunnerDryRunVerifyPackageStep($stateDirectory, $state),
                'joomla_package_state' => $this->runCoreRunnerDryRunJoomlaPackageStateStep($stateDirectory, $state),
                'restoration_bridge_check' => $this->runCoreRunnerDryRunRestorationBridgeCheckStep($stateDirectory, $state),
                'update_runner_prepare' => $this->runCoreRunnerDryRunUpdateRunnerPrepareStep($stateDirectory, $state, $config, $payload),
                'external_extract' => $this->resumeCoreRunnerExternalState($stateDirectory, $state),
                'update_runner_finalize_external' => $this->runCoreRunnerExternalFinalizeStep($stateDirectory, $state, $payload),
                'cleanup' => $this->runCoreRunnerDryRunCleanupStep($stateDirectory, $state),
                default => $state,
            };
        } catch (\Throwable $throwable) {
            $failed = is_array($state) ? $state : $this->createCoreRunnerDryRunStepState();
            $failed['status'] = 'fail';
            $failed['phase'] = $step;
            $failed['message'] = 'Dry-Run-Phase fehlgeschlagen: ' . $throwable->getMessage();
            $failed['exception_class'] = get_class($throwable);
            $failed['exception_file'] = $throwable->getFile();
            $failed['exception_line'] = $throwable->getLine();
            $failed['updated_at'] = gmdate(DATE_ATOM);
            $failed['finished_at'] = gmdate(DATE_ATOM);
            $this->appendCoreRunnerDryRunStep($failed, $step, 'fail', $failed['message']);
            $this->writeCoreRunnerStepState($stateDirectory, $failed);

            return $failed;
        }
    }

    private function runCoreRunnerDryRunInitStep(string $stateDirectory): array
    {
        $state = $this->createCoreRunnerDryRunStepState();
        $this->cleanupCoreRunnerDryRunArtifacts();
        $this->cleanupCoreRunnerStalePreparedUpdateFiles();
        $this->cleanupCoreRunnerDryRunPackage($state);
        $state['status'] = 'running';
        $state['phase'] = 'init';
        $state['message'] = 'Core-Runner-Dry-Run initialisiert.';
        $state['next_step'] = 'akeeba_guard';
        $state['updated_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'init', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunAkeebaStep(string $stateDirectory, array $state): array
    {
        $guard = $this->runCoreRunnerAkeebaGuard();
        $state['akeeba_guard'] = $guard;
        $state['phase'] = 'akeeba_guard';
        $state['updated_at'] = gmdate(DATE_ATOM);

        if (empty($guard['verified_disabled'])) {
            $state['status'] = 'fail';
            $state['message'] = 'Dry-Run abgebrochen: Akeeba Backup on Update konnte nicht sicher deaktiviert werden.';
            $state['next_step'] = null;
            $state['finished_at'] = gmdate(DATE_ATOM);
            $this->appendCoreRunnerDryRunStep($state, 'akeeba_guard', 'fail', $state['message']);
            $this->writeCoreRunnerStepState($stateDirectory, $state);

            return $state;
        }

        $state['status'] = 'running';
        $state['message'] = 'Akeeba Guard abgeschlossen.';
        $state['next_step'] = 'update_model';
        $this->appendCoreRunnerDryRunStep($state, 'akeeba_guard', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunUpdateModelStep(string $stateDirectory, array $state): array
    {
        $currentVersion = (string) ($state['current_version'] ?? (new Version())->getShortVersion());
        $model = $this->createJoomlaUpdateModel();
        $targetVersion = $this->fetchLatestVersionFromOfficialSources($this->majorVersion($currentVersion)) ?? '';
        $state['phase'] = 'update_model';
        $state['update_model'] = [
            'class' => get_class($model),
            'has_download' => method_exists($model, 'download'),
            'has_finaliseUpgrade' => method_exists($model, 'finaliseUpgrade'),
        ];
        $state['target_version'] = $targetVersion !== '' ? $targetVersion : null;
        $state['updated_at'] = gmdate(DATE_ATOM);

        if ($targetVersion === '' || !version_compare($targetVersion, $currentVersion, '>')) {
            $state['status'] = 'ok';
            $state['phase'] = 'dry_run_complete';
            $state['message'] = 'Kein neueres Joomla-Patchpaket für den Dry-Run ermittelt.';
            $state['next_step'] = null;
            $state['finished_at'] = gmdate(DATE_ATOM);
            $this->appendCoreRunnerDryRunStep($state, 'update_model', 'ok', $state['message']);
            $this->writeCoreRunnerStepState($stateDirectory, $state);

            return $state;
        }

        $state['status'] = 'running';
        $state['message'] = 'Joomla-Update-Model und Zielversion geprüft.';
        $state['next_step'] = 'package_prepare';
        $this->appendCoreRunnerDryRunStep($state, 'update_model', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunPackagePrepareStep(string $stateDirectory, array $state): array
    {
        $targetVersion = (string) ($state['target_version'] ?? '');
        $tmpPath = $this->resolveJoomlaUpdateTempDirectory();

        if ($targetVersion === '') {
            throw new \RuntimeException('Keine Zielversion im Runner-State vorhanden.');
        }

        if (!$this->ensureCoreRunnerDirectory($tmpPath)) {
            throw new \RuntimeException('Joomla-Update-Temp-Verzeichnis ist für den Dry-Run nicht beschreibbar.');
        }

        $this->cleanupCoreRunnerDryRunPackage($state);
        $this->cleanupCoreRunnerDryRunArtifacts();
        $downloadUrl = $this->buildOfficialUpgradePackageUrl($targetVersion);
        $packagePath = $tmpPath . '/luc-runner-dry-run-step-' . str_replace('.', '-', $targetVersion) . '-' . bin2hex(random_bytes(6)) . '.zip';
        $state['phase'] = 'package_prepare';
        $state['package'] = [
            'url' => $downloadUrl,
            'path' => $packagePath,
            'bytes_downloaded' => 0,
            'total_bytes' => null,
            'chunk_size' => 4194304,
            'sha256' => null,
            'removed_after_probe' => false,
        ];
        $state['status'] = 'running';
        $state['message'] = 'Paketdownload vorbereitet.';
        $state['next_step'] = 'package_chunk';
        $state['updated_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'package_prepare', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunPackageChunkStep(string $stateDirectory, array $state): array
    {
        $package = is_array($state['package'] ?? null) ? $state['package'] : [];
        $url = (string) ($package['url'] ?? '');
        $path = (string) ($package['path'] ?? '');
        clearstatcache(true, $path);
        $fileBytes = ($path !== '' && is_file($path)) ? (int) filesize($path) : 0;
        $offset = max($fileBytes, (int) ($package['bytes_downloaded'] ?? 0), 0);
        $chunkSize = max(262144, min(4194304, (int) ($package['chunk_size'] ?? 4194304)));

        if ($url === '' || $path === '') {
            throw new \RuntimeException('Paket-URL oder Paketpfad fehlt im Runner-State.');
        }

        $diagnostics = [];
        $chunk = $this->fetchRemoteRange($url, $offset, $chunkSize, $diagnostics);

        if (!is_string($chunk) || $chunk === '') {
            $state['phase'] = 'package_chunk';
            $state['package'] = $package + [];
            $state['package']['bytes_downloaded'] = $offset;
            $state['package']['chunk_failures'] = (int) ($package['chunk_failures'] ?? 0) + 1;
            $state['package']['diagnostics'] = $this->sanitizeDiagnosticArray($diagnostics);
            $state['status'] = $state['package']['chunk_failures'] >= 5 ? 'fail' : 'running';
            $state['message'] = $state['status'] === 'fail'
                ? 'Paket-Chunk konnte nach mehreren Wiederholungen nicht geladen werden.'
                : 'Paket-Chunk konnte nicht geladen werden. Der Download wird erneut versucht.';
            $state['next_step'] = $state['status'] === 'fail' ? null : 'package_chunk';
            $state['updated_at'] = gmdate(DATE_ATOM);

            if ($state['status'] === 'fail') {
                $state['finished_at'] = gmdate(DATE_ATOM);
            }

            $this->appendCoreRunnerDryRunStep($state, 'package_chunk', $state['status'] === 'fail' ? 'fail' : 'warn', $state['message']);
            $this->writeCoreRunnerStepState($stateDirectory, $state);

            return $state;
        }

        $directory = dirname($path);

        if (!is_dir($directory) || !is_writable($directory)) {
            throw new \RuntimeException('Zielverzeichnis für den Paket-Chunk ist nicht beschreibbar.');
        }

        if (@file_put_contents($path, $chunk, FILE_APPEND | LOCK_EX) === false) {
            throw new \RuntimeException('Paket-Chunk konnte nicht geschrieben werden.');
        }

        clearstatcache(true, $path);
        $downloaded = is_file($path) ? (int) filesize($path) : ($offset + strlen($chunk));
        $totalBytes = isset($diagnostics['range_total']) && (int) $diagnostics['range_total'] > 0
            ? (int) $diagnostics['range_total']
            : ((int) ($package['total_bytes'] ?? 0) ?: null);
        $state['phase'] = 'package_chunk';
        $state['package'] = $package + [];
        $state['package']['bytes_downloaded'] = $downloaded;
        $state['package']['total_bytes'] = $totalBytes;
        $state['package']['last_chunk_bytes'] = strlen($chunk);
        $state['package']['last_chunk_range'] = [
            'from' => $offset,
            'to' => $offset + strlen($chunk) - 1,
        ];
        $state['package']['chunk_failures'] = 0;
        $state['package']['diagnostics'] = $this->sanitizeDiagnosticArray($diagnostics);
        $state['updated_at'] = gmdate(DATE_ATOM);
        $state['status'] = 'running';

        if ($totalBytes !== null && $downloaded >= $totalBytes) {
            $state['message'] = 'Paketdownload vollständig. Prüfschritt steht aus.';
            $state['next_step'] = 'verify_package';
        } else {
            $state['message'] = 'Paket-Chunk geladen: ' . $downloaded . ($totalBytes !== null ? ' von ' . $totalBytes : '') . ' Bytes.';
            $state['next_step'] = 'package_chunk';
        }

        $this->appendCoreRunnerDryRunStep($state, 'package_chunk', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunVerifyPackageStep(string $stateDirectory, array $state): array
    {
        $package = is_array($state['package'] ?? null) ? $state['package'] : [];
        $path = (string) ($package['path'] ?? '');
        $totalBytes = (int) ($package['total_bytes'] ?? 0);

        if ($path === '' || !is_file($path)) {
            throw new \RuntimeException('Dry-Run-Paket wurde nicht gefunden.');
        }

        clearstatcache(true, $path);
        $actualBytes = (int) filesize($path);

        if ($totalBytes > 0 && $actualBytes !== $totalBytes) {
            throw new \RuntimeException('Dry-Run-Paketgröße passt nicht zur erwarteten Größe.');
        }

        if ($actualBytes < 1000000) {
            throw new \RuntimeException('Dry-Run-Paket ist unerwartet klein.');
        }

        $state['phase'] = 'verify_package';
        $state['package'] = $package;
        $state['package']['bytes_downloaded'] = $actualBytes;
        $state['package']['sha256'] = hash_file('sha256', $path) ?: null;
        $state['status'] = 'running';
        $state['message'] = 'Dry-Run-Paket wurde geprüft.';
        $state['next_step'] = 'joomla_package_state';
        $state['updated_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'verify_package', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunJoomlaPackageStateStep(string $stateDirectory, array $state): array
    {
        $package = is_array($state['package'] ?? null) ? $state['package'] : [];
        $path = (string) ($package['path'] ?? '');
        $joomlaUpdateTempDirectory = rtrim($this->resolveJoomlaUpdateTempDirectory(), '/\\') . '/';

        if ($path === '' || !is_file($path)) {
            throw new \RuntimeException('Dry-Run-Paket wurde für die Joomla-Paketprüfung nicht gefunden.');
        }

        $normalizedPath = str_replace('\\', '/', $path);
        $normalizedTemp = str_replace('\\', '/', $joomlaUpdateTempDirectory);

        if (!str_starts_with($normalizedPath, $normalizedTemp)) {
            throw new \RuntimeException('Dry-Run-Paket liegt nicht im Joomla-Update-Temp-Verzeichnis.');
        }

        $zipSummary = $this->inspectJoomlaUpdateZipPackage($path);
        $model = $this->createJoomlaUpdateModel();
        $state['phase'] = 'joomla_package_state';
        $state['joomla_package_state'] = [
            'package_in_joomla_update_tmp' => true,
            'joomla_update_tmp' => rtrim($this->resolveJoomlaUpdateTempDirectory(), '/\\'),
            'zip' => $zipSummary,
            'update_model' => $this->summarizeJoomlaUpdateModelForRunner($model),
            'destructive_actions_executed' => false,
        ];
        $state['status'] = 'running';
        $state['message'] = 'Joomla-nahe Paketprüfung abgeschlossen. Es wurde nichts entpackt oder installiert.';
        $state['next_step'] = 'restoration_bridge_check';
        $state['updated_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'joomla_package_state', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunRestorationBridgeCheckStep(string $stateDirectory, array $state): array
    {
        $bridgePath = JPATH_PLUGINS . '/system/lorchupdate/restore.php';
        $extractPath = JPATH_ADMINISTRATOR . '/components/com_joomlaupdate/extract.php';
        $restorationPath = JPATH_ADMINISTRATOR . '/components/com_joomlaupdate/restoration.php';
        $updatePath = JPATH_ADMINISTRATOR . '/components/com_joomlaupdate/update.php';
        $bridgeUrl = rtrim(Uri::root(), '/') . '/plugins/system/lorchupdate/restore.php';
        $http = $this->httpPostForm($bridgeUrl, [], 15);
        $body = trim((string) ($http['body'] ?? ''));
        $checks = [
            'bridge_file_readable' => is_file($bridgePath) && is_readable($bridgePath),
            'extract_file_readable' => is_file($extractPath) && is_readable($extractPath),
            'restoration_file_readable' => is_file($restorationPath) && is_readable($restorationPath),
            'update_file_readable' => is_file($updatePath) && is_readable($updatePath),
            'bridge_http_status' => (int) ($http['status_code'] ?? 0),
            'bridge_ready_response' => $body === 'Ready',
        ];
        $ok = $checks['bridge_file_readable']
            && $checks['extract_file_readable']
            && $checks['bridge_http_status'] >= 200
            && $checks['bridge_http_status'] < 300
            && $checks['bridge_ready_response'];

        $state['phase'] = 'restoration_bridge_check';
        $state['restoration_bridge_check'] = [
            'status' => $ok ? 'ok' : 'fail',
            'bridge_url' => $bridgeUrl,
            'checks' => $checks,
            'required_checks' => [
                'bridge_file_readable',
                'extract_file_readable',
                'bridge_http_status_2xx',
                'bridge_ready_response',
            ],
            'optional_files' => [
                'restoration.php' => $checks['restoration_file_readable'],
                'update.php' => $checks['update_file_readable'],
            ],
            'response_sample' => $this->truncateDiagnosticString($body, 300),
            'destructive_actions_executed' => false,
        ];
        $state['status'] = $ok ? 'running' : 'fail';
        $state['message'] = $ok
            ? 'Joomla-Restoration-Bridge ist erreichbar. Es wurde keine Extraktion gestartet.'
            : 'Joomla-Restoration-Bridge ist nicht vollständig bereit.';
        $state['next_step'] = $ok ? 'update_runner_prepare' : null;
        $state['updated_at'] = gmdate(DATE_ATOM);

        if (!$ok) {
            $state['finished_at'] = gmdate(DATE_ATOM);
        }

        $this->appendCoreRunnerDryRunStep($state, 'restoration_bridge_check', $ok ? 'ok' : 'fail', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunUpdateRunnerPrepareStep(string $stateDirectory, array $state, array $config, array $payload): array
    {
        $package = is_array($state['package'] ?? null) ? $state['package'] : [];
        $path = (string) ($package['path'] ?? '');
        $targetVersion = (string) ($state['target_version'] ?? '');
        $currentVersion = (string) ($state['current_version'] ?? (new Version())->getShortVersion());
        $componentDirectory = JPATH_ADMINISTRATOR . '/components/com_joomlaupdate';
        $restorationPath = $componentDirectory . '/restoration.php';
        $updatePath = $componentDirectory . '/update.php';
        $handoffDirectory = $this->resolveJoomlaTempDirectory();
        $restorationExistedBefore = is_file($restorationPath);
        $updateExistedBefore = is_file($updatePath);

        if ($path === '' || !is_file($path)) {
            throw new \RuntimeException('Dry-Run-Paket wurde für die Update-Runner-Vorbereitung nicht gefunden.');
        }

        if (!$this->ensureCoreRunnerDirectory($handoffDirectory)) {
            throw new \RuntimeException('Joomla-tmp_path ist für die Update-Runner-Vorbereitung nicht beschreibbar.');
        }

        $handoffPath = rtrim($handoffDirectory, '/\\') . '/' . basename($path);
        $handoffExistedBefore = is_file($handoffPath);
        $handoffCopied = false;

        if (str_replace('\\', '/', $handoffPath) !== str_replace('\\', '/', $path)) {
            if (!@copy($path, $handoffPath)) {
                throw new \RuntimeException('Dry-Run-Paket konnte nicht in Joomla-tmp_path kopiert werden.');
            }

            clearstatcache(true, $handoffPath);
            $sourceBytes = filesize($path);
            $handoffBytes = filesize($handoffPath);

            if ($sourceBytes === false || $handoffBytes === false || (int) $sourceBytes !== (int) $handoffBytes) {
                throw new \RuntimeException('Handoff-Paket im Joomla-tmp_path ist unvollständig.');
            }

            $handoffCopied = true;
        }

        $model = $this->createJoomlaUpdateModel();
        $createResult = $this->invokeModelMethod($model, 'createRestorationFile', [
            [basename($handoffPath)],
        ]);
        $restorationExistedAfter = is_file($restorationPath);
        $updateExistedAfter = is_file($updatePath);
        $password = $this->readCoreRunnerUpdatePassword($restorationPath, $updatePath);

        if ($password === '') {
            throw new \RuntimeException('Joomla hat keine Restoration-/Update-Passwortdatei erzeugt oder das Passwort konnte nicht gelesen werden.');
        }

        $bridgeId = bin2hex(random_bytes(16));
        $bridgeKey = hash_hmac('sha256', "luc-core-update-bridge\n" . $bridgeId, (string) ($config['secret'] ?? ''));

        if (!$this->writeCoreUpdateBridgeState($bridgeId, [
            'bridge_id' => $bridgeId,
            'site_uuid' => (string) ($config['site_uuid'] ?? ''),
            'key_id' => (string) ($config['key_id'] ?? ''),
            'bridge_key' => $bridgeKey,
            'update_password' => $password,
            'restore_url' => rtrim(Uri::root(), '/') . '/plugins/system/lorchupdate/restore.php',
            'factory' => null,
            'phase' => 'prepared',
            'current_version' => $currentVersion,
            'target_version' => $targetVersion,
            'runner_job_id' => (int) ($payload['runner_job_id'] ?? 0),
            'created_at' => time(),
            'expires_at' => time() + 5400,
            'last_request_id' => '',
            'last_response' => null,
        ])) {
            throw new \RuntimeException('Der zustandsfeste Standalone-Updatekanal konnte nicht vorbereitet werden.');
        }

        $createdFiles = [];

        if (!$restorationExistedBefore && $restorationExistedAfter) {
            $createdFiles[] = $restorationPath;
        }

        if (!$updateExistedBefore && $updateExistedAfter) {
            $createdFiles[] = $updatePath;
        }

        $state['phase'] = 'update_runner_prepare';
        $state['update_runner_prepare'] = [
            'status' => 'ok',
            'current_version' => $currentVersion,
            'target_version' => $targetVersion,
            'package_path' => $path,
            'handoff_package' => [
                'path' => $handoffPath,
                'basename' => basename($handoffPath),
                'source_path' => $path,
                'directory' => $handoffDirectory,
                'copied' => $handoffCopied,
                'existed_before' => $handoffExistedBefore,
                'bytes' => is_file($handoffPath) ? filesize($handoffPath) : null,
                'remove_on_cleanup' => $handoffCopied && str_starts_with(basename($handoffPath), 'luc-runner-dry-run-step-'),
            ],
            'createRestorationFile' => $this->normalizeMethodResult($createResult),
            'files' => [
                'restoration_php' => [
                    'path' => $restorationPath,
                    'existed_before' => $restorationExistedBefore,
                    'exists_after' => $restorationExistedAfter,
                ],
                'update_php' => [
                    'path' => $updatePath,
                    'existed_before' => $updateExistedBefore,
                    'exists_after' => $updateExistedAfter,
                ],
            ],
            'created_files' => $createdFiles,
            'password_available' => true,
            'password_length' => strlen($password),
            'bridge_id' => $bridgeId,
            'runner_job_id' => (int) ($payload['runner_job_id'] ?? 0),
            'extraction_started' => false,
            'destructive_actions_executed' => false,
        ];
        $state['status'] = 'running';
        $state['message'] = 'Update-Vorbereitung abgeschlossen. Die Extraktion wird über den unabhängigen, zustandsfesten Updatekanal fortgesetzt.';
        $state['next_step'] = 'external_extract';
        $state['updated_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'update_runner_prepare', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function resumeCoreRunnerExternalState(string $stateDirectory, array $state): array
    {
        $state['phase'] = 'update_runner_prepare';
        $state['status'] = 'running';
        $state['next_step'] = 'external_extract';
        $state['message'] = 'Ein vorhandener Standalone-Update-State wird ohne erneuten Joomla-Bootstrap fortgesetzt.';
        $state['updated_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'external_extract', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunUpdateRunnerExtractStartStep(string $stateDirectory, array $state): array
    {
        $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
        $password = $this->normalizeScalarString($prepare['update_password'] ?? '');

        if ($password === '' || $password === '[redacted]') {
            throw new \RuntimeException('Update-Passwort fehlt im internen Runner-State. Bitte Dry-Run neu starten.');
        }

        $extractResponse = $this->callLocalUpdateBridge('startRestore', $password, null);
        $success = !empty($extractResponse['success']);
        $needsMoreSteps = !empty($extractResponse['needs_more_steps']);
        $state['phase'] = 'update_runner_extract_start';
        $state['update_runner_extract'] = [
            'status' => $success ? 'running' : 'fail',
            'start' => $extractResponse['summary'],
            'factory' => $extractResponse['factory'],
            'needs_more_steps' => $needsMoreSteps,
            'extract_started' => true,
            'finaliseUpgrade_executed' => false,
        ];
        $state['status'] = $success ? 'running' : 'fail';
        $state['message'] = $success
            ? 'Joomla-Extraktion wurde gestartet und der Factory-State gespeichert.'
            : 'Joomla-Extraktion konnte nicht gestartet werden.';
        $state['next_step'] = $success ? ($needsMoreSteps ? 'update_runner_extract_step' : 'update_runner_finalize') : null;
        $state['updated_at'] = gmdate(DATE_ATOM);

        if (!$success) {
            $state['finished_at'] = gmdate(DATE_ATOM);
        }

        $this->appendCoreRunnerDryRunStep($state, 'update_runner_extract_start', $success ? 'ok' : 'fail', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerDryRunUpdateRunnerExtractStep(string $stateDirectory, array $state): array
    {
        $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
        $extract = is_array($state['update_runner_extract'] ?? null) ? $state['update_runner_extract'] : [];
        $password = $this->normalizeScalarString($prepare['update_password'] ?? '');
        $factory = $this->normalizeFactoryState($extract['factory'] ?? null);

        if ($password === '' || $password === '[redacted]') {
            throw new \RuntimeException('Update-Passwort fehlt im internen Runner-State. Bitte Dry-Run neu starten.');
        }

        if ($factory === null || $factory === '' || $factory === '[redacted]') {
            throw new \RuntimeException('Factory-State fehlt im internen Runner-State. Bitte Extract-Start erneut prüfen.');
        }

        $extractResponse = $this->callLocalUpdateBridge('stepRestore', $password, $factory);
        $success = !empty($extractResponse['success']);
        $needsMoreSteps = !empty($extractResponse['needs_more_steps']);
        $extractSteps = is_array($extract['steps'] ?? null) ? $extract['steps'] : [];
        $extractSteps[] = $extractResponse['summary'];
        $state['phase'] = 'update_runner_extract_step';
        $state['update_runner_extract'] = $extract;
        $state['update_runner_extract']['status'] = $success ? 'running' : 'fail';
        $state['update_runner_extract']['factory'] = $extractResponse['factory'] ?? $factory;
        $state['update_runner_extract']['needs_more_steps'] = $needsMoreSteps;
        $state['update_runner_extract']['steps'] = array_slice($extractSteps, -40);
        $state['update_runner_extract']['finaliseUpgrade_executed'] = false;
        $state['status'] = $success ? 'running' : 'fail';
        $state['message'] = $success
            ? ($needsMoreSteps ? 'Ein Joomla-Extraktionsschritt wurde ausgeführt. Weitere Extraktionsschritte sind nötig.' : 'Joomla-Extraktionsschritt abgeschlossen. Nächste Phase: Finalisierung.')
            : 'Joomla-Extraktionsschritt ist fehlgeschlagen.';
        $state['next_step'] = $success ? ($needsMoreSteps ? 'update_runner_extract_step' : 'update_runner_finalize') : null;
        $state['updated_at'] = gmdate(DATE_ATOM);

        if (!$success) {
            $state['finished_at'] = gmdate(DATE_ATOM);
        }

        $this->appendCoreRunnerDryRunStep($state, 'update_runner_extract_step', $success ? 'ok' : 'fail', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function runCoreRunnerExternalFinalizeStep(string $stateDirectory, array $state, array $payload): array
    {
        $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
        $bridgeId = trim((string) ($payload['bridge_id'] ?? ''));
        $expectedBridgeId = trim((string) ($prepare['bridge_id'] ?? ''));

        if ($bridgeId === '' || $expectedBridgeId === '' || !hash_equals($expectedBridgeId, $bridgeId)) {
            throw new \RuntimeException('Finalisierung abgebrochen: Bridge-ID fehlt oder passt nicht zum Update-State.');
        }

        $bridgeState = $this->readCoreUpdateBridgeState($bridgeId);

        $bridgePhase = is_array($bridgeState) ? (string) ($bridgeState['phase'] ?? '') : '';

        if (!is_array($bridgeState) || !in_array($bridgePhase, ['extract_finalized', 'finalise_upgrade_succeeded'], true)) {
            throw new \RuntimeException('Finalisierung abgebrochen: Die Standalone-Extraktion ist noch nicht vollständig finalisiert.');
        }

        if ((int) ($bridgeState['expires_at'] ?? 0) < time()) {
            throw new \RuntimeException('Finalisierung abgebrochen: Der Standalone-Update-State ist abgelaufen. Restore oder kontrollierte Recovery erforderlich.');
        }

        if ((string) ($bridgeState['target_version'] ?? '') !== (string) ($state['target_version'] ?? '')) {
            throw new \RuntimeException('Finalisierung abgebrochen: Zielversion des Standalone-States passt nicht.');
        }

        if ((int) ($bridgeState['runner_job_id'] ?? 0) <= 0 || (int) ($bridgeState['runner_job_id'] ?? 0) !== (int) ($payload['runner_job_id'] ?? 0)) {
            throw new \RuntimeException('Finalisierung abgebrochen: Der Standalone-State gehört nicht zu diesem Update-Job.');
        }

        $state['update_runner_extract'] = [
            'status' => 'ok',
            'needs_more_steps' => false,
            'extract_started' => true,
            'external_bridge' => true,
            'bridge_id' => $bridgeId,
            'finaliseUpgrade_executed' => false,
        ];

        return $this->runCoreRunnerDryRunUpdateRunnerFinalizeStep(
            $stateDirectory,
            $state,
            true,
            $bridgePhase === 'finalise_upgrade_succeeded'
        );
    }

    private function runCoreRunnerDryRunUpdateRunnerFinalizeStep(
        string $stateDirectory,
        array $state,
        bool $extractAlreadyFinalized = false,
        bool $finaliseUpgradeAlreadySucceeded = false
    ): array
    {
        $extract = is_array($state['update_runner_extract'] ?? null) ? $state['update_runner_extract'] : [];
        $currentVersion = (string) ($state['current_version'] ?? (new Version())->getShortVersion());
        $targetVersion = (string) ($state['target_version'] ?? '');

        if (empty($extract['extract_started'])) {
            throw new \RuntimeException('Finalisierung abgebrochen: Die Joomla-Extraktion wurde noch nicht gestartet.');
        }

        if (!empty($extract['needs_more_steps'])) {
            throw new \RuntimeException('Finalisierung abgebrochen: Die Joomla-Extraktion meldet noch offene Extraktionsschritte.');
        }

        if (!empty($extract['finaliseUpgrade_executed'])) {
            throw new \RuntimeException('Finalisierung abgebrochen: finaliseUpgrade wurde in diesem Runner-State bereits ausgeführt.');
        }

        $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
        $finalizeExtract = $extractAlreadyFinalized
            ? ['success' => true, 'summary' => ['task' => 'finalizeRestore', 'status' => true, 'external_bridge' => true]]
            : $this->callLocalUpdateBridge(
                'finalizeRestore',
                $this->normalizeScalarString($prepare['update_password'] ?? ''),
                $this->normalizeFactoryState($extract['factory'] ?? null)
            );

        if (empty($finalizeExtract['success'])) {
            $state['phase'] = 'update_runner_finalize';
            $state['update_runner_extract'] = $extract;
            $state['update_runner_finalize'] = [
                'status' => 'fail',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'extract_finalize' => $finalizeExtract['summary'],
            ];
            $state['status'] = 'fail';
            $state['message'] = 'Die lokale Joomla-Extraktion konnte nicht finalisiert werden.';
            $state['next_step'] = null;
            $state['updated_at'] = gmdate(DATE_ATOM);
            $state['finished_at'] = gmdate(DATE_ATOM);
            $this->appendCoreRunnerDryRunStep($state, 'update_runner_finalize', 'fail', $state['message']);
            $this->writeCoreRunnerStepState($stateDirectory, $state);

            return $state;
        }

        $model = $this->createJoomlaUpdateModel();
        $bridgeId = trim((string) ($prepare['bridge_id'] ?? ''));
        $bridgeState = $bridgeId !== '' ? $this->readCoreUpdateBridgeState($bridgeId) : null;

        if (!$finaliseUpgradeAlreadySucceeded) {
            if (!is_array($bridgeState)) {
                throw new \RuntimeException('Finalisierung abgebrochen: Persistenter Bridge-State fehlt.');
            }

            $bridgeState['phase'] = 'finalise_upgrade_inflight';
            $bridgeState['finalize_receipt'] = [
                'status' => 'inflight',
                'runner_job_id' => (int) ($bridgeState['runner_job_id'] ?? 0),
                'target_version' => $targetVersion,
                'created_at' => time(),
            ];

            if (!$this->writeCoreUpdateBridgeState($bridgeId, $bridgeState)) {
                throw new \RuntimeException('Finalisierung abgebrochen: Der Inflight-Beleg konnte nicht atomar geschrieben werden.');
            }
        }

        $finaliseResult = $finaliseUpgradeAlreadySucceeded
            ? true
            : $this->invokeModelMethod($model, 'finaliseUpgrade', [[]]);
        $finaliseFailed = $this->isFailedResult($finaliseResult);

        if (!$finaliseFailed && !$finaliseUpgradeAlreadySucceeded) {
            $bridgeState = $this->readCoreUpdateBridgeState($bridgeId);

            if (!is_array($bridgeState)) {
                throw new \RuntimeException('Finalisierung wurde ausgeführt, aber der persistente Bridge-State ist nicht mehr lesbar. Manuelle Prüfung erforderlich.');
            }

            $bridgeState['phase'] = 'finalise_upgrade_succeeded';
            $bridgeState['finalize_receipt'] = [
                'status' => 'finalise_upgrade_succeeded',
                'runner_job_id' => (int) ($bridgeState['runner_job_id'] ?? 0),
                'target_version' => $targetVersion,
                'finalise_upgrade_failed' => false,
                'created_at' => time(),
            ];

            if (!$this->writeCoreUpdateBridgeState($bridgeId, $bridgeState)) {
                throw new \RuntimeException('finaliseUpgrade war erfolgreich, aber der atomare Zwischenbeleg konnte nicht geschrieben werden. Manuelle Prüfung erforderlich.');
            }
        } elseif ($finaliseFailed && is_array($bridgeState)) {
            $bridgeState['phase'] = 'extract_finalized';
            $bridgeState['finalize_receipt'] = [
                'status' => 'fail',
                'runner_job_id' => (int) ($bridgeState['runner_job_id'] ?? 0),
                'target_version' => $targetVersion,
                'finalise_upgrade_failed' => true,
                'created_at' => time(),
            ];
            $this->writeCoreUpdateBridgeState($bridgeId, $bridgeState);
        }

        $cleanupResult = null;

        if (!$finaliseFailed && method_exists($model, 'cleanUp')) {
            $cleanupResult = $this->invokeModelMethod($model, 'cleanUp', [[]]);
        }

        $autoloadCachePath = JPATH_BASE . '/administrator/cache/autoload_psr4.php';
        $autoloadCacheExisted = is_file($autoloadCachePath);

        if ($autoloadCacheExisted) {
            @unlink($autoloadCachePath);
        }

        $postcheck = $this->waitForInstalledJoomlaVersionChange($currentVersion, $targetVersion, 12, 500000);
        $newVersion = (string) ($postcheck['effective_version'] ?? '');
        $updateSucceeded = !$finaliseFailed
            && $newVersion !== ''
            && $targetVersion !== ''
            && version_compare($newVersion, $targetVersion, '==');

        $state['phase'] = 'update_runner_finalize';
        $state['update_runner_extract'] = $extract;
        $state['update_runner_extract']['finaliseUpgrade_executed'] = true;
        $state['update_runner_finalize'] = [
            'status' => $updateSucceeded ? 'ok' : 'fail',
            'current_version' => $currentVersion,
            'target_version' => $targetVersion,
            'joomla_version' => $newVersion,
            'extract_finalize' => $finalizeExtract['summary'],
            'finaliseUpgrade' => $this->normalizeMethodResult($finaliseResult),
            'cleanUp' => $cleanupResult === null ? null : $this->normalizeMethodResult($cleanupResult),
            'autoload_cache' => [
                'path' => $autoloadCachePath,
                'existed_before' => $autoloadCacheExisted,
                'exists_after' => is_file($autoloadCachePath),
            ],
            'postcheck_version' => [
                'fresh_version' => $postcheck['fresh_version'] ?? '',
                'loaded_version' => $postcheck['loaded_version'] ?? '',
                'effective_version' => $newVersion,
                'attempts' => $postcheck['attempts'] ?? null,
            ],
        ];

        if (!$finaliseFailed) {
            $this->cleanupCoreRunnerPreparedUpdateFiles($state);
            $this->cleanupCoreRunnerDryRunPackage($state);
            $this->cleanupCoreRunnerDryRunArtifacts();
            $state['update_runner_finalize']['artifact_cleanup'] = $this->inspectCoreRunnerArtifactCleanup($state);
        }

        $artifactCleanupStatus = is_array($state['update_runner_finalize']['artifact_cleanup'] ?? null)
            ? (string) ($state['update_runner_finalize']['artifact_cleanup']['status'] ?? '')
            : '';

        if ($updateSucceeded && $artifactCleanupStatus !== 'ok') {
            $updateSucceeded = false;
            $state['update_runner_finalize']['status'] = 'fail';
            $state['update_runner_finalize']['cleanup_error'] = 'Update-Artefakte wurden nicht vollständig entfernt.';
        }

        $receiptWritten = false;

        if ($bridgeId !== '') {
            $bridgeState = $this->readCoreUpdateBridgeState($bridgeId);

            if (is_array($bridgeState)) {
                $bridgeState['phase'] = $updateSucceeded
                    ? 'joomla_finalized'
                    : ($finaliseFailed ? 'extract_finalized' : 'finalise_upgrade_succeeded');
                $bridgeState['expires_at'] = $updateSucceeded ? time() + 86400 : (int) ($bridgeState['expires_at'] ?? 0);
                $bridgeState['finalize_receipt'] = [
                    'status' => $updateSucceeded
                        ? 'ok'
                        : ($finaliseFailed ? 'fail' : ($artifactCleanupStatus !== 'ok' ? 'cleanup_failed' : 'postcheck_failed')),
                    'runner_job_id' => (int) ($bridgeState['runner_job_id'] ?? 0),
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'joomla_version' => $newVersion,
                    'finalise_upgrade_failed' => $finaliseFailed,
                    'artifact_cleanup' => $artifactCleanupStatus,
                    'created_at' => time(),
                ];

                if (!$finaliseFailed) {
                    unset($bridgeState['update_password'], $bridgeState['factory'], $bridgeState['inflight_request_id']);
                }

                $receiptWritten = $this->writeCoreUpdateBridgeState($bridgeId, $bridgeState);
            }
        }

        if ($updateSucceeded && !$receiptWritten) {
            $updateSucceeded = false;
            $state['update_runner_finalize']['status'] = 'fail';
            $state['update_runner_finalize']['receipt_error'] = 'Der persistente Finalisierungsbeleg konnte nicht geschrieben werden.';
        }

        $state['status'] = $updateSucceeded ? 'ok' : 'fail';
        $state['message'] = $updateSucceeded
            ? 'Joomla-Core-Update erfolgreich finalisiert: ' . $currentVersion . ' -> ' . $newVersion
            : ($finaliseFailed
                ? 'Joomla-Core-Update-Finalisierung ist fehlgeschlagen.'
                : ($artifactCleanupStatus !== 'ok'
                    ? 'Joomla-Core-Update wurde finalisiert, aber sicherheitsrelevante Update-Artefakte konnten nicht vollständig entfernt werden.'
                    : 'Joomla-Core-Update finalisiert, aber die Versionsprüfung ist fehlgeschlagen.'));
        $state['next_step'] = null;
        $state['updated_at'] = gmdate(DATE_ATOM);
        $state['finished_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'update_runner_finalize', $updateSucceeded ? 'ok' : 'fail', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function inspectCoreRunnerArtifactCleanup(array $state): array
    {
        $componentDirectory = JPATH_ADMINISTRATOR . '/components/com_joomlaupdate';
        $package = is_array($state['package'] ?? null) ? $state['package'] : [];
        $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
        $handoffPackage = is_array($prepare['handoff_package'] ?? null) ? $prepare['handoff_package'] : [];
        $mainPackagePath = (string) ($package['path'] ?? '');
        $handoffPath = (string) ($handoffPackage['path'] ?? '');
        $updatePath = $componentDirectory . '/update.php';
        $restorationPath = $componentDirectory . '/restoration.php';
        $paths = [
            'main_package' => $mainPackagePath,
            'handoff_package' => $handoffPath,
            'update_php' => $updatePath,
            'restoration_php' => $restorationPath,
        ];
        $items = [];

        foreach ($paths as $key => $path) {
            $items[$key] = [
                'path' => $path,
                'exists_after_cleanup' => $path !== '' && is_file($path),
            ];
        }

        $remainingLucZips = [];

        foreach (array_filter([
            $this->resolveJoomlaUpdateTempDirectory(),
            $this->resolveJoomlaTempDirectory(),
        ]) as $directory) {
            foreach (glob(rtrim($directory, '/\\') . '/luc-runner-dry-run*.zip') ?: [] as $path) {
                if (is_file($path)) {
                    $remainingLucZips[] = $path;
                }
            }
        }

        return [
            'status' => empty($items['main_package']['exists_after_cleanup'])
                && empty($items['handoff_package']['exists_after_cleanup'])
                && empty($items['update_php']['exists_after_cleanup'])
                && empty($items['restoration_php']['exists_after_cleanup'])
                && $remainingLucZips === [] ? 'ok' : 'warn',
            'items' => $items,
            'remaining_luc_zips' => $remainingLucZips,
        ];
    }

    private function inspectJoomlaUpdateZipPackage(string $path): array
    {
        if (!class_exists(\ZipArchive::class)) {
            throw new \RuntimeException('PHP ZipArchive ist für die Joomla-Paketprüfung nicht verfügbar.');
        }

        $zip = new \ZipArchive();
        $opened = $zip->open($path, \ZipArchive::RDONLY);

        if ($opened !== true) {
            throw new \RuntimeException('Dry-Run-Paket konnte nicht als ZIP geöffnet werden.');
        }

        $entryCount = (int) $zip->numFiles;
        $sampleEntries = [];
        $requiredEntries = [
            'administrator/components/com_admin/sql/updates/mysql/',
            'administrator/components/com_joomlaupdate/',
            'administrator/manifests/files/joomla.xml',
            'libraries/src/Version.php',
        ];
        $foundEntries = array_fill_keys($requiredEntries, false);

        for ($index = 0; $index < $entryCount; $index++) {
            $name = (string) $zip->getNameIndex($index);

            if ($name === '') {
                continue;
            }

            if (count($sampleEntries) < 30) {
                $sampleEntries[] = $name;
            }

            foreach ($requiredEntries as $requiredEntry) {
                if ($name === $requiredEntry || str_starts_with($name, $requiredEntry)) {
                    $foundEntries[$requiredEntry] = true;
                }
            }
        }

        $zip->close();

        $missingEntries = array_values(array_filter(
            array_keys($foundEntries),
            fn (string $entry): bool => !$foundEntries[$entry]
        ));

        if ($entryCount < 1000) {
            throw new \RuntimeException('Dry-Run-Paket enthält unerwartet wenige ZIP-Einträge.');
        }

        if ($missingEntries !== []) {
            throw new \RuntimeException('Dry-Run-Paket wirkt nicht wie ein vollständiges Joomla-Updatepaket.');
        }

        return [
            'open_readonly' => true,
            'entry_count' => $entryCount,
            'required_entries_found' => $foundEntries,
            'sample_entries' => $sampleEntries,
        ];
    }

    private function summarizeJoomlaUpdateModelForRunner(object $model): array
    {
        $methods = [];

        foreach (['download', 'createRestorationFile', 'finaliseUpgrade', 'getUpdateInformation', 'purge', 'refreshUpdates'] as $methodName) {
            $methods[$methodName] = method_exists($model, $methodName);
        }

        return [
            'class' => get_class($model),
            'methods' => $methods,
        ];
    }

    private function runCoreRunnerDryRunCleanupStep(string $stateDirectory, array $state): array
    {
        $this->cleanupCoreRunnerPreparedUpdateFiles($state);
        $this->cleanupCoreRunnerDryRunPackage($state);
        $state['phase'] = 'dry_run_complete';
        $state['status'] = 'ok';
        $state['message'] = 'Core-Runner-Dry-Run abgeschlossen. Paketdownload, Prüfsumme, Cleanup und State-Schreibung funktionieren.';
        $state['next_step'] = null;
        $state['updated_at'] = gmdate(DATE_ATOM);
        $state['finished_at'] = gmdate(DATE_ATOM);
        $this->appendCoreRunnerDryRunStep($state, 'cleanup', 'ok', $state['message']);
        $this->writeCoreRunnerStepState($stateDirectory, $state);

        return $state;
    }

    private function readCoreRunnerUpdatePassword(string $restorationPath, string $updatePath): string
    {
        if (is_file($restorationPath) && is_readable($restorationPath)) {
            $restorationSetup = ['kickstart.security.password' => ''];

            if (!defined('_AKEEBA_RESTORATION')) {
                define('_AKEEBA_RESTORATION', 1);
            }

            require $restorationPath;

            $password = $this->normalizeScalarString($restorationSetup['kickstart.security.password'] ?? '');

            if ($password !== '') {
                return $password;
            }
        }

        if (is_file($updatePath) && is_readable($updatePath)) {
            $extractionSetup = ['security.password' => ''];

            if (!defined('_JOOMLA_UPDATE')) {
                define('_JOOMLA_UPDATE', 1);
            }

            require $updatePath;

            return $this->normalizeScalarString($extractionSetup['security.password'] ?? '');
        }

        return '';
    }

    private function createCoreRunnerDryRunStepState(): array
    {
        $version = new Version();

        return [
            'status' => 'new',
            'phase' => 'init',
            'message' => 'Core-Runner-Dry-Run ist noch nicht gestartet.',
            'current_version' => $version->getShortVersion(),
            'target_version' => null,
            'next_step' => 'init',
            'akeeba_guard' => null,
            'update_model' => null,
            'package' => null,
            'steps' => [],
            'state_written' => false,
            'started_at' => gmdate(DATE_ATOM),
            'updated_at' => null,
            'finished_at' => null,
        ];
    }

    private function appendCoreRunnerDryRunStep(array &$state, string $step, string $status, string $message): void
    {
        $steps = is_array($state['steps'] ?? null) ? $state['steps'] : [];
        $steps[] = [
            'step' => $step,
            'status' => $status,
            'message' => $message,
            'time' => gmdate(DATE_ATOM),
        ];
        $state['steps'] = array_slice($steps, -80);
    }

    private function cleanupCoreRunnerDryRunPackage(array &$state): void
    {
        $package = is_array($state['package'] ?? null) ? $state['package'] : [];
        $path = (string) ($package['path'] ?? '');

        if ($path !== '' && str_starts_with(basename($path), 'luc-runner-dry-run-step-') && is_file($path)) {
            @unlink($path);
            $package['removed_after_probe'] = !is_file($path);
            $state['package'] = $package;
        }
    }

    private function cleanupCoreRunnerPreparedUpdateFiles(array &$state): void
    {
        $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
        $createdFiles = is_array($prepare['created_files'] ?? null) ? $prepare['created_files'] : [];
        $handoffPackage = is_array($prepare['handoff_package'] ?? null) ? $prepare['handoff_package'] : [];
        $removedFiles = [];
        $allowedDirectory = str_replace('\\', '/', JPATH_ADMINISTRATOR . '/components/com_joomlaupdate/');

        foreach ($createdFiles as $path) {
            $path = (string) $path;
            $normalizedPath = str_replace('\\', '/', $path);

            if (!str_starts_with($normalizedPath, $allowedDirectory)) {
                continue;
            }

            if (!in_array(basename($path), ['restoration.php', 'update.php'], true)) {
                continue;
            }

            if (is_file($path)) {
                @unlink($path);
                $removedFiles[] = [
                    'path' => $path,
                    'removed' => !is_file($path),
                ];
            }
        }

        $handoffPath = (string) ($handoffPackage['path'] ?? '');

        if (!empty($handoffPackage['remove_on_cleanup']) && str_starts_with(basename($handoffPath), 'luc-runner-dry-run-step-') && is_file($handoffPath)) {
            @unlink($handoffPath);
            $handoffPackage['removed_after_cleanup'] = !is_file($handoffPath);
            $prepare['handoff_package'] = $handoffPackage;
        }

        if ($removedFiles !== []) {
            $prepare['cleanup_removed_files'] = $removedFiles;
            $state['update_runner_prepare'] = $prepare;
        } elseif ($handoffPackage !== []) {
            $state['update_runner_prepare'] = $prepare;
        }
    }

    private function cleanupCoreRunnerStalePreparedUpdateFiles(): void
    {
        $componentDirectory = JPATH_ADMINISTRATOR . '/components/com_joomlaupdate';

        foreach (['restoration.php', 'update.php'] as $fileName) {
            $path = $componentDirectory . '/' . $fileName;

            if (!is_file($path) || !is_readable($path)) {
                continue;
            }

            $content = @file_get_contents($path);

            if (!is_string($content) || !str_contains($content, 'luc-runner-dry-run-step-')) {
                continue;
            }

            @unlink($path);
        }
    }

    private function cleanupCoreRunnerDryRunArtifacts(): void
    {
        $directories = array_values(array_unique(array_filter([
            $this->resolveJoomlaUpdateTempDirectory(),
            $this->resolveJoomlaTempDirectory(),
        ])));

        foreach ($directories as $directory) {
            if (!is_dir($directory) || !is_writable($directory)) {
                continue;
            }

            foreach (['luc-runner-dry-run-step-*.zip', 'luc-runner-dry-run-*.zip'] as $pattern) {
                $paths = glob(rtrim($directory, '/\\') . '/' . $pattern);

                foreach (is_array($paths) ? $paths : [] as $path) {
                    if (is_file($path) && preg_match('/^luc-runner-dry-run(?:-step)?-[a-z0-9.-]+\.zip$/i', basename($path)) === 1) {
                        @unlink($path);
                    }
                }
            }
        }
    }

    private function readCoreRunnerStepResult(string $stateDirectory): ?array
    {
        $state = $this->readCoreRunnerStateFileRaw($stateDirectory, 'dry-run-step.json');
        $result = is_array($state['result'] ?? null) ? $state['result'] : null;

        return is_array($result) ? $result : null;
    }

    private function buildCoreRunnerBridgeHandoff(array $state): ?array
    {
        $prepare = is_array($state['update_runner_prepare'] ?? null) ? $state['update_runner_prepare'] : [];
        $bridgeId = trim((string) ($prepare['bridge_id'] ?? ''));

        if ($bridgeId === '' || preg_match('/^[a-f0-9]{32}$/', $bridgeId) !== 1) {
            return null;
        }

        $bridgeState = $this->readCoreUpdateBridgeState($bridgeId);

        if (!is_array($bridgeState)) {
            return null;
        }

        return [
            'bridge_id' => $bridgeId,
            'endpoint_path' => '/plugins/system/lorchupdate/runner.php',
            'phase' => (string) ($bridgeState['phase'] ?? ''),
            'expires_at' => (int) ($bridgeState['expires_at'] ?? 0),
        ];
    }

    private function coreUpdateBridgeStateDirectory(): string
    {
        return rtrim(JPATH_PLUGINS, '/\\') . '/system/lorchupdate/.luc-update-bridge';
    }

    private function coreUpdateBridgeStatePath(string $bridgeId): string
    {
        return $this->coreUpdateBridgeStateDirectory() . '/' . $bridgeId . '.php';
    }

    private function writeCoreUpdateBridgeState(string $bridgeId, array $state): bool
    {
        if (preg_match('/^[a-f0-9]{32}$/', $bridgeId) !== 1) {
            return false;
        }

        $directory = $this->coreUpdateBridgeStateDirectory();

        if (!is_dir($directory) && !@mkdir($directory, 0700, true) && !is_dir($directory)) {
            return false;
        }

        @file_put_contents($directory . '/.htaccess', "Require all denied\n", LOCK_EX);
        $json = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        if (!is_string($json)) {
            return false;
        }

        $path = $this->coreUpdateBridgeStatePath($bridgeId);
        $temporary = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';

        if (@file_put_contents($temporary, "<?php exit; ?>\n" . $json, LOCK_EX) === false) {
            return false;
        }

        @chmod($temporary, 0600);

        if (!@rename($temporary, $path)) {
            @unlink($temporary);
            return false;
        }

        return true;
    }

    private function readCoreUpdateBridgeState(string $bridgeId): ?array
    {
        if (preg_match('/^[a-f0-9]{32}$/', $bridgeId) !== 1) {
            return null;
        }

        $content = @file_get_contents($this->coreUpdateBridgeStatePath($bridgeId));

        if (!is_string($content)) {
            return null;
        }

        $json = preg_replace('/^<\?php exit; \?>\R/', '', $content, 1);
        $decoded = is_string($json) ? json_decode($json, true) : null;

        return is_array($decoded) ? $decoded : null;
    }

    private function deleteCoreUpdateBridgeState(string $bridgeId): void
    {
        if (preg_match('/^[a-f0-9]{32}$/', $bridgeId) === 1) {
            @unlink($this->coreUpdateBridgeStatePath($bridgeId));
            @unlink($this->coreUpdateBridgeStatePath($bridgeId) . '.lock');
        }
    }

    private function resetCoreRunnerStepState(string $stateDirectory, array $payload = []): void
    {
        $statePath = rtrim($stateDirectory, '/\\') . '/dry-run-step.json';

        $existing = $this->readCoreRunnerStepResult($stateDirectory);
        $prepare = is_array($existing['update_runner_prepare'] ?? null) ? $existing['update_runner_prepare'] : [];
        $bridgeId = trim((string) ($prepare['bridge_id'] ?? ''));

        if ($bridgeId !== '') {
            $bridgeState = $this->readCoreUpdateBridgeState($bridgeId);
            $phase = is_array($bridgeState) ? (string) ($bridgeState['phase'] ?? '') : '';

            if ($phase === 'finalise_upgrade_inflight') {
                throw new \RuntimeException('Ein früherer finaliseUpgrade-Aufruf hat keinen eindeutigen Abschlussbeleg. Automatische Wiederholung ist gesperrt; manuelle Prüfung ist erforderlich.');
            }

            if (is_array($bridgeState) && (int) ($bridgeState['expires_at'] ?? 0) < time()) {
                if (in_array($phase, ['prepared', 'joomla_finalized'], true)) {
                    $this->deleteCoreUpdateBridgeState($bridgeId);
                    $phase = '';
                } else {
                    throw new \RuntimeException('Ein abgelaufener, bereits destruktiver Update-State wurde nicht gelöscht. Automatischer Neustart ist gesperrt; kontrollierte Recovery oder Restore erforderlich.');
                }
            }

            if (in_array($phase, ['prepared', 'extracting', 'extracted', 'extract_finalized', 'finalise_upgrade_succeeded', 'joomla_finalized'], true)) {
                $expectedJobId = (int) ($payload['runner_job_id'] ?? 0);
                $expectedTarget = trim((string) ($payload['target_version'] ?? ''));

                if (
                    $expectedJobId > 0
                    && $expectedJobId === (int) ($bridgeState['runner_job_id'] ?? 0)
                    && $expectedTarget !== ''
                    && hash_equals((string) ($bridgeState['target_version'] ?? ''), $expectedTarget)
                ) {
                    return;
                }

                throw new \RuntimeException('Ein fortsetzbarer Standalone-Update-State gehört zu einem anderen Job oder einer anderen Zielversion. Automatischer Reset wurde blockiert.');
            }
        }

        if (is_file($statePath)) {
            @unlink($statePath);
        }
    }

    private function readCoreRunnerStateFileRaw(string $stateDirectory, string $fileName): ?array
    {
        $path = rtrim($stateDirectory, '/\\') . '/' . basename($fileName);

        if (!is_file($path) || !is_readable($path)) {
            return null;
        }

        $content = @file_get_contents($path);
        $decoded = is_string($content) ? json_decode($content, true) : null;

        return is_array($decoded) ? $decoded : null;
    }

    private function readCoreRunnerStateFile(string $stateDirectory, string $fileName): ?array
    {
        $decoded = $this->readCoreRunnerStateFileRaw($stateDirectory, $fileName);

        return is_array($decoded) ? $this->sanitizeDiagnosticArray($decoded) : null;
    }

    private function writeCoreRunnerStepState(string $stateDirectory, array &$result): void
    {
        if (!is_dir($stateDirectory) && !@mkdir($stateDirectory, 0755, true) && !is_dir($stateDirectory)) {
            return;
        }

        @file_put_contents(rtrim($stateDirectory, '/\\') . '/.htaccess', "Require all denied\n", LOCK_EX);
        $result['state_written'] = true;
        $payload = json_encode([
            'type' => 'dry_run_step',
            'written_at' => gmdate(DATE_ATOM),
            'result' => $result,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

        if (!is_string($payload) || @file_put_contents(rtrim($stateDirectory, '/\\') . '/dry-run-step.json', $payload, LOCK_EX) === false) {
            $result['state_written'] = false;
        }
    }

    private function fetchRemoteRange(string $url, int $offset, int $length, array &$diagnostics): ?string
    {
        $end = $offset + $length - 1;
        $diagnostics = [
            'url' => $url,
            'range_from' => $offset,
            'range_to' => $end,
            'curl_available' => function_exists('curl_init'),
            'curl_status' => null,
            'curl_errno' => null,
            'curl_error' => null,
            'response_bytes' => 0,
            'range_total' => null,
            'content_range' => null,
            'response_sample' => null,
        ];

        if (!function_exists('curl_init')) {
            return null;
        }

        $curl = curl_init($url);

        if ($curl === false) {
            return null;
        }

        curl_setopt_array($curl, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 3,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_RANGE => $offset . '-' . $end,
            CURLOPT_HTTPHEADER => [
                'User-Agent: Lorch Update Center Agent',
                'Accept: application/zip,application/octet-stream,*/*',
            ],
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        ]);

        $response = curl_exec($curl);
        $statusCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $headerSize = (int) curl_getinfo($curl, CURLINFO_HEADER_SIZE);
        $diagnostics['curl_status'] = $statusCode;
        $diagnostics['curl_errno'] = curl_errno($curl);
        $diagnostics['curl_error'] = curl_error($curl);
        curl_close($curl);

        if (!is_string($response)) {
            return null;
        }

        $headerText = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);
        $diagnostics['response_bytes'] = strlen($body);

        if (preg_match_all('/Content-Range:\s*bytes\s+(\d+)-(\d+)\/(\d+)/i', $headerText, $matches, PREG_SET_ORDER) > 0 && $matches !== []) {
            $last = end($matches);
            $diagnostics['content_range'] = $last[0];
            $diagnostics['range_total'] = (int) $last[3];
        }

        if ($statusCode !== 206) {
            $diagnostics['response_sample'] = $this->createRemoteResponseSample($body);
            return null;
        }

        if (strlen($body) > $length + 8192) {
            $diagnostics['response_sample'] = 'Range-Antwort ist größer als erwartet.';
            return null;
        }

        return $body !== '' ? $body : null;
    }

    private function runCoreRunnerAkeebaGuard(): array
    {
        $stateDirectory = $this->resolveCoreRunnerStateDirectory();
        $result = [
            'status' => 'fail',
            'message' => 'Akeeba Backup on Update Guard wurde nicht abgeschlossen.',
            'found' => false,
            'extension_id' => null,
            'enabled_before' => null,
            'disabled_by_runner' => false,
            'db_enabled_after' => null,
            'plugin_helper_active_after' => null,
            'verified_disabled' => false,
            'state_written' => false,
        ];

        try {
            $plugin = $this->findAkeebaBackupOnUpdatePlugin();

            if ($plugin === null) {
                $result['status'] = 'ok';
                $result['message'] = 'Akeeba Backup on Update ist nicht installiert oder nicht auffindbar.';
                $result['verified_disabled'] = true;
                $this->writeCoreRunnerGuardState($stateDirectory, $result);

                return $result;
            }

            $extensionId = (int) ($plugin['extension_id'] ?? 0);
            $enabledBefore = (int) ($plugin['enabled'] ?? 0);
            $result['found'] = true;
            $result['extension_id'] = $extensionId;
            $result['enabled_before'] = $enabledBefore;

            if ($extensionId <= 0) {
                $result['message'] = 'Akeeba Backup on Update wurde gefunden, aber die Extension-ID ist ungültig.';
                $this->writeCoreRunnerGuardState($stateDirectory, $result);

                return $result;
            }

            if ($enabledBefore === 1) {
                $db = Factory::getContainer()->get(DatabaseInterface::class);
                $query = $db->getQuery(true)
                    ->update($db->quoteName('#__extensions'))
                    ->set($db->quoteName('enabled') . ' = 0')
                    ->where($db->quoteName('extension_id') . ' = ' . $extensionId)
                    ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                    ->where($db->quoteName('folder') . ' = ' . $db->quote('system'));
                $db->setQuery($query);
                $db->execute();
                $result['disabled_by_runner'] = true;
            }

            $this->clearJoomlaExtensionCaches();
            $this->invalidateAkeebaBackupOnUpdateOpcache((string) ($plugin['element'] ?? ''));

            $verified = $this->findAkeebaBackupOnUpdatePlugin();
            $dbEnabledAfter = $verified === null ? 0 : (int) ($verified['enabled'] ?? 0);
            $pluginHelperActive = $this->isExtensionEnabled('plugin', 'system', (string) ($plugin['element'] ?? ''));
            $result['db_enabled_after'] = $dbEnabledAfter;
            $result['plugin_helper_active_after'] = $pluginHelperActive;
            $result['verified_disabled'] = $dbEnabledAfter === 0 && !$pluginHelperActive;
            $result['status'] = $result['verified_disabled'] ? 'ok' : 'fail';
            $result['message'] = $result['verified_disabled']
                ? 'Akeeba Backup on Update wurde deaktiviert und verifiziert.'
                : 'Akeeba Backup on Update konnte nicht eindeutig deaktiviert werden.';
            $this->writeCoreRunnerGuardState($stateDirectory, $result);

            return $result;
        } catch (\Throwable $throwable) {
            $result['message'] = 'Akeeba Guard fehlgeschlagen: ' . $throwable->getMessage();
            $result['exception_class'] = get_class($throwable);
            $result['exception_file'] = $throwable->getFile();
            $result['exception_line'] = $throwable->getLine();
            $this->writeCoreRunnerGuardState($stateDirectory, $result);

            return $result;
        }
    }

    private function writeCoreRunnerGuardState(string $stateDirectory, array &$result): void
    {
        if (!is_dir($stateDirectory) && !@mkdir($stateDirectory, 0755, true) && !is_dir($stateDirectory)) {
            return;
        }

        @file_put_contents(rtrim($stateDirectory, '/\\') . '/.htaccess', "Require all denied\n", LOCK_EX);
        $result['state_written'] = true;
        $payload = json_encode([
            'type' => 'akeeba_guard',
            'written_at' => gmdate(DATE_ATOM),
            'result' => $result,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);

        if (!is_string($payload) || @file_put_contents(rtrim($stateDirectory, '/\\') . '/akeeba-guard.json', $payload, LOCK_EX) === false) {
            $result['state_written'] = false;
        }
    }

    private function clearJoomlaExtensionCaches(): void
    {
        try {
            Factory::getApplication()->bootComponent('com_plugins');
        } catch (\Throwable $throwable) {
        }

        if (function_exists('clearstatcache')) {
            clearstatcache(true);
        }
    }

    private function invalidateAkeebaBackupOnUpdateOpcache(string $element): void
    {
        if (!function_exists('opcache_invalidate') || $element === '') {
            return;
        }

        foreach ([
            JPATH_PLUGINS . '/system/' . $element . '/' . $element . '.php',
            JPATH_PLUGINS . '/system/' . $element . '/services/provider.php',
        ] as $path) {
            if (is_file($path)) {
                @opcache_invalidate($path, true);
            }
        }
    }

    private function resolveCoreRunnerStateDirectory(): string
    {
        return JPATH_ADMINISTRATOR . '/cache/luc-runner';
    }

    private function resolveJoomlaUpdateTempDirectory(): string
    {
        return JPATH_ADMINISTRATOR . '/components/com_joomlaupdate/tmp';
    }

    private function resolveJoomlaTempDirectory(): string
    {
        return rtrim((string) Factory::getConfig()->get('tmp_path', JPATH_ROOT . '/tmp'), '/\\');
    }

    private function ensureCoreRunnerDirectory(string $directory): bool
    {
        return $directory !== ''
            && (is_dir($directory) || @mkdir($directory, 0755, true) || is_dir($directory))
            && is_writable($directory);
    }

    private function probeCoreRunnerStateDirectory(string $stateDirectory): array
    {
        if (!$this->ensureCoreRunnerDirectory($stateDirectory)) {
            return $this->makeCheck('runner_state_writable', 'fail', 'Runner-State-Verzeichnis konnte nicht erstellt werden.', [
                'path' => $stateDirectory,
            ]);
        }

        $guardPath = rtrim($stateDirectory, '/\\') . '/.htaccess';
        $probePath = rtrim($stateDirectory, '/\\') . '/probe-' . bin2hex(random_bytes(6)) . '.json';
        @file_put_contents($guardPath, "Require all denied\n", LOCK_EX);
        $payload = json_encode(['probe' => true, 'time' => time()], JSON_UNESCAPED_SLASHES);
        $written = is_string($payload) && @file_put_contents($probePath, $payload, LOCK_EX) !== false;
        $readBack = $written ? @file_get_contents($probePath) : false;

        if (is_file($probePath)) {
            @unlink($probePath);
        }

        return $this->makeCheck(
            'runner_state_writable',
            ($written && $readBack === $payload) ? 'ok' : 'fail',
            ($written && $readBack === $payload) ? 'Runner-State ist schreib- und lesbar.' : 'Runner-State ist nicht zuverlässig schreib- und lesbar.',
            [
                'path' => $stateDirectory,
                'guard_written' => is_file($guardPath),
            ]
        );
    }

    private function probeJoomlaUpdateTempDirectory(string $directory): array
    {
        if (!$this->ensureCoreRunnerDirectory($directory)) {
            return $this->makeCheck('joomla_update_tmp_writable', 'fail', 'Joomla-Update-Temp-Verzeichnis konnte nicht erstellt oder beschrieben werden.', [
                'path' => $directory,
            ]);
        }

        $probePath = rtrim($directory, '/\\') . '/luc-runner-probe-' . bin2hex(random_bytes(6)) . '.txt';
        $payload = 'luc-runner-probe';
        $written = @file_put_contents($probePath, $payload, LOCK_EX) !== false;
        $readBack = $written ? @file_get_contents($probePath) : false;

        if (is_file($probePath)) {
            @unlink($probePath);
        }

        return $this->makeCheck(
            'joomla_update_tmp_writable',
            ($written && $readBack === $payload) ? 'ok' : 'fail',
            ($written && $readBack === $payload) ? 'Joomla-Update-Temp-Verzeichnis ist schreib- und lesbar.' : 'Joomla-Update-Temp-Verzeichnis ist nicht zuverlässig schreib- und lesbar.',
            [
                'path' => $directory,
            ]
        );
    }

    private function probeJoomlaUpdateModel(): array
    {
        try {
            $model = $this->createJoomlaUpdateModel();

            return $this->makeCheck('joomla_update_model', 'ok', 'Joomla-Update-Model konnte geladen werden.', [
                'model_class' => get_class($model),
                'has_download' => method_exists($model, 'download'),
                'has_finaliseUpgrade' => method_exists($model, 'finaliseUpgrade'),
            ]);
        } catch (\Throwable $throwable) {
            return $this->makeCheck('joomla_update_model', 'fail', 'Joomla-Update-Model konnte nicht geladen werden: ' . $throwable->getMessage());
        }
    }

    private function probeZipArchiveSupport(string $tmpPath): array
    {
        if (!class_exists(\ZipArchive::class)) {
            return $this->makeCheck('zip_archive_probe', 'fail', 'PHP ZipArchive ist nicht verfügbar.');
        }

        if ($tmpPath === '' || !is_dir($tmpPath) || !is_writable($tmpPath)) {
            return $this->makeCheck('zip_archive_probe', 'fail', 'tmp_path ist für den ZIP-Test nicht beschreibbar.', [
                'path' => $tmpPath,
            ]);
        }

        $zipPath = rtrim($tmpPath, '/\\') . '/luc-runner-probe-' . bin2hex(random_bytes(6)) . '.zip';
        $extractPath = rtrim($tmpPath, '/\\') . '/luc-runner-probe-' . bin2hex(random_bytes(6));
        $zip = new \ZipArchive();

        if ($zip->open($zipPath, \ZipArchive::CREATE) !== true) {
            return $this->makeCheck('zip_archive_probe', 'fail', 'Test-ZIP konnte nicht erzeugt werden.');
        }

        $zip->addFromString('probe.txt', 'luc-runner-probe');
        $zip->close();
        @mkdir($extractPath, 0755, true);
        $zip = new \ZipArchive();
        $opened = $zip->open($zipPath) === true;
        $extracted = $opened && $zip->extractTo($extractPath);

        if ($opened) {
            $zip->close();
        }

        $ok = $extracted && is_file($extractPath . '/probe.txt');
        @unlink($zipPath);
        @unlink($extractPath . '/probe.txt');
        @rmdir($extractPath);

        return $this->makeCheck($ok ? 'zip_archive_probe' : 'zip_archive_probe', $ok ? 'ok' : 'fail', $ok ? 'Test-ZIP konnte entpackt werden.' : 'Test-ZIP konnte nicht entpackt werden.');
    }

    private function probeRemoteJoomlaPackageAccess(string $currentVersion): array
    {
        $targetVersion = $this->fetchLatestVersionFromOfficialSources($this->majorVersion($currentVersion)) ?? '';

        if ($targetVersion === '' || !version_compare($targetVersion, $currentVersion, '>')) {
            return $this->makeCheck('joomla_package_access', 'warn', 'Kein neueres Joomla-Patchpaket für den Downloadtest ermittelt.', [
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
            ]);
        }

        $url = $this->buildOfficialUpgradePackageUrl($targetVersion);
        $diagnostics = [];
        $body = $this->fetchRemoteText($url, 'application/zip,application/octet-stream', $diagnostics);
        $ok = is_string($body) && strlen($body) > 1000;

        return $this->makeCheck($ok ? 'joomla_package_access' : 'joomla_package_access', $ok ? 'ok' : 'fail', $ok ? 'Joomla-Updatepaket ist vom Server erreichbar.' : 'Joomla-Updatepaket konnte nicht geladen werden.', [
            'target_version' => $targetVersion,
            'url' => $url,
            'diagnostics' => $this->sanitizeDiagnosticArray($diagnostics),
        ]);
    }

    private function buildUpdatePreparationData(array $config): array
    {
        $version = new Version();
        $guard = $this->ensureAkeebaBackupOnUpdateDisabled();

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'update_preparation' => [
                'status' => !empty($guard['verified_disabled']) ? 'ok' : 'fail',
                'message' => !empty($guard['verified_disabled'])
                    ? 'Update-Vorbereitung abgeschlossen: Akeeba Backup on Update ist deaktiviert.'
                    : 'Update-Vorbereitung fehlgeschlagen: Akeeba Backup on Update ist weiterhin aktiv.',
                'disableAkeebaBackupOnUpdate' => $guard,
            ],
        ];
    }

    private function buildUpdateData(array $config, array $payload): array
    {
        $version = new Version();
        $update = $this->triggerJoomlaCoreUpdate($config, $payload);

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $update['joomla_version'] ?? $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'update' => $update,
        ];
    }

    private function buildAgentUpdateData(array $config, array $payload): array
    {
        $version = new Version();
        $agentUpdate = $this->triggerAgentSelfUpdate(trim((string) ($payload['target_version'] ?? '')));

        return [
            'site_uuid' => $config['site_uuid'],
            'agent_version' => $this->getAgentVersion(),
            'joomla_version' => $version->getShortVersion(),
            'php_version' => PHP_VERSION,
            'base_url' => rtrim(Uri::root(), '/'),
            'agent_update' => $agentUpdate,
        ];
    }

    private function makeCheck(string $key, string $status, string $message, array $context = []): array
    {
        return [
            'key' => $key,
            'status' => $status,
            'message' => $message,
            'context' => $context,
        ];
    }

    private function checkJoomlaManualUpdatePath(): array
    {
        try {
            $app = Factory::getApplication();
            $component = $app->bootComponent('com_joomlaupdate');
            $mvcFactory = $component->getMVCFactory();
            $model = $mvcFactory->createModel('Update', 'Administrator', ['ignore_request' => true]);

            if (!is_object($model)) {
                return $this->makeCheck(
                    'joomla_manual_update_path',
                    'fail',
                    'com_joomlaupdate ist vorhanden, aber das Update-Model konnte nicht instanziiert werden.'
                );
            }

            $methodMap = [];
            $interestingMethods = [
                'download',
                'createRestorationFile',
                'finaliseUpgrade',
                'cleanUp',
                'applyUpdateSite',
                'upload',
                'removeExtractedUpdatePackage',
            ];

            foreach ($interestingMethods as $method) {
                $methodMap[$method] = method_exists($model, $method);
            }

            $methodSignatures = [];

            foreach ($interestingMethods as $method) {
                if (!method_exists($model, $method)) {
                    continue;
                }

                try {
                    $reflection = new \ReflectionMethod($model, $method);
                    $parameters = [];

                    foreach ($reflection->getParameters() as $parameter) {
                        $parameters[] = [
                            'name' => $parameter->getName(),
                            'optional' => $parameter->isOptional(),
                            'has_default' => $parameter->isDefaultValueAvailable(),
                        ];
                    }

                    $methodSignatures[$method] = [
                        'parameter_count' => $reflection->getNumberOfParameters(),
                        'required_parameter_count' => $reflection->getNumberOfRequiredParameters(),
                        'parameters' => $parameters,
                    ];
                } catch (\Throwable $throwable) {
                    $methodSignatures[$method] = [
                        'error' => $throwable->getMessage(),
                    ];
                }
            }

            $hasManualPath = !empty($methodMap['download'])
                && (!empty($methodMap['createRestorationFile']) || !empty($methodMap['applyUpdateSite']))
                && !empty($methodMap['finaliseUpgrade']);

            return $this->makeCheck(
                'joomla_manual_update_path',
                $hasManualPath ? 'ok' : 'warn',
                $hasManualPath
                    ? 'Der interne manuelle Joomla-Updatepfad ist auf dieser Website grundsätzlich vorhanden.'
                    : 'Der interne manuelle Joomla-Updatepfad ist auf dieser Website noch unklar oder unvollständig.',
                [
                    'model_class' => get_class($model),
                    'methods' => $methodMap,
                    'signatures' => $methodSignatures,
                ]
            );
        } catch (\Throwable $throwable) {
            return $this->makeCheck(
                'joomla_manual_update_path',
                'warn',
                'Der interne manuelle Joomla-Updatepfad konnte noch nicht sauber geprüft werden: ' . $throwable->getMessage()
            );
        }
    }

    private function checkAkeebaBackupOnUpdatePlugin(): array
    {
        try {
            $plugin = $this->findAkeebaBackupOnUpdatePlugin();

            if ($plugin === null) {
                return $this->makeCheck(
                    'akeeba_backup_on_update_disabled',
                    'ok',
                    'Akeeba Backup on Update ist nicht aktiv oder nicht installiert.'
                );
            }

            $enabled = (int) ($plugin['enabled'] ?? 0) === 1;

            return $this->makeCheck(
                'akeeba_backup_on_update_disabled',
                $enabled ? 'warn' : 'ok',
                $enabled
                    ? 'Akeeba Backup on Update ist aktiv und wird vor dem Core-Update automatisch deaktiviert.'
                    : 'Akeeba Backup on Update ist installiert, aber deaktiviert.',
                [
                    'extension_id' => (int) ($plugin['extension_id'] ?? 0),
                    'name' => (string) ($plugin['name'] ?? ''),
                    'element' => (string) ($plugin['element'] ?? ''),
                    'folder' => (string) ($plugin['folder'] ?? ''),
                    'enabled' => (int) ($plugin['enabled'] ?? 0),
                ]
            );
        } catch (\Throwable $throwable) {
            return $this->makeCheck(
                'akeeba_backup_on_update_disabled',
                'fail',
                'Akeeba Backup on Update konnte nicht sicher geprüft werden: ' . $throwable->getMessage()
            );
        }
    }

    private function isExtensionEnabled(string $type, string $folder, string $element): bool
    {
        try {
            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                ->select($db->quoteName('enabled'))
                ->from($db->quoteName('#__extensions'))
                ->where($db->quoteName('type') . ' = ' . $db->quote($type))
                ->where($db->quoteName('folder') . ' = ' . $db->quote($folder))
                ->where($db->quoteName('element') . ' = ' . $db->quote($element));
            $db->setQuery($query);

            return (int) $db->loadResult() === 1;
        } catch (\Throwable $throwable) {
            return false;
        }
    }

    private function findAkeebaBackupOnUpdatePlugin(): ?array
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('extension_id'),
                $db->quoteName('name'),
                $db->quoteName('type'),
                $db->quoteName('folder'),
                $db->quoteName('element'),
                $db->quoteName('enabled'),
            ])
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where('('
                . 'LOWER(' . $db->quoteName('name') . ') LIKE ' . $db->quote('%backup on update%')
                . ' OR LOWER(' . $db->quoteName('element') . ') LIKE ' . $db->quote('%backuponupdate%')
                . ' OR LOWER(' . $db->quoteName('element') . ') LIKE ' . $db->quote('%backup%update%')
                . ')')
            ->order($db->quoteName('enabled') . ' DESC, ' . $db->quoteName('extension_id') . ' ASC');
        $db->setQuery($query, 0, 1);
        $row = $db->loadAssoc();

        return is_array($row) ? $row : null;
    }

    private function ensureAkeebaBackupOnUpdateDisabled(): array
    {
        $details = [
            'checked' => true,
            'found' => false,
            'disabled' => false,
            'verified_disabled' => false,
            'plugin' => null,
            'message' => 'Akeeba Backup on Update ist nicht aktiv oder nicht installiert.',
        ];

        $plugin = $this->findAkeebaBackupOnUpdatePlugin();

        if ($plugin === null) {
            $details['verified_disabled'] = true;

            return $details;
        }

        $extensionId = (int) ($plugin['extension_id'] ?? 0);

        $details['found'] = true;
        $details['plugin'] = [
            'extension_id' => $extensionId,
            'name' => (string) ($plugin['name'] ?? ''),
            'element' => (string) ($plugin['element'] ?? ''),
            'folder' => (string) ($plugin['folder'] ?? ''),
            'enabled_before' => (int) ($plugin['enabled'] ?? 0),
            'disabled' => false,
            'enabled_after' => null,
        ];

        if ($extensionId <= 0) {
            $details['message'] = 'Akeeba Backup on Update wurde gefunden, aber die Extension-ID ist ungültig.';

            return $details;
        }

        if ((int) ($plugin['enabled'] ?? 0) === 1) {
            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 0')
                ->where($db->quoteName('extension_id') . ' = ' . $extensionId)
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = ' . $db->quote('system'));
            $db->setQuery($query);
            $db->execute();
            $details['disabled'] = true;
            $details['plugin']['disabled'] = true;
        }

        $verified = $this->findAkeebaBackupOnUpdatePlugin();
        $enabledAfter = $verified === null ? 0 : (int) ($verified['enabled'] ?? 0);

        $details['plugin']['enabled_after'] = $enabledAfter;
        $details['verified_disabled'] = $enabledAfter === 0;
        $details['message'] = $details['verified_disabled']
            ? 'Akeeba Backup on Update ist vor dem Core-Update deaktiviert.'
            : 'Akeeba Backup on Update ist vor dem Core-Update weiterhin aktiv.';

        return $details;
    }

    private function detectCoreUpdate(string $currentVersion): array
    {
        try {
            $extensionId = $this->findCoreExtensionId();

            if ($extensionId === null) {
                return [
                    'status' => 'fail',
                    'message' => 'Joomla-Core-Extension für die Updateprüfung nicht gefunden.',
                    'target_version' => null,
                    'has_update' => false,
                    'same_major' => null,
                ];
            }

            $updater = Updater::getInstance();
            $updater->findUpdates($extensionId, 0, Updater::STABILITY_STABLE, false);
            $updates = $updater->getAvailableUpdates($extensionId, Updater::STABILITY_STABLE);

            if (!is_array($updates) || $updates === []) {
                $fallbackVersion = $this->fetchLatestVersionFromOfficialSources($this->majorVersion($currentVersion));

                if ($fallbackVersion !== null) {
                    return $this->buildCoreUpdateResult($currentVersion, $fallbackVersion, 'official_downloads_fallback');
                }

                return [
                    'status' => 'ok',
                    'message' => 'Kein neuer Joomla-Core-Patch verfügbar.',
                    'target_version' => $currentVersion,
                    'has_update' => false,
                    'same_major' => true,
                    'source' => 'internal_updater_empty',
                ];
            }

            $targetVersion = null;

            foreach ($updates as $update) {
                if (!is_object($update)) {
                    continue;
                }

                $candidate = null;

                if (method_exists($update, 'getTargetVersion')) {
                    $candidate = (string) $update->getTargetVersion();
                }

                if (($candidate === null || $candidate === '') && method_exists($update, 'get')) {
                    $candidate = (string) $update->get('version');
                }

                if ($candidate === '') {
                    continue;
                }

                if ($targetVersion === null || version_compare($candidate, $targetVersion, '>')) {
                    $targetVersion = $candidate;
                }
            }

            if ($targetVersion === null) {
                return [
                    'status' => 'fail',
                    'message' => 'Updateprüfung lieferte kein verwertbares Ziel.',
                    'target_version' => null,
                    'has_update' => false,
                    'same_major' => null,
                ];
            }

            $fallbackVersion = $this->fetchLatestVersionFromOfficialSources($this->majorVersion($currentVersion));

            if ($fallbackVersion !== null && version_compare($fallbackVersion, $targetVersion, '>')) {
                return $this->buildCoreUpdateResult($currentVersion, $fallbackVersion, 'official_update_feed_fallback');
            }

            return $this->buildCoreUpdateResult($currentVersion, $targetVersion, 'internal_updater');
        } catch (\Throwable $throwable) {
            $fallbackVersion = $this->fetchLatestVersionFromOfficialSources($this->majorVersion($currentVersion));

            if ($fallbackVersion !== null) {
                return $this->buildCoreUpdateResult($currentVersion, $fallbackVersion, 'official_downloads_fallback');
            }

            return [
                'status' => 'fail',
                'message' => 'Core-Updateprüfung fehlgeschlagen: ' . $throwable->getMessage(),
                'target_version' => null,
                'has_update' => false,
                'same_major' => null,
                'source' => 'internal_updater_failed',
            ];
        }
    }

    private function findCoreExtensionId(): ?int
    {
        try {
            $db = Factory::getContainer()->get(DatabaseInterface::class);

            $candidates = [
                ['type' => 'file', 'element' => 'joomla', 'folder' => ''],
                ['type' => 'package', 'element' => 'pkg_joomla', 'folder' => ''],
                ['type' => 'component', 'element' => 'com_joomlaupdate', 'folder' => ''],
            ];

            foreach ($candidates as $candidate) {
                $query = $db->getQuery(true)
                    ->select($db->quoteName('extension_id'))
                    ->from($db->quoteName('#__extensions'))
                    ->where($db->quoteName('type') . ' = ' . $db->quote($candidate['type']))
                    ->where($db->quoteName('element') . ' = ' . $db->quote($candidate['element']));

                if ($candidate['folder'] !== '') {
                    $query->where($db->quoteName('folder') . ' = ' . $db->quote($candidate['folder']));
                }

                $db->setQuery($query);
                $result = (int) $db->loadResult();

                if ($result > 0) {
                    return $result;
                }
            }

            return null;
        } catch (\Throwable $throwable) {
            return null;
        }
    }

    private function majorVersion(string $version): int
    {
        return (int) explode('.', $version)[0];
    }

    private function buildCoreUpdateResult(string $currentVersion, string $targetVersion, string $source): array
    {
        $sameMajor = $this->majorVersion($currentVersion) === $this->majorVersion($targetVersion);

        if (!version_compare($targetVersion, $currentVersion, '>')) {
            return [
                'status' => 'ok',
                'message' => 'Joomla-Core ist bereits auf dem aktuellen Stand.',
                'target_version' => $currentVersion,
                'has_update' => false,
                'same_major' => $sameMajor,
                'source' => $source,
            ];
        }

        return [
            'status' => $sameMajor ? 'ok' : 'warn',
            'message' => $sameMajor
                ? 'Verfügbares Joomla-Core-Update erkannt: ' . $currentVersion . ' -> ' . $targetVersion
                : 'Verfügbares Core-Update erkannt, aber außerhalb derselben Major-Version: ' . $currentVersion . ' -> ' . $targetVersion,
            'target_version' => $targetVersion,
            'has_update' => true,
            'same_major' => $sameMajor,
            'source' => $source,
        ];
    }

    private function fetchLatestVersionFromOfficialSources(int $major): ?string
    {
        $versions = [];
        $feedVersion = $this->fetchLatestVersionFromJoomlaUpdateFeed($major);

        if ($feedVersion !== null) {
            $versions[] = $feedVersion;
        }

        $downloadsVersion = $this->fetchLatestVersionFromDownloads($major);

        if ($downloadsVersion !== null) {
            $versions[] = $downloadsVersion;
        }

        if ($versions === []) {
            return null;
        }

        usort($versions, 'version_compare');

        return end($versions) ?: null;
    }

    private function fetchLatestVersionFromJoomlaUpdateFeed(int $major): ?string
    {
        if (!in_array($major, [5, 6], true)) {
            return null;
        }

        $xml = $this->fetchRemoteText('https://update.joomla.org/core/list.xml', 'application/xml,text/xml');

        if ($xml === null || !preg_match_all('/\bversion="(' . $major . '\.\d+\.\d+)"/u', $xml, $matches)) {
            return null;
        }

        $latestVersion = null;

        foreach ($matches[1] as $candidate) {
            $candidate = trim((string) $candidate);

            if ($candidate === '') {
                continue;
            }

            if ($latestVersion === null || version_compare($candidate, $latestVersion, '>')) {
                $latestVersion = $candidate;
            }
        }

        return $latestVersion;
    }

    private function fetchLatestVersionFromDownloads(int $major): ?string
    {
        if (!in_array($major, [5, 6], true)) {
            return null;
        }

        try {
            $html = $this->fetchRemoteText('https://downloads.joomla.org/latest', 'text/html,application/xhtml+xml');

            if (!is_string($html) || trim($html) === '') {
                return null;
            }

            if (!preg_match_all('/Joomla!\s+' . $major . '\.\d+\.\d+/u', $html, $matches)) {
                return null;
            }

            $latestVersion = null;

            foreach ($matches[0] as $rawMatch) {
                $candidate = trim(str_replace('Joomla!', '', (string) $rawMatch));

                if ($candidate === '') {
                    continue;
                }

                if ($latestVersion === null || version_compare($candidate, $latestVersion, '>')) {
                    $latestVersion = $candidate;
                }
            }

            return $latestVersion;
        } catch (\Throwable $throwable) {
            return null;
        }
    }

    private function fetchRemoteText(string $url, string $acceptHeader, ?array &$diagnostics = null): ?string
    {
        $diagnostics = [
            'url' => $url,
            'curl_available' => function_exists('curl_init'),
            'request_method' => 'GET',
            'request_http_version' => '1.1',
            'request_content_type' => 'suppressed',
            'curl_status' => null,
            'curl_errno' => null,
            'curl_error' => null,
            'stream_status' => null,
            'stream_error' => null,
            'response_bytes' => 0,
            'response_sample' => null,
        ];
        $headers = [
            'User-Agent: Lorch Update Center Agent',
            'Accept: ' . $acceptHeader . ', */*',
        ];
        $curlHeaders = array_merge($headers, [
            'Content-Type:',
        ]);

        if (function_exists('curl_init')) {
            $curl = curl_init($url);

            if ($curl !== false) {
                curl_setopt_array($curl, [
                    CURLOPT_HTTPGET => true,
                    CURLOPT_POST => false,
                    CURLOPT_NOBODY => false,
                    CURLOPT_UPLOAD => false,
                    CURLOPT_RETURNTRANSFER => true,
                    CURLOPT_FOLLOWLOCATION => true,
                    CURLOPT_MAXREDIRS => 3,
                    CURLOPT_CONNECTTIMEOUT => 10,
                    CURLOPT_TIMEOUT => 20,
                    CURLOPT_HTTPHEADER => $curlHeaders,
                    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                ]);

                $body = curl_exec($curl);
                $statusCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
                $diagnostics['curl_status'] = $statusCode;
                $diagnostics['curl_errno'] = curl_errno($curl);
                $diagnostics['curl_error'] = curl_error($curl);
                curl_close($curl);

                if (is_string($body) && trim($body) !== '' && $statusCode >= 200 && $statusCode < 300) {
                    $diagnostics['response_bytes'] = strlen($body);
                    return $body;
                }

                if (is_string($body)) {
                    $diagnostics['response_bytes'] = strlen($body);
                    $diagnostics['response_sample'] = $this->createRemoteResponseSample($body);
                }
            }
        }

        $previousError = error_get_last();
        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'timeout' => 20,
                'header' => implode("\r\n", $headers) . "\r\n",
            ],
        ]);
        $body = @file_get_contents($url, false, $context);
        $lastError = error_get_last();

        if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', (string) $http_response_header[0], $matches)) {
            $diagnostics['stream_status'] = (int) $matches[1];
        }

        if ($lastError !== $previousError && is_array($lastError)) {
            $diagnostics['stream_error'] = (string) ($lastError['message'] ?? '');
        }

        if (is_string($body)) {
            $diagnostics['response_bytes'] = strlen($body);
            $diagnostics['response_sample'] = $this->createRemoteResponseSample($body);
        }

        return is_string($body) && trim($body) !== '' ? $body : null;
    }

    private function createRemoteResponseSample(string $body): ?string
    {
        $sample = trim(substr($body, 0, 300));

        if ($sample === '') {
            return null;
        }

        if (function_exists('mb_check_encoding') && !mb_check_encoding($sample, 'UTF-8')) {
            return '[binäre oder nicht UTF-8-kodierte Antwort]';
        }

        return preg_replace('/\s+/', ' ', $sample);
    }

    private function triggerAgentSelfUpdate(string $requestedTargetVersion): array
    {
        $details = [
            'driver' => 'joomla_installer_update_model',
            'feed_url' => 'https://updates.lorch-webdesign.com/plg_system_lorchupdate.xml',
            'download_url' => null,
            'current_version' => $this->getAgentVersion(),
            'target_version' => null,
            'requested_target_version' => $requestedTargetVersion,
            'extension' => null,
            'update_id' => null,
        ];

        try {
            if (!$this->isSupportedVersionString($requestedTargetVersion)) {
                throw new \RuntimeException('Die angeforderte Agent-Zielversion ist ungültig.');
            }

            $extension = $this->findOwnAgentExtension();
            $details['extension'] = $extension;

            if ($extension === null) {
                return [
                    'status' => 'fail',
                    'message' => 'LUC-Agent-Extension wurde lokal nicht eindeutig gefunden.',
                    'details' => $details,
                ];
            }

            $extensionId = (int) ($extension['extension_id'] ?? 0);

            if ($extensionId <= 0) {
                throw new \RuntimeException('Die Extension-ID des LUC-Agenten ist ungültig.');
            }

            $updater = Updater::getInstance();
            $updater->findUpdates($extensionId, 0, Updater::STABILITY_STABLE, false);
            $update = $this->findOwnAgentUpdateRecord($extensionId);

            if ($update === null) {
                $alreadyCurrent = version_compare($details['current_version'], $requestedTargetVersion, '>=');

                return [
                    'status' => $alreadyCurrent ? 'ok' : 'fail',
                    'message' => $alreadyCurrent
                        ? 'LUC-Agent ist bereits mindestens auf der angeforderten Zielversion.'
                        : 'Joomla konnte die angeforderte LUC-Agent-Zielversion nicht als Update erkennen.',
                    'details' => $details,
                ];
            }

            $details['update_id'] = (int) ($update['update_id'] ?? 0);
            $details['target_version'] = (string) ($update['version'] ?? '');
            $details['update_details_url'] = (string) ($update['detailsurl'] ?? '');

            if ($details['update_id'] <= 0 || !$this->isSupportedVersionString($details['target_version'])) {
                throw new \RuntimeException('Joomla hat keinen gültigen Update-Datensatz für den LUC-Agenten erzeugt.');
            }

            if (version_compare($details['target_version'], $requestedTargetVersion, '<')) {
                throw new \RuntimeException('Joomla hat nur eine ältere als die angeforderte Agent-Zielversion gefunden.');
            }

            $app = Factory::getApplication();
            $component = $app->bootComponent('com_installer');
            $model = $component->getMVCFactory()->createModel('Update', 'Administrator', ['ignore_request' => true]);

            if (!is_object($model) || !method_exists($model, 'update')) {
                throw new \RuntimeException('Das Joomla-Modell für Erweiterungsupdates konnte nicht geladen werden.');
            }

            $model->update([$details['update_id']], Updater::STABILITY_STABLE);
            $result = method_exists($model, 'getState') ? (bool) $model->getState('result') : false;

            if (!$result) {
                return [
                    'status' => 'fail',
                    'message' => 'Joomlas regulärer Erweiterungs-Updater konnte das LUC-Agent-Update nicht installieren.',
                    'details' => $details,
                ];
            }

            clearstatcache(true);

            if (function_exists('opcache_invalidate')) {
                @opcache_invalidate(__FILE__, true);
                @opcache_invalidate(__DIR__ . '/lorchupdate.xml', true);
            }

            return [
                'status' => 'ok',
                'message' => 'LUC-Agent-Update wurde über Joomlas regulären Erweiterungs-Updater installiert. Die Version wird per separatem Ping bestätigt.',
                'details' => $details,
            ];
        } catch (\Throwable $throwable) {
            $details['exception'] = $throwable->getMessage();
            $details['exception_class'] = get_class($throwable);

            return [
                'status' => 'fail',
                'message' => 'LUC-Agent-Update fehlgeschlagen: ' . $throwable->getMessage(),
                'details' => $details,
            ];
        }
    }

    private function findOwnAgentExtension(): ?array
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('extension_id'),
                $db->quoteName('type'),
                $db->quoteName('folder'),
                $db->quoteName('element'),
                $db->quoteName('enabled'),
                $db->quoteName('manifest_cache'),
            ])
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('lorchupdate'))
            ->setLimit(1);
        $db->setQuery($query);
        $row = $db->loadAssoc();

        return is_array($row) ? [
            'extension_id' => (int) ($row['extension_id'] ?? 0),
            'type' => (string) ($row['type'] ?? ''),
            'folder' => (string) ($row['folder'] ?? ''),
            'element' => (string) ($row['element'] ?? ''),
            'enabled' => (int) ($row['enabled'] ?? 0),
        ] : null;
    }

    private function findOwnAgentUpdateRecord(int $extensionId): ?array
    {
        $db = Factory::getContainer()->get(DatabaseInterface::class);
        $query = $db->getQuery(true)
            ->select([
                $db->quoteName('update_id'),
                $db->quoteName('version'),
                $db->quoteName('detailsurl'),
            ])
            ->from($db->quoteName('#__updates'))
            ->where($db->quoteName('extension_id') . ' = :extensionId')
            ->bind(':extensionId', $extensionId, ParameterType::INTEGER)
            ->order($db->quoteName('update_id') . ' DESC');
        $db->setQuery($query, 0, 1);
        $row = $db->loadAssoc();

        return is_array($row) ? $row : null;
    }

    private function triggerJoomlaCoreUpdate(array $config, array $payload): array
    {
        $currentVersion = (new Version())->getShortVersion();
        $targetVersion = trim((string) ($payload['target_version'] ?? ''));
        $command = strtolower(trim((string) ($payload['update_command'] ?? 'start')));

        if ($targetVersion === '') {
            return [
                'status' => 'fail',
                'message' => 'Zielversion für das Core-Update fehlt.',
                'current_version' => $currentVersion,
                'target_version' => null,
                'details' => [],
            ];
        }

        try {
            return $command === 'step'
                ? $this->stepLocalJoomlaCoreUpdate($currentVersion, $targetVersion, $payload)
                : $this->startLocalJoomlaCoreUpdate($currentVersion, $targetVersion);
        } catch (\Throwable $throwable) {
            $details = [
                'exception' => $throwable->getMessage(),
                'exception_class' => get_class($throwable),
                'exception_file' => $throwable->getFile(),
                'exception_line' => $throwable->getLine(),
                'joomla_logs' => $this->collectJoomlaLogTail(['joomla_update.php', 'error.php']),
            ];

            return [
                'status' => 'fail',
                'message' => 'Joomla-Core-Update fehlgeschlagen: ' . $throwable->getMessage(),
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $this->sanitizeDiagnosticArray($details),
            ];
        }

        $token = trim((string) ($config['joomla_update_token'] ?? ''));

        if ($targetVersion === '') {
            return [
                'status' => 'fail',
                'message' => 'Zielversion für das Core-Update fehlt.',
                'current_version' => $currentVersion,
                'target_version' => null,
                'prepare' => null,
                'finalize' => null,
            ];
        }

        if ($token === '') {
            return [
                'status' => 'fail',
                'message' => 'Joomla-Update-Token fehlt im Agenten.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'prepare' => null,
                'finalize' => null,
            ];
        }

        try {
            $this->requestJoomlaUpdateApi('GET', '/api/index.php/v1/joomlaupdate/healthcheck', $token);
            $prepareResponse = $this->requestJoomlaUpdateApi(
                'POST',
                '/api/index.php/v1/joomlaupdate/prepareUpdate',
                $token,
                ['targetVersion' => $targetVersion]
            );
            $prepareAttributes = $this->extractJoomlaUpdateApiAttributes($prepareResponse);

            if (!($prepareAttributes['success'] ?? false)) {
                return [
                    'status' => 'fail',
                    'message' => 'Joomla-Core-Update konnte nicht vorbereitet werden.',
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'prepare' => $prepareAttributes,
                    'finalize' => null,
                ];
            }

            $finalizeResponse = $this->requestJoomlaUpdateApi(
                'POST',
                '/api/index.php/v1/joomlaupdate/finalizeUpdate',
                $token
            );
            $finalizeAttributes = $this->extractJoomlaUpdateApiAttributes($finalizeResponse);

            if (!($finalizeAttributes['success'] ?? false)) {
                $errors = is_array($finalizeAttributes['errors'] ?? null) ? $finalizeAttributes['errors'] : [];

                return [
                    'status' => 'fail',
                    'message' => $errors !== []
                        ? 'Joomla-Core-Update wurde vorbereitet, aber nicht sauber finalisiert: ' . implode(' | ', $errors)
                        : 'Joomla-Core-Update wurde vorbereitet, aber die Finalisierung ist fehlgeschlagen.',
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'prepare' => $prepareAttributes,
                    'finalize' => $finalizeAttributes,
                ];
            }

            $newVersion = (new Version())->getShortVersion();

            return [
                'status' => 'ok',
                'message' => 'Joomla-Core-Update erfolgreich abgeschlossen: ' . $currentVersion . ' -> ' . $newVersion,
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'joomla_version' => $newVersion,
                'prepare' => $prepareAttributes,
                'finalize' => $finalizeAttributes,
            ];
        } catch (\Throwable $throwable) {
            return [
                'status' => 'fail',
                'message' => 'Joomla-Core-Update fehlgeschlagen: ' . $throwable->getMessage(),
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'prepare' => null,
                'finalize' => null,
            ];
        }
    }

    private function startLocalJoomlaCoreUpdate(string $currentVersion, string $targetVersion): array
    {
        $details = [
            'driver' => 'joomla_connector_style_flow',
            'steps' => [],
        ];
        $lastStep = 'init';
        $coreUpdate = $this->detectCoreUpdate($currentVersion);

        if (
            (($coreUpdate['status'] ?? 'fail') !== 'ok' || empty($coreUpdate['has_update']) || empty($coreUpdate['same_major']))
            && $this->isAllowedTargetVersion($currentVersion, $targetVersion)
        ) {
            $coreUpdate = $this->buildCoreUpdateResult($currentVersion, $targetVersion, 'webapp_target_fallback');
            $details['steps']['target_version_fallback'] = [
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'source' => 'webapp_target_fallback',
            ];
        }

        if (($coreUpdate['status'] ?? 'fail') !== 'ok' || empty($coreUpdate['has_update']) || empty($coreUpdate['same_major'])) {
            return [
                'status' => 'fail',
                'message' => 'Es liegt kein zulässiges Joomla-Core-Patch-Update vor.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        $lastStep = 'disable_akeeba_backup_on_update';
        $details['steps']['disableAkeebaBackupOnUpdate'] = $this->ensureAkeebaBackupOnUpdateDisabled();

        if (empty($details['steps']['disableAkeebaBackupOnUpdate']['verified_disabled'])) {
            return [
                'status' => 'fail',
                'message' => 'Akeeba Backup on Update konnte vor dem Core-Update nicht sicher deaktiviert werden.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        $model = $this->createJoomlaUpdateModel();

        if (method_exists($model, 'applyUpdateSite')) {
            $lastStep = 'applyUpdateSite';
            $details['steps']['applyUpdateSite'] = $this->normalizeMethodResult($this->invokeModelMethod($model, 'applyUpdateSite', [[], [$targetVersion]]));
        }

        if (method_exists($model, 'refreshUpdates')) {
            $lastStep = 'refreshUpdates';
            $details['steps']['refreshUpdates'] = $this->normalizeMethodResult($this->invokeModelMethod($model, 'refreshUpdates', [[true], []]));
        }

        $lastStep = 'getUpdateInformation';
        $updateInformation = $this->loadJoomlaUpdateInformation($model);
        $details['steps']['getUpdateInformation'] = $this->normalizeMethodResult($updateInformation);

        if (!$this->hasUsableDownloadInformation($updateInformation)) {
            return [
                'status' => 'fail',
                'message' => 'Joomla liefert lokal noch keine verwertbare Updateinformation.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        $lastStep = 'download';
        $downloadResult = $this->invokeModelMethod($model, 'download', [[]]);
        $details['steps']['download'] = $this->normalizeMethodResult($downloadResult);

        if ($this->isFailedResult($downloadResult)) {
            return [
                'status' => 'fail',
                'message' => 'Der Download des Joomla-Upgrade-Pakets ist fehlgeschlagen.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        $lastStep = 'createLocalUpdateFile';
        $password = $this->createLocalUpdateFile($model, $details);
        $stateId = bin2hex(random_bytes(16));
        $state = [
            'id' => $stateId,
            'current_version' => $currentVersion,
            'target_version' => $targetVersion,
            'password' => $password,
            'factory' => null,
            'phase' => 'extract',
            'details' => $details,
        ];

        try {
            $lastStep = 'extract_start';
            $extractResponse = $this->callLocalUpdateBridge(
                'startRestore',
                $this->normalizeScalarString($state['password'] ?? null),
                $this->normalizeFactoryState($state['factory'] ?? null)
            );
            $state['details']['steps']['extract_start'] = $extractResponse['summary'];

            if (!$extractResponse['success']) {
                $this->deleteLocalUpdateState($stateId);

                return [
                    'status' => 'fail',
                    'message' => 'Die lokale Joomla-Extraktion konnte nicht gestartet werden.',
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'details' => $this->withFailureDiagnostics($state['details'], 'extract_start'),
                ];
            }
        } catch (\Throwable $throwable) {
            $details['last_step'] = $lastStep;
            $details['exception_file'] = $throwable->getFile();
            $details['exception_line'] = $throwable->getLine();
            $details['exception_class'] = get_class($throwable);
            $details['steps'][$lastStep] = [
                'exception' => $throwable->getMessage(),
            ];

            return [
                'status' => 'fail',
                'message' => 'Die lokale Joomla-Extraktion konnte nicht gestartet werden: ' . $throwable->getMessage(),
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $this->withFailureDiagnostics($details, $lastStep),
            ];
        }

        $state['factory'] = $extractResponse['factory'];
        $state['phase'] = $extractResponse['needs_more_steps'] ? 'extract' : 'finalize';
        $this->writeLocalUpdateState($stateId, $state);

        if ($state['phase'] === 'finalize') {
            return $this->stepLocalJoomlaCoreUpdate($currentVersion, $targetVersion, [
                'update_state_id' => $stateId,
                'target_version' => $targetVersion,
            ]);
        }

        return [
            'status' => 'running',
            'message' => 'Joomla-Update wurde lokal vorbereitet und die Extraktion läuft weiter.',
            'current_version' => $currentVersion,
            'target_version' => $targetVersion,
            'update_state_id' => $stateId,
            'details' => $state['details'],
        ];
    }

    private function stepLocalJoomlaCoreUpdate(string $currentVersion, string $targetVersion, array $payload): array
    {
        $lastStep = 'load_state';
        $stateId = trim((string) ($payload['update_state_id'] ?? ''));

        if ($stateId === '') {
            return [
                'status' => 'fail',
                'message' => 'Lokaler Update-Status fehlt.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => [],
            ];
        }

        $state = $this->readLocalUpdateState($stateId);

        if ($state === null) {
            return [
                'status' => 'fail',
                'message' => 'Lokaler Update-Status wurde nicht gefunden.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => [],
            ];
        }

        if (($state['phase'] ?? '') === 'extract') {
            try {
                $lastStep = 'extract_step';
                $extractResponse = $this->callLocalUpdateBridge(
                    'stepRestore',
                    $this->normalizeScalarString($state['password'] ?? null),
                    $this->normalizeFactoryState($state['factory'] ?? null)
                );
                $state['details']['steps']['extract_step'] = $extractResponse['summary'];
            } catch (\Throwable $throwable) {
                $state['details']['last_step'] = $lastStep;
                $state['details']['exception_file'] = $throwable->getFile();
                $state['details']['exception_line'] = $throwable->getLine();
                $state['details']['exception_class'] = get_class($throwable);
                $state['details']['steps'][$lastStep] = [
                    'exception' => $throwable->getMessage(),
                ];
                $this->deleteLocalUpdateState($stateId);

                return [
                    'status' => 'fail',
                    'message' => 'Die lokale Joomla-Extraktion ist bei einem Teilschritt fehlgeschlagen: ' . $throwable->getMessage(),
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'details' => $this->withFailureDiagnostics($state['details'], $lastStep),
                ];
            }

            if (!$extractResponse['success']) {
                $this->deleteLocalUpdateState($stateId);

                return [
                    'status' => 'fail',
                    'message' => 'Die lokale Joomla-Extraktion ist fehlgeschlagen.',
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'details' => $this->withFailureDiagnostics($state['details'], 'extract_step'),
                ];
            }

            $state['factory'] = $extractResponse['factory'] ?? $state['factory'];

            if ($extractResponse['needs_more_steps']) {
                $this->writeLocalUpdateState($stateId, $state);

                return [
                    'status' => 'running',
                    'message' => 'Die lokale Joomla-Extraktion läuft weiter.',
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'update_state_id' => $stateId,
                    'details' => $state['details'],
                ];
            }

            $state['phase'] = 'finalize';
            $this->writeLocalUpdateState($stateId, $state);
        }

        try {
            $lastStep = 'extract_finalize';
            $finalizeExtract = $this->callLocalUpdateBridge(
                'finalizeRestore',
                $this->normalizeScalarString($state['password'] ?? null),
                $this->normalizeFactoryState($state['factory'] ?? null)
            );
            $state['details']['steps']['extract_finalize'] = $finalizeExtract['summary'];
        } catch (\Throwable $throwable) {
            $state['details']['last_step'] = $lastStep;
            $state['details']['exception_file'] = $throwable->getFile();
            $state['details']['exception_line'] = $throwable->getLine();
            $state['details']['exception_class'] = get_class($throwable);
            $state['details']['steps'][$lastStep] = [
                'exception' => $throwable->getMessage(),
            ];
            $this->deleteLocalUpdateState($stateId);

            return [
                'status' => 'fail',
                'message' => 'Die lokale Joomla-Extraktion konnte nicht finalisiert werden: ' . $throwable->getMessage(),
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $this->withFailureDiagnostics($state['details'], $lastStep),
            ];
        }

        if (!$finalizeExtract['success']) {
            $this->deleteLocalUpdateState($stateId);

            return [
                'status' => 'fail',
                'message' => 'Die lokale Joomla-Extraktion konnte nicht finalisiert werden.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $this->withFailureDiagnostics($state['details'], 'extract_finalize'),
            ];
        }

        $lastStep = 'finaliseUpgrade';
        $model = $this->createJoomlaUpdateModel();
        $finaliseUpgrade = $this->invokeModelMethod($model, 'finaliseUpgrade', [[]]);
        $state['details']['steps']['finaliseUpgrade'] = $this->normalizeMethodResult($finaliseUpgrade);

        if ($this->isFailedResult($finaliseUpgrade)) {
            $this->deleteLocalUpdateState($stateId);

            return [
                'status' => 'fail',
                'message' => 'Die Finalisierung des Joomla-Core-Updates ist fehlgeschlagen.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $this->withFailureDiagnostics($state['details'], 'finaliseUpgrade'),
            ];
        }

        if (method_exists($model, 'cleanUp')) {
            $state['details']['steps']['cleanUp'] = $this->normalizeMethodResult($this->invokeModelMethod($model, 'cleanUp', [[]]));
        }

        if (file_exists(JPATH_BASE . '/administrator/cache/autoload_psr4.php')) {
            @unlink(JPATH_BASE . '/administrator/cache/autoload_psr4.php');
        }

        $this->deleteLocalUpdateState($stateId);
        $postcheck = $this->waitForInstalledJoomlaVersionChange($currentVersion, $targetVersion, 12, 500000);
        $freshVersion = $postcheck['fresh_version'];
        $loadedVersion = $postcheck['loaded_version'];
        $newVersion = $postcheck['effective_version'];
        $state['details']['steps']['postcheck_version'] = [
            'fresh_version' => $freshVersion,
            'loaded_version' => $loadedVersion,
            'effective_version' => $newVersion,
            'attempts' => $postcheck['attempts'],
        ];

        $updateSucceeded = $newVersion !== '' && version_compare($newVersion, $currentVersion, '>');

        return [
            'status' => $updateSucceeded ? 'ok' : 'fail',
            'message' => version_compare($newVersion, $currentVersion, '>')
                ? 'Joomla-Core-Update erfolgreich abgeschlossen: ' . $currentVersion . ' -> ' . $newVersion
                : 'Der lokale Joomla-Updateflow lief durch, aber die Joomla-Version hat sich nicht geändert.',
            'current_version' => $currentVersion,
            'target_version' => $targetVersion,
            'joomla_version' => $newVersion,
            'details' => $updateSucceeded ? $state['details'] : $this->withFailureDiagnostics($state['details'], 'postcheck_version'),
        ];
    }

    private function createLocalUpdateFile(object $model, array &$details): string
    {
        if (!method_exists($model, 'createUpdateFile')) {
            $restorationSetup = ['kickstart.security.password' => ''];
            $this->invokeModelMethod($model, 'createRestorationFile', [[]]);
            $details['steps']['createRestorationFile'] = ['status' => 'ok'];

            if (!defined('_AKEEBA_RESTORATION')) {
                define('_AKEEBA_RESTORATION', 1);
            }

            require JPATH_ADMINISTRATOR . '/components/com_joomlaupdate/restoration.php';

            return $this->normalizeScalarString($restorationSetup['kickstart.security.password'] ?? '');
        }

        $extractionSetup = ['security.password' => ''];
        $this->invokeModelMethod($model, 'createUpdateFile', [[]]);
        $details['steps']['createUpdateFile'] = ['status' => 'ok'];

        if (!defined('_JOOMLA_UPDATE')) {
            define('_JOOMLA_UPDATE', 1);
        }

        require JPATH_ADMINISTRATOR . '/components/com_joomlaupdate/update.php';

        return $this->normalizeScalarString($extractionSetup['security.password'] ?? '');
    }

    private function callLocalUpdateBridge(string $task, string $password, ?string $factory = null): array
    {
        $bridgeUrl = rtrim(Uri::root(), '/') . '/plugins/system/lorchupdate/restore.php';
        $timestamp = time();
        $nonce = bin2hex(random_bytes(16));
        $payload = [
            'task' => $task,
            'update_password' => $password,
        ];

        if ($factory !== null && $factory !== '') {
            $payload['factory'] = $factory;
        }

        $canonical = implode("\n", [
            $task,
            (string) $timestamp,
            $nonce,
            $password,
            $factory ?? '',
        ]);

        $response = $this->httpPostForm($bridgeUrl, [
            'json' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'bridge_timestamp' => (string) $timestamp,
            'bridge_nonce' => $nonce,
            'bridge_signature' => hash_hmac('sha256', $canonical, $password),
        ], 120);
        $responseBody = (string) ($response['body'] ?? '');
        $cleanBody = ltrim((string) preg_replace('/^#+/', '', trim($responseBody)));
        $decoded = json_decode($cleanBody, true);
        $baseSummary = [
            'task' => $task,
            'http_status' => (int) ($response['status_code'] ?? 0),
            'body_bytes' => strlen($responseBody),
        ];

        if (!is_array($decoded)) {
            return [
                'success' => false,
                'needs_more_steps' => false,
                'factory' => $factory,
                'summary' => $baseSummary + [
                    'json_error' => json_last_error_msg(),
                    'raw_excerpt' => $this->truncateDiagnosticString($cleanBody, 4000),
                ],
            ];
        }

        $status = $decoded['status'] ?? null;
        $success = !($status === false || $status === 'false' || $status === 'error');
        $needsMoreSteps = false;

        if (array_key_exists('done', $decoded)) {
            $needsMoreSteps = !$decoded['done'];
        } elseif (isset($decoded['percent']) && is_numeric($decoded['percent'])) {
            $needsMoreSteps = (float) $decoded['percent'] < 100;
        } elseif (!empty($decoded['factory']) || !empty($decoded['instance'])) {
            $needsMoreSteps = true;
        }

        return [
            'success' => $success,
            'needs_more_steps' => $needsMoreSteps,
            'factory' => $this->normalizeFactoryState($decoded['factory'] ?? $decoded['instance'] ?? $factory ?? null),
            'summary' => $this->sanitizeDiagnosticArray($baseSummary + $decoded),
        ];
    }

    private function withFailureDiagnostics(array $details, string $lastStep): array
    {
        $details['last_step'] = $details['last_step'] ?? $lastStep;
        $details['joomla_logs'] = $this->collectJoomlaLogTail(['joomla_update.php', 'error.php']);

        return $this->sanitizeDiagnosticArray($details);
    }

    private function collectJoomlaLogTail(array $preferredFiles): array
    {
        $logPath = (string) Factory::getConfig()->get('log_path', '');

        if ($logPath === '' || !is_dir($logPath)) {
            return [
                'status' => 'unavailable',
                'message' => 'Joomla-Logpfad ist nicht lesbar.',
            ];
        }

        $allowedFiles = array_values(array_unique(array_merge($preferredFiles, [
            'joomla_update.php',
            'error.php',
            'everything.php',
        ])));
        $entries = [];
        $totalBytes = 0;

        foreach ($allowedFiles as $fileName) {
            $safeName = basename((string) $fileName);

            if ($safeName === '' || !preg_match('/^[a-z0-9_.-]+\\.php$/i', $safeName)) {
                continue;
            }

            $path = rtrim($logPath, '/\\') . '/' . $safeName;

            if (!is_file($path) || !is_readable($path)) {
                continue;
            }

            $content = @file_get_contents($path, false, null, -20000);

            if (!is_string($content) || $content === '') {
                continue;
            }

            $lines = preg_split('/\\R/', trim($content));
            $tail = array_slice(is_array($lines) ? $lines : [], -40);
            $tail = array_map(fn ($line) => $this->truncateDiagnosticString((string) $line, 800), $tail);
            $bytes = strlen(implode("\n", $tail));

            if ($totalBytes + $bytes > 20000) {
                break;
            }

            $entries[$safeName] = $tail;
            $totalBytes += $bytes;
        }

        return $entries === []
            ? ['status' => 'empty', 'message' => 'Keine lesbaren Joomla-Logzeilen gefunden.']
            : $this->sanitizeDiagnosticArray($entries);
    }

    private function sanitizeDiagnosticArray(array $value): array
    {
        $sanitized = [];

        foreach ($value as $key => $item) {
            $keyString = is_string($key) ? $key : (string) $key;

            if ($this->isSensitiveDiagnosticKey($keyString)) {
                $sanitized[$key] = '[redacted]';
                continue;
            }

            if (is_array($item)) {
                $sanitized[$key] = $this->sanitizeDiagnosticArray($item);
                continue;
            }

            if (is_object($item)) {
                $sanitized[$key] = $this->sanitizeDiagnosticArray($this->normalizeMethodResult($item));
                continue;
            }

            if (is_string($item)) {
                $sanitized[$key] = $this->truncateDiagnosticString($item, 4000);
                continue;
            }

            $sanitized[$key] = $item;
        }

        return $sanitized;
    }

    private function isSensitiveDiagnosticKey(string $key): bool
    {
        return preg_match('/(password|secret|token|signature|authorization|auth|key|nonce|factory|instance)/i', $key) === 1;
    }

    private function truncateDiagnosticString(string $value, int $maxLength): string
    {
        if (strlen($value) <= $maxLength) {
            return $value;
        }

        return substr($value, 0, $maxLength) . '... [gekürzt]';
    }

    private function normalizeFactoryState(mixed $factory): ?string
    {
        if ($factory === null) {
            return null;
        }

        if (is_string($factory)) {
            return $factory;
        }

        if (is_scalar($factory)) {
            return (string) $factory;
        }

        if (is_array($factory) || is_object($factory)) {
            $json = json_encode($factory, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            return is_string($json) ? $json : null;
        }

        return null;
    }

    private function normalizeScalarString(mixed $value): string
    {
        if ($value === null) {
            return '';
        }

        if (is_string($value)) {
            return $value;
        }

        if (is_scalar($value)) {
            return (string) $value;
        }

        if (is_array($value) || is_object($value)) {
            $json = json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            return is_string($json) ? $json : '';
        }

        return '';
    }

    private function readInstalledJoomlaVersionFresh(): ?string
    {
        $versionFile = JPATH_ROOT . '/libraries/src/Version.php';

        if (!is_file($versionFile)) {
            return null;
        }

        clearstatcache(true, $versionFile);

        if (function_exists('opcache_invalidate')) {
            @opcache_invalidate($versionFile, true);
        }

        $content = @file_get_contents($versionFile);

        if (!is_string($content) || $content === '') {
            return null;
        }

        if (preg_match('/SHORT_VERSION\s*=\s*[\'"]([^\'"]+)[\'"]/', $content, $matches) === 1) {
            return trim((string) $matches[1]);
        }

        $major = null;
        $minor = null;
        $patch = null;

        if (preg_match('/MAJOR_VERSION\s*=\s*[\'"]?(\d+)[\'"]?/', $content, $matches) === 1) {
            $major = $matches[1];
        }

        if (preg_match('/MINOR_VERSION\s*=\s*[\'"]?(\d+)[\'"]?/', $content, $matches) === 1) {
            $minor = $matches[1];
        }

        if (preg_match('/PATCH_VERSION\s*=\s*[\'"]?(\d+)[\'"]?/', $content, $matches) === 1) {
            $patch = $matches[1];
        }

        if ($major === null || $minor === null || $patch === null) {
            return null;
        }

        return $major . '.' . $minor . '.' . $patch;
    }

    private function waitForInstalledJoomlaVersionChange(string $currentVersion, string $targetVersion, int $maxAttempts = 12, int $sleepMicroseconds = 500000): array
    {
        $attempts = [];
        $lastFreshVersion = null;
        $lastLoadedVersion = null;

        for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
            $freshVersion = $this->readInstalledJoomlaVersionFresh();
            $loadedVersion = (new Version())->getShortVersion();
            $effectiveVersion = $freshVersion ?? $loadedVersion;

            $attempts[] = [
                'attempt' => $attempt,
                'fresh_version' => $freshVersion,
                'loaded_version' => $loadedVersion,
                'effective_version' => $effectiveVersion,
            ];

            $lastFreshVersion = $freshVersion;
            $lastLoadedVersion = $loadedVersion;

            if ($effectiveVersion !== '' && version_compare($effectiveVersion, $currentVersion, '>')) {
                return [
                    'fresh_version' => $freshVersion,
                    'loaded_version' => $loadedVersion,
                    'effective_version' => $effectiveVersion,
                    'attempts' => $attempts,
                ];
            }

            if ($targetVersion !== '' && $effectiveVersion !== '' && version_compare($effectiveVersion, $targetVersion, '>=')) {
                return [
                    'fresh_version' => $freshVersion,
                    'loaded_version' => $loadedVersion,
                    'effective_version' => $effectiveVersion,
                    'attempts' => $attempts,
                ];
            }

            if ($attempt < $maxAttempts) {
                usleep($sleepMicroseconds);
            }
        }

        return [
            'fresh_version' => $lastFreshVersion,
            'loaded_version' => $lastLoadedVersion,
            'effective_version' => $lastFreshVersion ?? $lastLoadedVersion,
            'attempts' => $attempts,
        ];
    }

    private function httpPostForm(string $url, array $formData, int $timeout = 60): array
    {
        $body = http_build_query($formData, '', '&', PHP_QUERY_RFC3986);

        if (function_exists('curl_init')) {
            $curl = curl_init($url);

            if ($curl === false) {
                throw new \RuntimeException('Lokaler HTTP-Aufruf konnte nicht initialisiert werden.');
            }

            curl_setopt_array($curl, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/x-www-form-urlencoded',
                    'Content-Length: ' . strlen($body),
                    'User-Agent: Lorch Update Center Agent',
                ],
            ]);

            $responseBody = curl_exec($curl);

            if (!is_string($responseBody)) {
                $error = curl_error($curl);
                curl_close($curl);
                throw new \RuntimeException('Lokaler HTTP-Aufruf fehlgeschlagen: ' . ($error !== '' ? $error : 'Unbekannter Fehler'));
            }

            $statusCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);

            return [
                'status_code' => $statusCode,
                'body' => $responseBody,
            ];
        }

        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => "Content-Type: application/x-www-form-urlencoded\r\nUser-Agent: Lorch Update Center Agent\r\n",
                'content' => $body,
                'timeout' => $timeout,
                'ignore_errors' => true,
            ],
        ]);

        $responseBody = file_get_contents($url, false, $context);

        if (!is_string($responseBody)) {
            throw new \RuntimeException('Lokaler HTTP-Aufruf fehlgeschlagen.');
        }

        $statusCode = 0;

        foreach (($http_response_header ?? []) as $headerLine) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $headerLine, $matches) === 1) {
                $statusCode = (int) $matches[1];
                break;
            }
        }

        return [
            'status_code' => $statusCode,
            'body' => $responseBody,
        ];
    }

    private function httpGetLocal(string $url, int $timeout = 15): array
    {
        if (function_exists('curl_init')) {
            $curl = curl_init($url);

            if ($curl === false) {
                throw new \RuntimeException('Lokaler HTTP-GET-Aufruf konnte nicht initialisiert werden.');
            }

            curl_setopt_array($curl, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 10,
                CURLOPT_TIMEOUT => $timeout,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTPHEADER => [
                    'User-Agent: Lorch Update Center Agent',
                    'Accept: text/plain,*/*',
                ],
            ]);

            $responseBody = curl_exec($curl);

            if (!is_string($responseBody)) {
                $error = curl_error($curl);
                curl_close($curl);
                throw new \RuntimeException('Lokaler HTTP-GET-Aufruf fehlgeschlagen: ' . ($error !== '' ? $error : 'Unbekannter Fehler'));
            }

            $statusCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);

            return [
                'status_code' => $statusCode,
                'body' => $responseBody,
            ];
        }

        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => "User-Agent: Lorch Update Center Agent\r\nAccept: text/plain,*/*\r\n",
                'timeout' => $timeout,
                'ignore_errors' => true,
            ],
        ]);

        $responseBody = file_get_contents($url, false, $context);

        if (!is_string($responseBody)) {
            throw new \RuntimeException('Lokaler HTTP-GET-Aufruf fehlgeschlagen.');
        }

        $statusCode = 0;

        foreach (($http_response_header ?? []) as $headerLine) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $headerLine, $matches) === 1) {
                $statusCode = (int) $matches[1];
                break;
            }
        }

        return [
            'status_code' => $statusCode,
            'body' => $responseBody,
        ];
    }

    private function updateStateDirectory(): string
    {
        $tmpPath = (string) Factory::getConfig()->get('tmp_path', sys_get_temp_dir());
        $path = rtrim($tmpPath, '/\\') . '/luc-update-state';

        if (!is_dir($path)) {
            @mkdir($path, 0755, true);
        }

        return $path;
    }

    private function updateStatePath(string $stateId): string
    {
        return $this->updateStateDirectory() . '/' . preg_replace('/[^a-f0-9]/', '', strtolower($stateId)) . '.json';
    }

    private function writeLocalUpdateState(string $stateId, array $state): void
    {
        file_put_contents($this->updateStatePath($stateId), json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    }

    private function readLocalUpdateState(string $stateId): ?array
    {
        $path = $this->updateStatePath($stateId);

        if (!is_file($path)) {
            return null;
        }

        $decoded = json_decode((string) file_get_contents($path), true);

        return is_array($decoded) ? $decoded : null;
    }

    private function deleteLocalUpdateState(string $stateId): void
    {
        $path = $this->updateStatePath($stateId);

        if (is_file($path)) {
            @unlink($path);
        }
    }

    private function requestJoomlaUpdateApi(string $method, string $path, string $token, ?array $payload = null): array
    {
        $url = rtrim(Uri::root(), '/') . $path;
        $headers = [
            'Accept: application/json',
            'X-JUpdate-Token: ' . $token,
            'User-Agent: Lorch Update Center Agent',
        ];
        $method = strtoupper($method);
        $body = null;

        if ($payload !== null) {
            $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

            if (!is_string($body)) {
                throw new \RuntimeException('Update-Request konnte nicht serialisiert werden.');
            }

            $headers[] = 'Content-Type: application/json; charset=utf-8';
        }

        if (function_exists('curl_init')) {
            $curl = curl_init($url);

            if ($curl === false) {
                throw new \RuntimeException('cURL konnte für den Joomla-Update-API-Aufruf nicht initialisiert werden.');
            }

            curl_setopt_array($curl, [
                CURLOPT_CUSTOMREQUEST => $method,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_TIMEOUT => 300,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ]);

            if ($body !== null) {
                curl_setopt($curl, CURLOPT_POSTFIELDS, $body);
            }

            $responseBody = curl_exec($curl);

            if (!is_string($responseBody)) {
                $error = curl_error($curl);
                curl_close($curl);
                throw new \RuntimeException('Joomla-Update-API-Request per cURL fehlgeschlagen: ' . ($error !== '' ? $error : 'Unbekannter Fehler'));
            }

            $statusCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);

            return [
                'status_code' => $statusCode,
                'body' => $responseBody,
            ];
        }

        $context = stream_context_create([
            'http' => [
                'method' => $method,
                'header' => implode("\r\n", $headers),
                'content' => $body ?? '',
                'timeout' => 300,
                'ignore_errors' => true,
            ],
        ]);

        $responseBody = file_get_contents($url, false, $context);

        if ($responseBody === false) {
            throw new \RuntimeException('Joomla-Update-API-Request fehlgeschlagen.');
        }

        $statusCode = 0;

        foreach (($http_response_header ?? []) as $headerLine) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $headerLine, $matches) === 1) {
                $statusCode = (int) $matches[1];
                break;
            }
        }

        return [
            'status_code' => $statusCode,
            'body' => $responseBody,
        ];
    }

    private function extractJoomlaUpdateApiAttributes(array $response): array
    {
        $statusCode = (int) ($response['status_code'] ?? 0);
        $body = (string) ($response['body'] ?? '');
        $json = json_decode($body, true);

        if (!is_array($json)) {
            throw new \RuntimeException('Joomla-Update-API lieferte kein gültiges JSON.', $statusCode);
        }

        if ($statusCode >= 400) {
            $errors = $json['errors'] ?? [];
            $firstError = is_array($errors) && isset($errors[0]['title']) ? (string) $errors[0]['title'] : 'Joomla-Update-API antwortete mit HTTP ' . $statusCode . '.';
            throw new \RuntimeException($firstError, $statusCode);
        }

        $attributes = $json['data']['attributes'] ?? null;

        if (!is_array($attributes)) {
            return ['success' => true];
        }

        return $attributes;
    }
    private function runManualJoomlaCoreUpdate(string $currentVersion, string $targetVersion): array
    {
        $details = [
            'driver' => 'joomla_manual_model_path',
            'steps' => [],
        ];
        $model = $this->createJoomlaUpdateModel();
        $extensionId = $this->findCoreExtensionId();
        $coreUpdateCandidate = $this->findCoreUpdateCandidate();
        $coreUpdateRow = $extensionId !== null ? $this->fetchCoreUpdateRow($extensionId) : null;

        $coreUpdate = $this->detectCoreUpdate($currentVersion);

        if (
            (($coreUpdate['status'] ?? 'fail') !== 'ok' || empty($coreUpdate['has_update']) || empty($coreUpdate['same_major']))
            && $this->isAllowedTargetVersion($currentVersion, $targetVersion)
        ) {
            $coreUpdate = $this->buildCoreUpdateResult($currentVersion, $targetVersion, 'webapp_target_fallback');
            $details['steps']['target_version_fallback'] = [
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'source' => 'webapp_target_fallback',
            ];
        }

        if (($coreUpdate['status'] ?? 'fail') !== 'ok' || empty($coreUpdate['has_update']) || empty($coreUpdate['same_major'])) {
            return [
                'status' => 'fail',
                'message' => 'Es liegt kein zulässiges manuelles Joomla-Core-Update innerhalb derselben Major-Version vor.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        if (!empty($coreUpdate['target_version']) && version_compare((string) $coreUpdate['target_version'], $targetVersion, '!=')) {
            return [
                'status' => 'fail',
                'message' => 'Die angeforderte Zielversion stimmt nicht mit der aktuell erkannten Joomla-Zielversion überein.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details + [
                    'detected_target_version' => (string) ($coreUpdate['target_version'] ?? ''),
                ],
            ];
        }

        $details['steps']['disableAkeebaBackupOnUpdate'] = $this->ensureAkeebaBackupOnUpdateDisabled();

        if (empty($details['steps']['disableAkeebaBackupOnUpdate']['verified_disabled'])) {
            return [
                'status' => 'fail',
                'message' => 'Akeeba Backup on Update konnte vor dem Core-Update nicht sicher deaktiviert werden.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        $details['steps']['detectedUpdateCandidate'] = $this->normalizeMethodResult($coreUpdateCandidate);
        $details['steps']['coreUpdateRow'] = $this->normalizeMethodResult($coreUpdateRow);

        if (!is_object($coreUpdateCandidate) && is_array($coreUpdateRow)) {
            $coreUpdateCandidate = $this->buildCoreUpdateCandidateFromRow($coreUpdateRow, $targetVersion);
            $details['steps']['detectedUpdateCandidateFromRow'] = $this->normalizeMethodResult($coreUpdateCandidate);
        }

        $this->primeJoomlaUpdateModel($model, $coreUpdateCandidate, $currentVersion, $targetVersion);

        if (method_exists($model, 'applyUpdateSite')) {
            $details['steps']['applyUpdateSite'] = $this->invokeModelMethod($model, 'applyUpdateSite', [[], [$targetVersion]]);
        }

        $updateInformation = $this->loadJoomlaUpdateInformation($model);
        $details['steps']['getUpdateInformation'] = $this->normalizeMethodResult($updateInformation);

        $hasUsableUpdateInformation = $this->hasUsableDownloadInformation($updateInformation);
        $hasUsableFallbackCandidate = is_object($coreUpdateCandidate)
            && method_exists($coreUpdateCandidate, 'get')
            && trim((string) $coreUpdateCandidate->get('downloadurl')) !== '';

        $details['steps']['downloadSource'] = [
            'uses_update_information' => $hasUsableUpdateInformation,
            'uses_candidate_fallback' => !$hasUsableUpdateInformation && $hasUsableFallbackCandidate,
            'candidate_downloadurl' => $hasUsableFallbackCandidate ? (string) $coreUpdateCandidate->get('downloadurl') : '',
        ];

        if (!$hasUsableUpdateInformation && !$hasUsableFallbackCandidate) {
            return [
                'status' => 'fail',
                'message' => 'Joomla liefert noch keine verwertbare Updateinformation für den Download. Die Diagnose liegt unten in den Update-Details.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        $downloadArgumentSets = [[]];

        if ($hasUsableUpdateInformation) {
            $downloadArgumentSets[] = [$updateInformation];
        }

        if ($hasUsableFallbackCandidate) {
            $downloadArgumentSets[] = [$coreUpdateCandidate];
            $downloadArgumentSets[] = [(string) $coreUpdateCandidate->get('downloadurl')];
        }

        $downloadArgumentSets[] = [$targetVersion];
        $downloadArgumentSets[] = [$coreUpdate];

        $downloadResult = $this->invokeModelMethod($model, 'download', $downloadArgumentSets);
        $details['steps']['download'] = $this->normalizeMethodResult($downloadResult);

        if ($this->isFailedResult($downloadResult)) {
            return [
                'status' => 'fail',
                'message' => 'Der Download des Joomla-Core-Updates ist fehlgeschlagen.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        $restorationInput = $this->extractRestorationInput($downloadResult);

        if (method_exists($model, 'createRestorationFile')) {
            $restorationResult = $this->invokeModelMethod($model, 'createRestorationFile', [
                $restorationInput !== null ? [$restorationInput] : [],
                [],
            ]);
            $details['steps']['createRestorationFile'] = $this->normalizeMethodResult($restorationResult);

            if ($this->isFailedResult($restorationResult)) {
                return [
                    'status' => 'fail',
                    'message' => 'Die Joomla-Restoration-Datei konnte nicht erzeugt werden.',
                    'current_version' => $currentVersion,
                    'target_version' => $targetVersion,
                    'details' => $details,
                ];
            }
        }

        $finalizeResult = $this->invokeModelMethod($model, 'finaliseUpgrade', [
            [],
            [$restorationInput],
            [$targetVersion],
        ]);
        $details['steps']['finaliseUpgrade'] = $this->normalizeMethodResult($finalizeResult);

        if ($this->isFailedResult($finalizeResult)) {
            return [
                'status' => 'fail',
                'message' => 'Die Finalisierung des Joomla-Core-Updates ist fehlgeschlagen.',
                'current_version' => $currentVersion,
                'target_version' => $targetVersion,
                'details' => $details,
            ];
        }

        if (method_exists($model, 'cleanUp')) {
            $details['steps']['cleanUp'] = $this->normalizeMethodResult($this->invokeModelMethod($model, 'cleanUp', [[], [$restorationInput]]));
        }

        if (method_exists($model, 'removeExtractedUpdatePackage')) {
            $details['steps']['removeExtractedUpdatePackage'] = $this->normalizeMethodResult($this->invokeModelMethod($model, 'removeExtractedUpdatePackage', [[], [$restorationInput]]));
        }

        $newVersion = (new Version())->getShortVersion();

        return [
            'status' => version_compare($newVersion, $currentVersion, '>') ? 'ok' : 'fail',
            'message' => version_compare($newVersion, $currentVersion, '>')
                ? 'Joomla-Core-Update erfolgreich abgeschlossen: ' . $currentVersion . ' -> ' . $newVersion
                : 'Der interne Joomla-Updatepfad lief durch, aber die Joomla-Version hat sich nicht geändert.',
            'current_version' => $currentVersion,
            'target_version' => $targetVersion,
            'joomla_version' => $newVersion,
            'details' => $details,
        ];
    }


    private function createJoomlaUpdateModel(): object
    {
        $app = Factory::getApplication();
        $component = $app->bootComponent('com_joomlaupdate');
        $mvcFactory = $component->getMVCFactory();
        $model = $mvcFactory->createModel('Update', 'Administrator', ['ignore_request' => true]);

        if (!is_object($model)) {
            throw new \RuntimeException('Das Joomla-Update-Model konnte nicht instanziiert werden.');
        }

        return $model;
    }

    private function findCoreUpdateCandidate(): mixed
    {
        $extensionId = $this->findCoreExtensionId();

        if ($extensionId === null) {
            return null;
        }

        $updater = Updater::getInstance();
        $updater->findUpdates($extensionId, 0, Updater::STABILITY_STABLE, false);
        $updates = $updater->getAvailableUpdates($extensionId, Updater::STABILITY_STABLE);

        if (!is_array($updates) || $updates === []) {
            return null;
        }

        $candidate = null;
        $candidateVersion = null;

        foreach ($updates as $update) {
            if (!is_object($update)) {
                continue;
            }

            $version = null;

            if (method_exists($update, 'getTargetVersion')) {
                $version = (string) $update->getTargetVersion();
            }

            if (($version === null || $version === '') && method_exists($update, 'get')) {
                $version = (string) $update->get('version');
            }

            if ($version === null || $version === '') {
                continue;
            }

            if ($candidate === null || version_compare($version, (string) $candidateVersion, '>')) {
                $candidate = $update;
                $candidateVersion = $version;
            }
        }

        return $candidate;
    }

    private function fetchCoreUpdateRow(int $extensionId): ?array
    {
        try {
            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $query = $db->getQuery(true)
                ->select('*')
                ->from($db->quoteName('#__updates'))
                ->where($db->quoteName('extension_id') . ' = ' . (int) $extensionId)
                ->order($db->quoteName('update_id') . ' DESC');
            $db->setQuery($query, 0, 1);
            $row = $db->loadAssoc();

            return is_array($row) ? $row : null;
        } catch (\Throwable $throwable) {
            return null;
        }
    }

    private function buildCoreUpdateCandidateFromRow(array $row, string $targetVersion): object
    {
        $downloadUrl = $this->extractDownloadUrlFromUpdateRow($row, $targetVersion);
        $data = [
            'version' => (string) ($row['version'] ?? $targetVersion),
            'downloadurl' => $downloadUrl,
            'infourl' => (string) ($row['infourl'] ?? ''),
            'detailsurl' => (string) ($row['detailsurl'] ?? ''),
            'type' => (string) ($row['type'] ?? ''),
            'name' => (string) ($row['name'] ?? ''),
            'element' => (string) ($row['element'] ?? ''),
        ];

        return new class($data) {
            public array $_data;

            public function __construct(array $data)
            {
                $this->_data = $data;
            }

            public function get(string $key, mixed $default = null): mixed
            {
                return $this->_data[$key] ?? $default;
            }

            public function __get(string $key): mixed
            {
                return $this->_data[$key] ?? null;
            }
        };
    }

    private function extractDownloadUrlFromUpdateRow(array $row, string $targetVersion): string
    {
        foreach (['downloadurl', 'detailsurl', 'infourl'] as $field) {
            if (!empty($row[$field]) && is_string($row[$field]) && filter_var($row[$field], FILTER_VALIDATE_URL)) {
                if ($field === 'downloadurl') {
                    return (string) $row[$field];
                }
            }
        }

        $rawData = (string) ($row['data'] ?? '');

        if ($rawData === '') {
            return $this->buildOfficialUpgradePackageUrl($targetVersion);
        }

        try {
            $xml = @simplexml_load_string($rawData);

            if ($xml === false) {
                return $this->buildOfficialUpgradePackageUrl($targetVersion);
            }

            $candidates = $xml->xpath('//downloadsource') ?: [];

            foreach ($candidates as $candidate) {
                $url = trim((string) $candidate);

                if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)) {
                    return $url;
                }
            }

            $legacyCandidates = $xml->xpath('//downloadurl') ?: [];

            foreach ($legacyCandidates as $candidate) {
                $url = trim((string) $candidate);

                if ($url !== '' && filter_var($url, FILTER_VALIDATE_URL)) {
                    return $url;
                }
            }
        } catch (\Throwable $throwable) {
            return $this->buildOfficialUpgradePackageUrl($targetVersion);
        }

        return $this->buildOfficialUpgradePackageUrl($targetVersion);
    }

    private function buildOfficialUpgradePackageUrl(string $targetVersion): string
    {
        $normalizedVersion = trim($targetVersion);

        if (!preg_match('/^\d+\.\d+\.\d+$/', $normalizedVersion)) {
            return '';
        }

        $major = $this->majorVersion($normalizedVersion);
        $versionSlug = str_replace('.', '-', $normalizedVersion);

        return sprintf(
            'https://downloads.joomla.org/cms/joomla%d/%s/Joomla_%s-Stable-Update_Package.zip?format=zip',
            $major,
            $versionSlug,
            $versionSlug
        );
    }

    private function isAllowedTargetVersion(string $currentVersion, string $targetVersion): bool
    {
        $currentVersion = trim($currentVersion);
        $targetVersion = trim($targetVersion);

        if ($currentVersion === '' || $targetVersion === '') {
            return false;
        }

        if (!$this->isSupportedVersionString($currentVersion) || !$this->isSupportedVersionString($targetVersion)) {
            return false;
        }

        if ($this->majorVersion($currentVersion) !== $this->majorVersion($targetVersion)) {
            return false;
        }

        return version_compare($targetVersion, $currentVersion, '>');
    }

    private function isSupportedVersionString(string $version): bool
    {
        return preg_match('/^\d+\.\d+\.\d+$/', $version) === 1;
    }

    private function primeJoomlaUpdateModel(object $model, mixed $coreUpdateCandidate, string $currentVersion, string $targetVersion): void
    {
        if (!is_object($coreUpdateCandidate)) {
            return;
        }

        foreach ([
            'currentUpdate' => $coreUpdateCandidate,
            'latest' => $targetVersion,
            'current' => $currentVersion,
            'installed' => $currentVersion,
            'hasUpdate' => true,
        ] as $property => $value) {
            if (!property_exists($model, $property)) {
                continue;
            }

            try {
                $reflection = new \ReflectionProperty($model, $property);
                $reflection->setAccessible(true);
                $reflection->setValue($model, $value);
            } catch (\Throwable $throwable) {
            }
        }
    }

    private function invokeModelMethod(object $model, string $method, array $candidateArgumentSets = []): mixed
    {
        if (!method_exists($model, $method)) {
            throw new \RuntimeException('Die Methode ' . $method . ' ist im Joomla-Update-Model nicht vorhanden.');
        }

        $reflection = new \ReflectionMethod($model, $method);

        foreach ($candidateArgumentSets as $arguments) {
            if (!is_array($arguments)) {
                continue;
            }

            if (count($arguments) < $reflection->getNumberOfRequiredParameters()) {
                continue;
            }

            if (count($arguments) > $reflection->getNumberOfParameters()) {
                continue;
            }

            return $reflection->invokeArgs($model, $arguments);
        }

        if ($reflection->getNumberOfRequiredParameters() === 0) {
            return $reflection->invoke($model);
        }

        throw new \RuntimeException('Für die Methode ' . $method . ' konnte kein passendes Argumentset bestimmt werden.');
    }

    private function normalizeMethodResult(mixed $result): array
    {
        if (is_array($result)) {
            return $this->summarizeArrayResult($result);
        }

        if (is_object($result)) {
            $summary = [
                'type' => 'object',
                'class' => get_class($result),
            ];

            if (method_exists($result, 'get')) {
                foreach (['downloadurl', 'version', 'infourl', 'detailsurl', 'type'] as $field) {
                    try {
                        $value = $result->get($field);

                        if (is_scalar($value) || $value === null) {
                            $summary[$field] = $value;
                        }
                    } catch (\Throwable $throwable) {
                        $summary[$field . '_error'] = $throwable->getMessage();
                    }
                }
            }

            $publicProperties = get_object_vars($result);

            if ($publicProperties !== []) {
                $summary['properties'] = $this->summarizeArrayResult($publicProperties);
            }

            return $summary;
        }

        return [
            'type' => gettype($result),
            'value' => $result,
        ];
    }

    private function isFailedResult(mixed $result): bool
    {
        if ($result === false || $result === null) {
            return true;
        }

        if (is_array($result) && isset($result['success']) && $result['success'] === false) {
            return true;
        }

        return false;
    }

    private function extractRestorationInput(mixed $downloadResult): mixed
    {
        if (is_string($downloadResult) && trim($downloadResult) !== '') {
            return $downloadResult;
        }

        if (!is_array($downloadResult)) {
            return null;
        }

        foreach (['basename', 'path', 'file', 'package', 'archive', 'target'] as $candidateKey) {
            if (!empty($downloadResult[$candidateKey]) && is_string($downloadResult[$candidateKey])) {
                return $downloadResult[$candidateKey];
            }
        }

        return null;
    }

    private function loadJoomlaUpdateInformation(object $model): mixed
    {
        if (method_exists($model, 'getUpdateInformation')) {
            return $this->invokeModelMethod($model, 'getUpdateInformation', [[]]);
        }

        if (method_exists($model, 'getItem')) {
            return $this->invokeModelMethod($model, 'getItem', [[]]);
        }

        return null;
    }

    private function hasUsableDownloadInformation(mixed $updateInformation): bool
    {
        if (is_object($updateInformation) && method_exists($updateInformation, 'get')) {
            return trim((string) $updateInformation->get('downloadurl')) !== '';
        }

        if (is_array($updateInformation)) {
            if (!empty($updateInformation['downloadurl']) && is_string($updateInformation['downloadurl'])) {
                return true;
            }

            if (isset($updateInformation['object']) && is_object($updateInformation['object']) && method_exists($updateInformation['object'], 'get')) {
                return trim($this->normalizeScalarString($updateInformation['object']->get('downloadurl'))) !== '';
            }
        }

        return false;
    }

    private function summarizeArrayResult(array $result): array
    {
        $summary = [];

        foreach ($result as $key => $value) {
            if (is_scalar($value) || $value === null) {
                $summary[$key] = $value;
                continue;
            }

            if (is_array($value)) {
                $summary[$key] = $this->summarizeArrayResult($value);
                continue;
            }

            if (is_object($value)) {
                $summary[$key] = $this->normalizeMethodResult($value);
                continue;
            }

            $summary[$key] = gettype($value);
        }

        return $summary;
    }

    private function triggerAkeebaBackup(array $config, array $payload): array
    {
        $details = [
            'driver' => 'akeeba_json_api_v2',
            'endpoint' => null,
            'backupid' => null,
            'archive_name' => null,
            'progress' => null,
            'step_count' => 0,
            'warnings' => [],
        ];
        $apiSecret = trim((string) ($config['akeeba_api_secret'] ?? ''));

        if (!is_dir(JPATH_ADMINISTRATOR . '/components/com_akeebabackup')) {
            return [
                'status' => 'fail',
                'message' => 'Akeeba Backup Pro ist nicht installiert.',
                'details' => $details,
            ];
        }

        if ($apiSecret === '') {
            return [
                'status' => 'fail',
                'message' => 'Im LUC-Agenten fehlt der Akeeba API Secret Key.',
                'details' => $details,
            ];
        }

        try {
            $result = $this->runAkeebaJsonApiBackup($apiSecret, $details, $payload);
            $hasMoreSteps = !empty($result['HasRun']);

            return [
                'status' => $hasMoreSteps ? 'running' : 'ok',
                'message' => $hasMoreSteps
                    ? 'Akeeba-Backup läuft und benötigt weitere API-Schritte.'
                    : 'Akeeba-Backup über die offizielle JSON API erfolgreich abgeschlossen.',
                'driver' => (string) $details['driver'],
                'archive_name' => $details['archive_name'],
                'tag' => 'json',
                'backupid' => (string) ($result['backupid'] ?? ''),
                'sleep_time' => max(0, (int) ($result['sleepTime'] ?? 0)),
                'progress' => isset($result['Progress']) ? (int) $result['Progress'] : null,
                'has_more_steps' => $hasMoreSteps,
                'details' => $details,
                'result' => $result,
            ];
        } catch (\Throwable $throwable) {
            $details['exception'] = $throwable->getMessage();

            return [
                'status' => 'fail',
                'message' => 'Akeeba-Pro-Backup über die JSON API fehlgeschlagen: ' . $throwable->getMessage(),
                'driver' => (string) $details['driver'],
                'archive_name' => $details['archive_name'],
                'tag' => 'json',
                'details' => $details,
            ];
        }
    }

    private function runAkeebaJsonApiBackup(string $apiSecret, array &$details, array $payload): array
    {
        $baseUrl = rtrim(Uri::root(), '/');
        $endpoints = [
            $baseUrl . '/api/index.php/v2/akeebabackup',
            $baseUrl . '/index.php?option=com_akeebabackup&view=Api&format=raw',
        ];
        $response = null;
        $command = strtolower(trim((string) ($payload['backup_command'] ?? 'start')));
        $existingBackupId = trim((string) ($payload['backupid'] ?? ''));
        $knownLucBackupIds = $this->normalizeBackupIdList($payload['luc_known_backupids'] ?? []);

        foreach ($endpoints as $endpoint) {
            try {
                $details['endpoint'] = $endpoint;
                $requestFields = $command === 'step'
                    ? [
                        'method' => 'stepBackup',
                        'backupid' => $existingBackupId,
                    ]
                    : [
                        'method' => 'startBackup',
                        'profile' => '1',
                        'description' => 'Lorch Update Center Backup ' . gmdate('Y-m-d H:i:s'),
                        'comment' => 'Ausgeloest durch Lorch Update Center',
                    ];
                $response = $this->postAkeebaApiForm($endpoint, $apiSecret, $requestFields);
                break;
            } catch (\Throwable $throwable) {
                $details['endpoint_error'] = $throwable->getMessage();
                $response = null;
            }
        }

        if (!is_array($response)) {
            throw new \RuntimeException('Keiner der Akeeba-API-Endpunkte war erfolgreich erreichbar. Prüfe JSON API, Secret Key und Web Services - Akeeba Backup.');
        }

        $data = $this->normalizeAkeebaApiResponse($response);
        $effectiveBackupId = trim((string) ($data['backupid'] ?? ''));

        if ($effectiveBackupId === '') {
            $effectiveBackupId = $existingBackupId;
        }

        $details['backupid'] = $effectiveBackupId;
        $details['archive_name'] = !empty($data['Archive']) ? (string) $data['Archive'] : null;
        $details['progress'] = isset($data['Progress']) ? (int) $data['Progress'] : null;
        $details['warnings'] = is_array($data['Warnings'] ?? null) ? $data['Warnings'] : [];
        $details['step_count'] = 1;
        $hasMoreSteps = !empty($data['HasRun']);

        if ($command === 'step' && !$hasMoreSteps) {
            $this->cleanupOlderLucBackupArchive($apiSecret, $details['endpoint'] ?? null, $effectiveBackupId, $knownLucBackupIds, $details);
        }

        return $data;
    }

    private function cleanupOlderLucBackupArchive(string $apiSecret, ?string $endpoint, string $currentBackupId, array $knownLucBackupIds, array &$details): void
    {
        $cleanup = [
            'status' => 'skipped',
            'message' => 'Keine Bereinigung durchgeführt.',
            'current_backupid' => $currentBackupId,
            'deleted_backupids' => [],
            'deleted_files_total' => 0,
            'deleted_count' => 0,
            'candidate_count' => 0,
        ];
        $details['retention'] = $cleanup;

        if (!is_string($endpoint) || trim($endpoint) === '') {
            $details['retention']['message'] = 'Akeeba-Endpoint für Bereinigung fehlt.';

            return;
        }

        if ($currentBackupId === '') {
            $details['retention']['message'] = 'Aktuelle backupid fehlt, keine sichere Bereinigung möglich.';

            return;
        }

        try {
            $listResponse = $this->postAkeebaMethod($endpoint, $apiSecret, 'listBackups', [
                'profile' => '1',
            ]);
            $rows = $this->extractAkeebaBackupRows($listResponse);

            if ($rows === []) {
                $details['retention']['message'] = 'Akeeba lieferte keine Backup-Liste für Bereinigung.';

                return;
            }

            usort($rows, function (array $left, array $right): int {
                return $this->extractAkeebaBackupSortValue($right) <=> $this->extractAkeebaBackupSortValue($left);
            });

            $candidates = [];

            foreach ($rows as $row) {
                $backupId = $this->extractAkeebaBackupId($row);

                if ($backupId === '' || $backupId === $currentBackupId) {
                    continue;
                }

                $effectiveRow = $this->enrichAkeebaBackupRow($endpoint, $apiSecret, $backupId, $row);

                if (!$this->isLucManagedBackupRow($effectiveRow) && !in_array($backupId, $knownLucBackupIds, true)) {
                    continue;
                }

                if ($this->isAkeebaBackupRowProtected($effectiveRow)) {
                    continue;
                }

                $candidates[] = [
                    'backupid' => $backupId,
                    'row' => $effectiveRow,
                ];
            }

            $details['retention']['candidate_count'] = count($candidates);

            if ($candidates === []) {
                $details['retention']['message'] = 'Kein älteres LUC-Backup-Archiv zum Löschen gefunden.';

                return;
            }

            $deletedBackupIds = [];
            $deletedFilesTotal = 0;

            $deleteErrors = [];

            foreach ($candidates as $candidate) {
                $targetBackupId = (string) ($candidate['backupid'] ?? '');

                if ($targetBackupId === '') {
                    continue;
                }

                try {
                    $deleteResponse = $this->deleteAkeebaBackupFiles($endpoint, $apiSecret, $targetBackupId, $candidate['row'] ?? []);
                    $deletedBackupIds[] = $targetBackupId;
                    $deletedFilesTotal += max(0, (int) ($deleteResponse['count'] ?? 0));
                } catch (\Throwable $throwable) {
                    $deleteErrors[] = [
                        'backupid' => $targetBackupId,
                        'error' => $throwable->getMessage(),
                    ];
                }
            }

            $details['retention'] = [
                'status' => $deleteErrors === [] ? 'ok' : 'warn',
                'message' => $deleteErrors === []
                    ? 'Ältere LUC-Backup-Archive wurden gelöscht.'
                    : 'Bereinigung teilweise fehlgeschlagen. Details enthalten.',
                'current_backupid' => $currentBackupId,
                'deleted_backupids' => $deletedBackupIds,
                'deleted_files_total' => $deletedFilesTotal,
                'deleted_count' => count($deletedBackupIds),
                'candidate_count' => count($candidates),
                'delete_errors' => $deleteErrors,
            ];
        } catch (\Throwable $throwable) {
            $details['retention'] = [
                'status' => 'warn',
                'message' => 'Archiv-Bereinigung nach Backup fehlgeschlagen: ' . $throwable->getMessage(),
                'current_backupid' => $currentBackupId,
                'deleted_backupids' => [],
                'deleted_files_total' => 0,
                'deleted_count' => 0,
                'candidate_count' => $details['retention']['candidate_count'] ?? 0,
            ];
        }
    }

    private function postAkeebaMethod(string $endpoint, string $apiSecret, string $method, array $extraFields = []): array
    {
        $response = $this->postAkeebaApiForm($endpoint, $apiSecret, array_merge([
            'method' => $method,
        ], $extraFields));

        return $this->normalizeAkeebaApiResponse($response);
    }

    private function extractAkeebaBackupRows(array $listResponse): array
    {
        if ($listResponse === []) {
            return [];
        }

        if (array_is_list($listResponse)) {
            return array_values(array_filter($listResponse, 'is_array'));
        }

        $candidates = [
            $listResponse['backups'] ?? null,
            $listResponse['items'] ?? null,
            $listResponse['list'] ?? null,
            $listResponse['records'] ?? null,
            $listResponse['data'] ?? null,
        ];

        foreach ($candidates as $candidate) {
            if (is_array($candidate) && array_is_list($candidate)) {
                return array_values(array_filter($candidate, 'is_array'));
            }
        }

        return [];
    }

    private function extractAkeebaBackupSortValue(array $row): int
    {
        $id = $this->extractAkeebaBackupId($row);

        if ($id !== '' && ctype_digit($id)) {
            return (int) $id;
        }

        $dateFields = [
            $row['backupstart'] ?? null,
            $row['backupStart'] ?? null,
            $row['start'] ?? null,
            $row['created'] ?? null,
        ];

        foreach ($dateFields as $value) {
            if (!is_string($value) || trim($value) === '') {
                continue;
            }

            $timestamp = strtotime($value);

            if ($timestamp !== false) {
                return $timestamp;
            }
        }

        return 0;
    }

    private function extractAkeebaBackupId(array $row): string
    {
        $keys = ['backupid', 'id', 'backup_id'];

        foreach ($keys as $key) {
            if (!array_key_exists($key, $row)) {
                continue;
            }

            $value = trim($this->normalizeScalarString($row[$key]));

            if ($value !== '') {
                return $value;
            }
        }

        return '';
    }

    private function isLucManagedBackupRow(array $row): bool
    {
        $description = trim($this->normalizeScalarString($row['description'] ?? ''));
        $comment = trim($this->normalizeScalarString($row['comment'] ?? ''));

        if ($description === '' && $comment === '') {
            return false;
        }

        $haystack = strtolower($description . ' ' . $comment);

        return str_contains($haystack, 'lorch update center');
    }

    private function enrichAkeebaBackupRow(string $endpoint, string $apiSecret, string $backupId, array $row): array
    {
        $description = trim($this->normalizeScalarString($row['description'] ?? ''));
        $comment = trim($this->normalizeScalarString($row['comment'] ?? ''));

        if ($description !== '' || $comment !== '') {
            return $row;
        }

        try {
            $info = $this->postAkeebaMethod($endpoint, $apiSecret, 'getBackupInfo', [
                'backupid' => $backupId,
            ]);

            if (is_array($info)) {
                return array_merge($row, $info);
            }
        } catch (\Throwable) {
        }

        return $row;
    }

    private function isAkeebaBackupRowProtected(array $row): bool
    {
        $frozen = trim($this->normalizeScalarString($row['frozen'] ?? '0'));

        if ($frozen === '1' || strtolower($frozen) === 'true') {
            return true;
        }

        $status = strtolower(trim($this->normalizeScalarString($row['status'] ?? '')));

        if ($status === '') {
            return false;
        }

        return in_array($status, ['pending', 'running', 'fail', 'error', 'obsolete'], true);
    }

    private function normalizeBackupIdList(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }

        $ids = [];

        foreach ($value as $entry) {
            $id = trim($this->normalizeScalarString($entry));

            if ($id !== '') {
                $ids[$id] = true;
            }
        }

        return array_keys($ids);
    }

    private function getAgentVersion(): string
    {
        if (is_string($this->cachedAgentVersion) && $this->cachedAgentVersion !== '') {
            return $this->cachedAgentVersion;
        }

        $manifestPath = __DIR__ . '/lorchupdate.xml';

        if (!is_file($manifestPath)) {
            $this->cachedAgentVersion = 'unknown';

            return $this->cachedAgentVersion;
        }

        $manifest = @file_get_contents($manifestPath);

        if (!is_string($manifest) || $manifest === '') {
            $this->cachedAgentVersion = 'unknown';

            return $this->cachedAgentVersion;
        }

        if (preg_match('/<version>\s*([^<]+)\s*<\/version>/i', $manifest, $matches) !== 1) {
            $this->cachedAgentVersion = 'unknown';

            return $this->cachedAgentVersion;
        }

        $version = trim((string) $matches[1]);
        $this->cachedAgentVersion = $version !== '' ? $version : 'unknown';

        return $this->cachedAgentVersion;
    }

    private function deleteAkeebaBackupFiles(string $endpoint, string $apiSecret, string $backupId, array $row = []): array
    {
        $recordId = $this->resolveAkeebaDeleteRecordId($endpoint, $apiSecret, $backupId, $row);

        if ($recordId === null) {
            throw new \RuntimeException('Kein numerischer Akeeba-Datensatz-Identifier für deleteFiles gefunden.');
        }

        $attempts = [
            ['backup_id' => (string) $recordId],
            ['id' => (string) $recordId],
            ['backupid' => (string) $recordId],
            ['backupid' => $backupId],
        ];
        $lastException = null;

        foreach ($attempts as $payload) {
            try {
                return $this->postAkeebaMethod($endpoint, $apiSecret, 'deleteFiles', $payload);
            } catch (\Throwable $throwable) {
                $lastException = $throwable;
            }
        }

        if ($lastException instanceof \Throwable) {
            throw $lastException;
        }

        throw new \RuntimeException('deleteFiles konnte nicht ausgeführt werden.');
    }

    private function resolveAkeebaDeleteRecordId(string $endpoint, string $apiSecret, string $backupId, array $row = []): ?int
    {
        $fromRow = $this->extractNumericAkeebaRecordId($row);

        if ($fromRow !== null) {
            return $fromRow;
        }

        try {
            $info = $this->postAkeebaMethod($endpoint, $apiSecret, 'getBackupInfo', [
                'backupid' => $backupId,
            ]);
            $fromInfo = $this->extractNumericAkeebaRecordId(is_array($info) ? $info : []);

            if ($fromInfo !== null) {
                return $fromInfo;
            }
        } catch (\Throwable) {
        }

        return null;
    }

    private function extractNumericAkeebaRecordId(array $payload): ?int
    {
        $keys = ['id', 'backup_id', 'record_id', 'backuprecordid', 'backupRecordId'];

        foreach ($keys as $key) {
            if (!array_key_exists($key, $payload)) {
                continue;
            }

            $value = trim($this->normalizeScalarString($payload[$key]));

            if ($value !== '' && ctype_digit($value)) {
                return (int) $value;
            }
        }

        return null;
    }

    private function postAkeebaApiForm(string $url, string $apiSecret, array $fields): array
    {
        $body = http_build_query($fields, '', '&', PHP_QUERY_RFC3986);
        $headers = [
            'Accept: application/json',
            'Content-Type: application/x-www-form-urlencoded; charset=utf-8',
            'X-Akeeba-Auth: ' . $apiSecret,
        ];

        if (function_exists('curl_init')) {
            $curl = curl_init($url);

            if ($curl === false) {
                throw new \RuntimeException('cURL konnte für den Akeeba-API-Aufruf nicht initialisiert werden.');
            }

            curl_setopt_array($curl, [
                CURLOPT_POST => true,
                CURLOPT_POSTFIELDS => $body,
                CURLOPT_HTTPHEADER => $headers,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_CONNECTTIMEOUT => 20,
                CURLOPT_TIMEOUT => 25,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ]);

            $responseBody = curl_exec($curl);

            if (!is_string($responseBody)) {
                $error = curl_error($curl);
                curl_close($curl);
                throw new \RuntimeException('Akeeba-API-Request per cURL fehlgeschlagen: ' . ($error !== '' ? $error : 'Unbekannter Fehler'));
            }

            $statusCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
            curl_close($curl);

            return [
                'status_code' => $statusCode,
                'body' => $responseBody,
            ];
        }

        $context = stream_context_create([
            'http' => [
                'method' => 'POST',
                'header' => implode("\r\n", $headers),
                'content' => $body,
                'timeout' => 25,
                'ignore_errors' => true,
            ],
        ]);

        $responseBody = file_get_contents($url, false, $context);

        if ($responseBody === false) {
            throw new \RuntimeException('Akeeba-API-Request fehlgeschlagen.');
        }

        $statusCode = 0;

        foreach (($http_response_header ?? []) as $headerLine) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $headerLine, $matches) === 1) {
                $statusCode = (int) $matches[1];
                break;
            }
        }

        return [
            'status_code' => $statusCode,
            'body' => $responseBody,
        ];
    }

    private function normalizeAkeebaApiResponse(array $response): array
    {
        $statusCode = (int) ($response['status_code'] ?? 0);
        $body = (string) ($response['body'] ?? '');
        $json = json_decode($body, true);

        if ($statusCode !== 200 || !is_array($json)) {
            throw new \RuntimeException('Akeeba API antwortete nicht sauber. HTTP ' . $statusCode . '.');
        }

        $apiStatus = (int) ($json['status'] ?? 0);
        $data = $json['data'] ?? null;

        if ($apiStatus !== 200) {
            $message = is_string($data) ? $data : 'Akeeba API meldet einen unbekannten Fehler.';
            throw new \RuntimeException($message);
        }

        if (!is_array($data)) {
            throw new \RuntimeException('Akeeba API lieferte kein gültiges Datenobjekt.');
        }

        if (!empty($data['Error'])) {
            throw new \RuntimeException((string) $data['Error']);
        }

        return $data;
    }

    private function respond(array $payload, int $statusCode = 200): void
    {
        $app = Factory::getApplication();
        $this->agentResponseSent = true;

        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');

        echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        $app->close();
    }
}

