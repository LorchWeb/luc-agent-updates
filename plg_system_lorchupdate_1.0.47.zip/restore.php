<?php

declare(strict_types=1);

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    if (!headers_sent()) {
        header('HTTP/1.0 404 Not Found');
    }

    exit;
}

if (!isset($_POST['json'])) {
    exit('Ready');
}

$_REQUEST['password'] = null;
$_REQUEST['task'] = null;
$_REQUEST['instance'] = null;

try {
    $payload = json_decode((string) $_POST['json'], false, 512, JSON_THROW_ON_ERROR);
} catch (JsonException) {
    if (!headers_sent()) {
        header('HTTP/1.0 400 Bad Request');
    }

    exit('Invalid JSON');
}

$password = is_string($payload->update_password ?? null) ? $payload->update_password : '';
$task = is_string($payload->task ?? null) ? $payload->task : '';
$factory = is_string($payload->factory ?? null) ? $payload->factory : '';
$timestamp = (int) ($_POST['bridge_timestamp'] ?? 0);
$nonce = is_string($_POST['bridge_nonce'] ?? null) ? trim((string) $_POST['bridge_nonce']) : '';
$signature = is_string($_POST['bridge_signature'] ?? null) ? trim((string) $_POST['bridge_signature']) : '';
$canonical = implode("\n", [
    $task,
    $timestamp,
    $nonce,
    $password,
    $factory,
]);
$expectedSignature = $password !== '' ? hash_hmac('sha256', $canonical, $password) : '';

if ($timestamp <= 0 || abs(time() - $timestamp) > 300 || $nonce === '' || preg_match('/^[a-f0-9]{32}$/', $nonce) !== 1 || $signature === '' || $expectedSignature === '' || !hash_equals($expectedSignature, $signature)) {
    if (!headers_sent()) {
        header('HTTP/1.0 403 Forbidden');
    }

    exit('Forbidden');
}

if (!rememberBridgeNonce($nonce)) {
    if (!headers_sent()) {
        header('HTTP/1.0 403 Forbidden');
    }

    exit('Forbidden');
}

$_REQUEST['password'] = $password;

if ($task === 'startRestore') {
    $_REQUEST['task'] = 'startExtract';
} elseif ($task === 'stepRestore') {
    $_REQUEST['task'] = 'stepExtract';
} elseif ($task === 'finalizeRestore') {
    $_REQUEST['task'] = 'finalizeUpdate';
}

if ($factory !== '') {
    $_REQUEST['instance'] = $factory;
}

if ($_REQUEST['password'] !== null && $_REQUEST['task'] !== null) {
    echo '###';
    $extractPath = dirname(__DIR__, 3) . '/administrator/components/com_joomlaupdate/extract.php';

    if (is_file($extractPath)) {
        require $extractPath;
        exit;
    }

    echo json_encode([
        'status' => false,
        'error' => 'extract.php not found',
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!headers_sent()) {
    header('HTTP/1.0 404 Not Found');
}

function rememberBridgeNonce(string $nonce): bool
{
    $directory = dirname(__DIR__, 3) . '/tmp/luc-bridge-nonces';

    if (!is_dir($directory) && !@mkdir($directory, 0755, true) && !is_dir($directory)) {
        return false;
    }

    $expireBefore = time() - 600;
    $files = @glob($directory . '/*.nonce');

    if (is_array($files)) {
        foreach ($files as $filePath) {
            if (is_string($filePath) && is_file($filePath)) {
                $modifiedAt = @filemtime($filePath);

                if ($modifiedAt !== false && $modifiedAt < $expireBefore) {
                    @unlink($filePath);
                }
            }
        }
    }

    $path = $directory . '/' . hash('sha256', $nonce) . '.nonce';

    $handle = @fopen($path, 'x');

    if (!is_resource($handle)) {
        return false;
    }

    $written = fwrite($handle, (string) time());
    fclose($handle);

    return $written !== false;
}
