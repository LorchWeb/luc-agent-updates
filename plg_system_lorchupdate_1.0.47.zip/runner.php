<?php

declare(strict_types=1);

const LUC_BRIDGE_STATE_PREFIX = "<?php exit; ?>\n";

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    respond(['status' => 'fail', 'bridge_id' => '', 'phase' => '', 'message' => 'Nicht gefunden.'], 404);
}

$bridgeId = strtolower(trim((string) ($_POST['bridge_id'] ?? '')));
$action = strtolower(trim((string) ($_POST['action'] ?? '')));
$requestId = strtolower(trim((string) ($_POST['request_id'] ?? '')));
$timestamp = (int) ($_POST['timestamp'] ?? 0);
$nonce = strtolower(trim((string) ($_POST['nonce'] ?? '')));
$siteUuid = trim((string) ($_POST['site_uuid'] ?? ''));
$keyId = trim((string) ($_POST['key_id'] ?? ''));
$signature = strtolower(trim((string) ($_POST['signature'] ?? '')));

if (
    preg_match('/^[a-f0-9]{32}$/', $bridgeId) !== 1
    || preg_match('/^[a-f0-9]{32}$/', $requestId) !== 1
    || preg_match('/^[a-f0-9]{32}$/', $nonce) !== 1
    || !in_array($action, ['probe', 'advance'], true)
    || $siteUuid === ''
    || $keyId === ''
    || $signature === ''
) {
    respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => '', 'message' => 'Ungültige Bridge-Anfrage.'], 400);
}

$statePath = bridgeStatePath($bridgeId);
$state = readBridgeState($statePath);

if (!is_array($state)) {
    respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => '', 'message' => 'Update-State wurde nicht gefunden.'], 404);
}

$bridgeKey = (string) ($state['bridge_key'] ?? '');
$canonical = implode("\n", [$action, (string) $timestamp, $nonce, $requestId, $bridgeId, $siteUuid, $keyId]);
$expectedSignature = $bridgeKey !== '' ? hash_hmac('sha256', $canonical, $bridgeKey) : '';

if (
    abs(time() - $timestamp) > 300
    || !hash_equals((string) ($state['site_uuid'] ?? ''), $siteUuid)
    || !hash_equals((string) ($state['key_id'] ?? ''), $keyId)
    || $expectedSignature === ''
    || !hash_equals($expectedSignature, $signature)
    || !rememberNonce($nonce)
) {
    respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => (string) ($state['phase'] ?? ''), 'message' => 'Bridge-Signatur ist ungültig oder abgelaufen.'], 403);
}

$lockPath = $statePath . '.lock';
$lock = @fopen($lockPath, 'c+');

if (!is_resource($lock) || !flock($lock, LOCK_EX)) {
    respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => (string) ($state['phase'] ?? ''), 'message' => 'Update-State konnte nicht exklusiv gesperrt werden.'], 503);
}

try {
    $state = readBridgeState($statePath);

    if (!is_array($state)) {
        respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => '', 'message' => 'Update-State ist während des Aufrufs verloren gegangen.'], 500);
    }

    $phase = (string) ($state['phase'] ?? '');

    if ((int) ($state['expires_at'] ?? 0) < time()) {
        respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => $phase, 'message' => 'Der Update-State ist abgelaufen. Automatische Fortsetzung wurde aus Sicherheitsgründen gesperrt.']);
    }

    if ($action === 'probe') {
        $summary = [];

        if (is_array($state['finalize_receipt'] ?? null)) {
            $summary['finalize_receipt'] = $state['finalize_receipt'];
        }

        respond([
            'status' => 'ok',
            'bridge_id' => $bridgeId,
            'phase' => $phase,
            'message' => 'Der unabhängige Updatekanal ist erreichbar und der persistente State ist gültig.',
            'summary' => $summary,
        ]);
    }

    if ((string) ($state['last_request_id'] ?? '') === $requestId && is_array($state['last_response'] ?? null)) {
        respond($state['last_response']);
    }

    if ((string) ($state['inflight_request_id'] ?? '') !== '') {
        respond([
            'status' => 'fail',
            'bridge_id' => $bridgeId,
            'phase' => $phase,
            'message' => 'Ein vorheriger Extraktionsaufruf wurde nicht eindeutig abgeschlossen. Der State bleibt erhalten; kontrollierte Recovery ist erforderlich.',
        ]);
    }

    if ($phase === 'extract_finalized') {
        respond([
            'status' => 'ok',
            'bridge_id' => $bridgeId,
            'phase' => $phase,
            'message' => 'Die Joomla-Dateiextraktion ist bereits vollständig finalisiert.',
        ]);
    }

    $task = match ($phase) {
        'prepared' => 'startRestore',
        'extracting' => 'stepRestore',
        'extracted' => 'finalizeRestore',
        default => '',
    };

    if ($task === '') {
        respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => $phase, 'message' => 'Unbekannte oder nicht fortsetzbare Bridge-Phase.']);
    }

    $state['inflight_request_id'] = $requestId;
    $state['updated_at'] = time();

    if (!writeBridgeState($statePath, $state)) {
        respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => $phase, 'message' => 'Der Inflight-State konnte nicht atomar gespeichert werden.'], 500);
    }

    $bridgeResponse = callRestoreBridge(
        $task,
        (string) ($state['update_password'] ?? ''),
        isset($state['factory']) && is_string($state['factory']) ? $state['factory'] : null,
        (string) ($state['restore_url'] ?? '')
    );

    if (empty($bridgeResponse['success'])) {
        $response = [
            'status' => 'fail',
            'bridge_id' => $bridgeId,
            'phase' => $phase,
            'message' => 'Joomlas unabhängiger Extraktionsendpunkt hat den Schritt nicht erfolgreich bestätigt.',
            'summary' => is_array($bridgeResponse['summary'] ?? null) ? $bridgeResponse['summary'] : [],
        ];
        $state['inflight_request_id'] = '';
        $state['last_request_id'] = $requestId;
        $state['last_response'] = $response;
        $state['updated_at'] = time();
        writeBridgeState($statePath, $state);
        respond($response);
    }

    if ($task === 'finalizeRestore') {
        $phase = 'extract_finalized';
    } else {
        $state['factory'] = $bridgeResponse['factory'] ?? ($state['factory'] ?? null);
        $phase = !empty($bridgeResponse['needs_more_steps']) ? 'extracting' : 'extracted';
    }

    $response = [
        'status' => 'ok',
        'bridge_id' => $bridgeId,
        'phase' => $phase,
        'message' => match ($phase) {
            'extracting' => 'Ein Joomla-Extraktionsschritt wurde unabhängig vom Joomla-Bootstrap abgeschlossen.',
            'extracted' => 'Alle Joomla-Dateien wurden extrahiert. Die Extraktionsfinalisierung steht aus.',
            'extract_finalized' => 'Die Joomla-Dateiextraktion wurde vollständig und unabhängig finalisiert.',
            default => 'Standalone-Updateschritt abgeschlossen.',
        },
        'summary' => is_array($bridgeResponse['summary'] ?? null) ? $bridgeResponse['summary'] : [],
    ];
    $state['phase'] = $phase;
    $state['inflight_request_id'] = '';
    $state['last_request_id'] = $requestId;
    $state['last_response'] = $response;
    $state['updated_at'] = time();

    if (!writeBridgeState($statePath, $state)) {
        respond(['status' => 'fail', 'bridge_id' => $bridgeId, 'phase' => $phase, 'message' => 'Der fortgeschrittene Update-State konnte nicht atomar gespeichert werden.'], 500);
    }

    respond($response);
} finally {
    if (is_resource($lock)) {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

function bridgeStatePath(string $bridgeId): string
{
    return __DIR__ . '/.luc-update-bridge/' . $bridgeId . '.php';
}

function readBridgeState(string $path): ?array
{
    $content = @file_get_contents($path);

    if (!is_string($content) || !str_starts_with($content, LUC_BRIDGE_STATE_PREFIX)) {
        return null;
    }

    $decoded = json_decode(substr($content, strlen(LUC_BRIDGE_STATE_PREFIX)), true);

    return is_array($decoded) ? $decoded : null;
}

function writeBridgeState(string $path, array $state): bool
{
    $json = json_encode($state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    if (!is_string($json)) {
        return false;
    }

    $temporary = $path . '.' . bin2hex(random_bytes(4)) . '.tmp';

    if (@file_put_contents($temporary, LUC_BRIDGE_STATE_PREFIX . $json, LOCK_EX) === false) {
        return false;
    }

    @chmod($temporary, 0600);

    if (!@rename($temporary, $path)) {
        @unlink($temporary);
        return false;
    }

    return true;
}

function rememberNonce(string $nonce): bool
{
    $directory = __DIR__ . '/.luc-update-bridge/nonces';

    if (!is_dir($directory) && !@mkdir($directory, 0700, true) && !is_dir($directory)) {
        return false;
    }

    foreach ((array) @glob($directory . '/*.nonce') as $path) {
        if (is_string($path) && is_file($path) && (int) @filemtime($path) < time() - 600) {
            @unlink($path);
        }
    }

    $handle = @fopen($directory . '/' . hash('sha256', $nonce) . '.nonce', 'x');

    if (!is_resource($handle)) {
        return false;
    }

    fwrite($handle, (string) time());
    fclose($handle);
    return true;
}

function callRestoreBridge(string $task, string $password, ?string $factory, string $restoreUrl): array
{
    if ($password === '') {
        return ['success' => false, 'summary' => ['error' => 'Ungültiger interner Bridge-Kontext.']];
    }

    $urlParts = parse_url($restoreUrl);
    $validHttpsUrl = is_array($urlParts)
        && strtolower((string) ($urlParts['scheme'] ?? '')) === 'https'
        && trim((string) ($urlParts['host'] ?? '')) !== ''
        && !isset($urlParts['user'], $urlParts['pass'], $urlParts['query'], $urlParts['fragment'])
        && str_ends_with((string) ($urlParts['path'] ?? ''), '/plugins/system/lorchupdate/restore.php');
    $validTestUrl = PHP_SAPI === 'cli-server'
        && preg_match('#^http://127\.0\.0\.1:\d+/plugins/system/lorchupdate/restore\.php$#', $restoreUrl) === 1;

    if (!$validHttpsUrl && !$validTestUrl) {
        return ['success' => false, 'summary' => ['error' => 'Die gebundene Restore-URL ist ungültig.']];
    }
    $timestamp = time();
    $nonce = bin2hex(random_bytes(16));
    $payload = ['task' => $task, 'update_password' => $password];

    if ($factory !== null && $factory !== '') {
        $payload['factory'] = $factory;
    }

    $canonical = implode("\n", [$task, (string) $timestamp, $nonce, $password, $factory ?? '']);
    $form = http_build_query([
        'json' => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        'bridge_timestamp' => (string) $timestamp,
        'bridge_nonce' => $nonce,
        'bridge_signature' => hash_hmac('sha256', $canonical, $password),
    ], '', '&', PHP_QUERY_RFC3986);

    $body = null;
    $statusCode = 0;

    if (function_exists('curl_init')) {
        $curl = curl_init($restoreUrl);
        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $form,
            CURLOPT_HTTPHEADER => ['Content-Type: application/x-www-form-urlencoded', 'Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_TIMEOUT => 150,
            CURLOPT_FOLLOWLOCATION => false,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
        ]);
        $result = curl_exec($curl);
        $body = is_string($result) ? $result : null;
        $statusCode = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        curl_close($curl);
    } else {
        $context = stream_context_create(['http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/x-www-form-urlencoded\r\nAccept: application/json",
            'content' => $form,
            'timeout' => 150,
            'ignore_errors' => true,
        ]]);
        $result = @file_get_contents($restoreUrl, false, $context);
        $body = is_string($result) ? $result : null;
        foreach (($http_response_header ?? []) as $header) {
            if (preg_match('#^HTTP/\S+\s+(\d{3})#', $header, $matches) === 1) {
                $statusCode = (int) $matches[1];
                break;
            }
        }
    }

    $cleanBody = is_string($body) ? ltrim((string) preg_replace('/^#+/', '', trim($body))) : '';
    $decoded = $cleanBody !== '' ? json_decode($cleanBody, true) : null;
    $summary = ['task' => $task, 'http_status' => $statusCode, 'body_bytes' => is_string($body) ? strlen($body) : 0];

    if (!is_array($decoded)) {
        return ['success' => false, 'summary' => $summary + ['json_error' => json_last_error_msg()]];
    }

    $status = $decoded['status'] ?? null;
    $explicitSuccess = $status === true || $status === 'true';

    if (!$explicitSuccess) {
        return ['success' => false, 'summary' => $summary + ['status' => $status, 'error' => 'Extractor hat keinen expliziten Erfolgsstatus geliefert.']];
    }

    if ($task !== 'finalizeRestore' && (!array_key_exists('done', $decoded) || !is_bool($decoded['done']))) {
        return ['success' => false, 'summary' => $summary + ['status' => $status, 'error' => 'Extractor-Antwort enthält keinen strikt booleschen done-Status.']];
    }

    if ($task !== 'finalizeRestore' && $decoded['done'] === false && empty($decoded['factory']) && empty($decoded['instance'])) {
        return ['success' => false, 'summary' => $summary + ['status' => $status, 'error' => 'Extractor verlangt einen Folgeschritt, liefert aber keinen Factory-State.']];
    }
    $needsMore = array_key_exists('done', $decoded)
        ? !$decoded['done']
        : (isset($decoded['percent']) && is_numeric($decoded['percent']) ? (float) $decoded['percent'] < 100 : !empty($decoded['factory']) || !empty($decoded['instance']));

    return [
        'success' => true,
        'needs_more_steps' => $needsMore,
        'factory' => isset($decoded['factory']) || isset($decoded['instance'])
            ? (is_string($decoded['factory'] ?? $decoded['instance']) ? ($decoded['factory'] ?? $decoded['instance']) : json_encode($decoded['factory'] ?? $decoded['instance']))
            : $factory,
        'summary' => $summary + array_intersect_key($decoded, array_flip(['status', 'message', 'files', 'bytesIn', 'bytesOut', 'percent', 'done'])),
    ];
}

function respond(array $payload, int $statusCode = 200): never
{
    if (!headers_sent()) {
        http_response_code($statusCode);
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
    }

    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
