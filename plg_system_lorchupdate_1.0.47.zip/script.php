<?php

defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\Database\DatabaseInterface;

final class PlgSystemLorchupdateInstallerScript
{
    private const UPDATE_SITE_URL = 'https://lorch-webdesign.com/updates/plg_system_lorchupdate.xml';

    public function postflight(string $type, $parent): bool
    {
        $this->cleanupDuplicateUpdateSites();

        return true;
    }

    private function cleanupDuplicateUpdateSites(): void
    {
        try {
            $db = Factory::getContainer()->get(DatabaseInterface::class);
            $extensionId = $this->findAgentExtensionId($db);

            if ($extensionId <= 0) {
                return;
            }

            $query = $db->getQuery(true)
                ->select([
                    $db->quoteName('us.update_site_id'),
                    $db->quoteName('us.location'),
                    $db->quoteName('us.enabled'),
                ])
                ->from($db->quoteName('#__update_sites', 'us'))
                ->innerJoin(
                    $db->quoteName('#__update_sites_extensions', 'usex')
                    . ' ON ' . $db->quoteName('usex.update_site_id') . ' = ' . $db->quoteName('us.update_site_id')
                )
                ->where($db->quoteName('usex.extension_id') . ' = ' . (int) $extensionId)
                ->where($db->quoteName('us.location') . ' LIKE ' . $db->quote('%plg_system_lorchupdate.xml'))
                ->order($db->quoteName('us.update_site_id') . ' DESC');
            $db->setQuery($query);
            $rows = $db->loadAssocList();

            if (!is_array($rows) || $rows === []) {
                return;
            }

            $keepId = 0;

            foreach ($rows as $row) {
                if ((string) ($row['location'] ?? '') === self::UPDATE_SITE_URL) {
                    $keepId = (int) ($row['update_site_id'] ?? 0);
                    break;
                }
            }

            if ($keepId <= 0) {
                $keepId = (int) ($rows[0]['update_site_id'] ?? 0);
            }

            if ($keepId <= 0) {
                return;
            }

            $db->setQuery(
                $db->getQuery(true)
                    ->update($db->quoteName('#__update_sites'))
                    ->set($db->quoteName('location') . ' = ' . $db->quote(self::UPDATE_SITE_URL))
                    ->where($db->quoteName('update_site_id') . ' = ' . $keepId)
            )->execute();

            foreach ($rows as $row) {
                $updateSiteId = (int) ($row['update_site_id'] ?? 0);

                if ($updateSiteId <= 0 || $updateSiteId === $keepId) {
                    continue;
                }

                $db->setQuery(
                    $db->getQuery(true)
                        ->delete($db->quoteName('#__update_sites_extensions'))
                        ->where($db->quoteName('update_site_id') . ' = ' . $updateSiteId)
                )->execute();
                $db->setQuery(
                    $db->getQuery(true)
                        ->delete($db->quoteName('#__update_sites'))
                        ->where($db->quoteName('update_site_id') . ' = ' . $updateSiteId)
                )->execute();
            }
        } catch (Throwable $throwable) {
            return;
        }
    }

    private function findAgentExtensionId(DatabaseInterface $db): int
    {
        $query = $db->getQuery(true)
            ->select($db->quoteName('extension_id'))
            ->from($db->quoteName('#__extensions'))
            ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
            ->where($db->quoteName('folder') . ' = ' . $db->quote('system'))
            ->where($db->quoteName('element') . ' = ' . $db->quote('lorchupdate'))
            ->setLimit(1);
        $db->setQuery($query);

        return (int) $db->loadResult();
    }
}
